import { test, expect } from "@playwright/test";
test("local persistence, context retrieval, streaming, and validation", async ({
  request,
}) => {
  const suffix = Date.now().toString();
  const ids: { kind: string; id: string }[] = [];
  try {
    const invalid = await request.post("/api/chat", { data: { prompt: " " } });
    expect(invalid.status()).toBe(400);
    const memory = await request.post("/api/data/memory", {
      data: {
        title: `Aster_${suffix}`,
        content: `Aster_${suffix} uses TypeScript`,
        category: "PROJECTS",
      },
    });
    expect(memory.ok()).toBeTruthy();
    const mem = await memory.json();
    ids.push({ kind: "memory", id: mem.id });
    const update = await request.patch("/api/data/memory", {
      data: {
        id: mem.id,
        title: `Aster_${suffix}`,
        content: `Aster_${suffix} uses Rust`,
        category: "PROJECTS",
      },
    });
    expect(update.ok()).toBeTruthy();
    const task = await request.post("/api/data/tasks", {
      data: {
        title: `Ship_${suffix}`,
        priority: "HIGH",
        dueDate: "2026-12-01T00:00:00.000Z",
      },
    });
    const taskRow = await task.json();
    expect(task.ok()).toBeTruthy();
    ids.push({ kind: "tasks", id: taskRow.id });
    const completed = await request.patch("/api/data/tasks", {
      data: { ...taskRow, status: "COMPLETED" },
    });
    expect((await completed.json()).completedAt).toBeTruthy();
    const note = await request.post("/api/data/notes", {
      data: {
        title: `Idea_${suffix}`,
        content: "# Hello\nPersistent note",
        pinned: true,
        tags: "research",
      },
    });
    const noteRow = await note.json();
    ids.push({ kind: "notes", id: noteRow.id });
    expect(note.ok()).toBeTruthy();
    const file = await request.post("/api/data/knowledge", {
      multipart: {
        file: {
          name: "aster.md",
          mimeType: "text/markdown",
          buffer: Buffer.from(`Aster_${suffix} launch is Friday.`),
        },
      },
    });
    const knowledge = await file.json();
    ids.push({ kind: "knowledge", id: knowledge.id });
    expect(file.ok()).toBeTruthy();
    const chat = await request.post("/api/chat", {
      data: { prompt: `Aster_${suffix} launch` },
    });
    expect(chat.ok()).toBeTruthy();
    const events = (await chat.text())
      .trim()
      .split("\n")
      .map((line) => JSON.parse(line));
    const meta = events.find((e) => e.type === "meta");
    ids.push({ kind: "conversations", id: meta.conversationId });
    expect(meta.sources).toContain("aster.md");
    expect(
      events
        .filter((e) => e.type === "token")
        .map((e) => e.content)
        .join(""),
    ).toContain("Friday");
    expect(events.at(-1).type).toBe("done");
    const state = await (await request.get("/api/state")).json();
    expect(
      state.memories.find((m: { id: string }) => m.id === mem.id).content,
    ).toContain("Rust");
    expect(
      state.notes.find((n: { id: string }) => n.id === noteRow.id).pinned,
    ).toBe(true);
    expect(
      state.conversations.find(
        (c: { id: string }) => c.id === meta.conversationId,
      ).messages.length,
    ).toBe(2);
    const unsupported = await request.post("/api/data/knowledge", {
      multipart: {
        file: {
          name: "script.sh",
          mimeType: "text/plain",
          buffer: Buffer.from("echo no"),
        },
      },
    });
    expect(unsupported.status()).toBe(400);
    const crossOrigin = await request.post("/api/data/tasks", {
      headers: { origin: "https://untrusted.example" },
      data: { title: "Rejected" },
    });
    expect(crossOrigin.status()).toBe(400);
  } finally {
    for (const item of ids)
      expect(
        (
          await request.delete(`/api/data/${item.kind}`, {
            data: { id: item.id },
          })
        ).ok(),
      ).toBeTruthy();
  }
});
test("desktop and mobile navigation, neural inspection, CRUD, chat, settings, and palette", async ({
  page,
}) => {
  await page.addInitScript(() => {
    sessionStorage.setItem("edith.boot", "1");
    localStorage.setItem("edith.welcome", "1");
  });
  await page.setViewportSize({ width: 1440, height: 900 });
  await page.goto("/");
  await expect(
    page.getByRole("heading", { name: "Intelligence, connected." }),
  ).toBeVisible();
  await page.screenshot({ path: "/tmp/edith-desktop.png", fullPage: true });
  await page.getByRole("button", { name: "Memory", exact: true }).click();
  await page.getByRole("button", { name: "NEW MEMORY" }).click();
  await page.getByLabel("Title", { exact: true }).fill("Browser memory");
  await page
    .getByLabel("Content", { exact: true })
    .fill("Browser test content");
  await page.getByRole("button", { name: "SAVE", exact: true }).click();
  await expect(
    page.getByRole("heading", { name: "Browser memory" }),
  ).toBeVisible();
  await page.reload();
  await page.getByRole("button", { name: "Memory", exact: true }).click();
  await expect(
    page.getByRole("heading", { name: "Browser memory" }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Neural map", exact: true }).click();
  await page.getByRole("button", { name: "MEMORY: Browser memory" }).click();
  await expect(
    page.getByRole("heading", { name: "Browser memory" }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Memory", exact: true }).click();
  page.once("dialog", (d) => d.accept());
  await page
    .getByRole("button", { name: "Delete Browser memory", exact: true })
    .click();
  await expect(
    page.getByRole("heading", { name: "Browser memory" }),
  ).toHaveCount(0);
  await page.getByLabel("Ask EDITH").fill("Explain what demo mode can do");
  await page.getByLabel("Send message").click();
  await expect(page.locator(".assistant p")).toContainText("demo provider", {
    timeout: 20000,
  });
  await expect(page.locator(".processing-label")).toHaveCount(0, {
    timeout: 20000,
  });
  page.once("dialog", (d) => d.accept());
  await page
    .getByRole("button", {
      name: "Delete conversation Explain what demo mode can do",
      exact: true,
    })
    .click();
  await expect(page.locator(".assistant p")).toHaveCount(0);
  await page.keyboard.press("Control+k");
  await expect(
    page.getByRole("dialog", { name: "Command palette" }),
  ).toBeVisible();
  await page.getByLabel("Search commands").fill("settings");
  await page.keyboard.press("Enter");
  await expect(
    page.getByRole("heading", { name: "Settings", exact: true }),
  ).toBeVisible();
  await page.getByLabel("Reduce motion").check();
  await page.getByRole("button", { name: "SAVE CONFIGURATION" }).click();
  await expect(page.locator(".app-shell")).toHaveClass(/reduced-motion/);
  await page.getByRole("button", { name: "Core", exact: true }).click();
  await page.getByRole("button", { name: "Dismiss notification" }).click();
  await page.setViewportSize({ width: 1366, height: 768 });
  await page.screenshot({ path: "/tmp/edith-laptop.png", fullPage: true });
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= window.innerWidth,
    ),
  ).toBe(true);
  await page.setViewportSize({ width: 1920, height: 1080 });
  await page.screenshot({ path: "/tmp/edith-large.png", fullPage: true });
  await page.setViewportSize({ width: 390, height: 844 });
  await page.screenshot({ path: "/tmp/edith-mobile.png", fullPage: true });
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= window.innerWidth,
    ),
  ).toBe(true);
  await page.getByLabel("Toggle navigation").click();
  await page.getByRole("button", { name: "Tasks", exact: true }).click();
  await expect(
    page.getByRole("heading", { name: "Tasks", exact: true }),
  ).toBeVisible();
  await page.getByLabel("Toggle navigation").click();
  await page.getByRole("button", { name: "Settings", exact: true }).click();
  await page.getByLabel("Reduce motion").uncheck();
  await page.getByRole("button", { name: "SAVE CONFIGURATION" }).click();
});

test("first launch initializes the core and offers credential-free demo mode", async ({
  page,
}) => {
  await page.goto("/");
  await expect(
    page.getByText("SYSTEM INITIALIZATION", { exact: true }),
  ).toBeVisible();
  await expect(
    page.getByRole("dialog", { name: "Welcome to EDITH" }),
  ).toBeVisible({ timeout: 6000 });
  await page
    .getByRole("button", { name: "CONTINUE IN DEMO MODE", exact: true })
    .click();
  await expect(
    page.getByRole("dialog", { name: "Welcome to EDITH" }),
  ).toHaveCount(0);
  await expect(
    page.getByRole("heading", { name: "Intelligence, connected." }),
  ).toBeVisible();
});

test("local voice API produces audio, settings persist, and voice preview can be stopped", async ({
  page,
  request,
}) => {
  const before = await (await request.get("/api/state")).json();
  expect(before.voice.available).toBe(true);
  const audio = await request.post("/api/voice", {
    data: { text: "EDITH is online.", voice: "af_sarah", speed: 0.94 },
  });
  expect(audio.ok()).toBeTruthy();
  expect(audio.headers()["content-type"]).toContain("audio/wav");
  const bytes = await audio.body();
  expect(bytes.subarray(0, 4).toString()).toBe("RIFF");
  expect(bytes.subarray(8, 12).toString()).toBe("WAVE");
  expect(bytes.length).toBeGreaterThan(10000);
  const bad = await request.post("/api/voice", {
    data: { text: "Hello", voice: "not-a-voice" },
  });
  expect(bad.status()).toBe(400);
  await page.addInitScript(() => {
    sessionStorage.setItem("edith.boot", "1");
    localStorage.setItem("edith.welcome", "1");
  });
  await page.goto("/");
  await page.getByRole("button", { name: "Settings", exact: true }).click();
  await page.getByRole("combobox", {name:"Voice engine",exact:true}).selectOption("kokoro");
  await page.getByRole("combobox", {name:"Voice",exact:true}).selectOption("af_bella");
  await page.getByRole("button", { name: "SAVE CONFIGURATION" }).click();
  await page
    .getByRole("button", { name: "PREVIEW EDITH VOICE", exact: true })
    .click();
  await expect(page.getByText("EDITH IS SPEAKING…",{exact:true})).toBeVisible({timeout:20000});
  await expect(
    page.getByRole("button", { name: "STOP VOICE", exact: true }),
  ).toBeVisible({ timeout: 20000 });
  await page.getByRole("button", { name: "STOP VOICE", exact: true }).click();
  await expect(
    page.getByRole("button", { name: "STOP VOICE", exact: true }),
  ).toHaveCount(0);
  await page.reload();
  await page.getByRole("button", { name: "Settings", exact: true }).click();
  await expect(page.getByRole("combobox", {name:"Voice",exact:true})).toHaveValue(
    "af_bella",
  );
  expect(
    (await (await request.get("/api/state")).json()).localModel.available,
  ).toBe(false);
  await expect(
    page.getByRole("button", { name: "USE FREE LOCAL MODEL", exact: true }),
  ).toBeDisabled();
  const unavailable = await request.post("/api/data/model", {
    data: { mode: "local" },
  });
  expect(unavailable.ok()).toBe(false);
  expect((await (await request.get("/api/state")).json()).provider).toBe(
    "mock",
  );
  await request.post("/api/data/settings", { data: before.settings });
});

 test("each completed reply requests the neural voice automatically", async ({page, request}) => {
 const before=await (await request.get("/api/state")).json();
 await request.post("/api/data/settings", {data:{...before.settings,voiceOutput:true,voiceEngine:"kokoro",voiceId:"af_sarah"}});
 try {
  await page.addInitScript(()=>{sessionStorage.setItem("edith.boot","1");localStorage.setItem("edith.welcome","1");});
  await page.goto("/");
  for(const prompt of ["Hello EDITH", "What can you do?"]) {
   const voice=page.waitForRequest(r=>r.url().endsWith("/api/voice")&&r.method()==="POST"&&!r.postDataJSON()?.text?.includes("Welcome back"));
   await page.getByRole("textbox",{name:"Ask EDITH"}).fill(prompt);
   await page.getByRole("textbox",{name:"Ask EDITH"}).press("Enter");
   const sent=await voice;
   expect(sent.postDataJSON().voice).toBe("af_sarah");
   expect(sent.postDataJSON().text.length).toBeGreaterThan(0);
   await expect(page.getByText("EDITH IS SPEAKING…",{exact:true})).toBeVisible({timeout:20000});
   await page.getByRole("button",{name:"Stop speech"}).click();
  }
 } finally {await request.post("/api/data/settings",{data:before.settings});}
 });

test("neural voice starts before a delayed chat stream finishes",async({page,request})=>{
 const {createServer}=await import('node:http');
 let release!:()=>void;
 const gate=new Promise<void>(resolve=>{release=resolve;});
 const server=createServer(async(req,res)=>{
  res.setHeader('Access-Control-Allow-Origin','*');
  res.setHeader('Access-Control-Allow-Headers','content-type');
  if(req.method==='OPTIONS'){res.end();return;}
  res.setHeader('Content-Type','application/x-ndjson');
  res.write(JSON.stringify({type:'token',content:'I am ready. '})+'\n');
  await gate;
  res.end(JSON.stringify({type:'token',content:'This is the remaining answer.'})+'\n');
 });
 await new Promise<void>(resolve=>server.listen(3022,'127.0.0.1',resolve));
 const before=await (await request.get('/api/state')).json();
 await request.post('/api/data/settings',{data:{...before.settings,voiceOutput:true,voiceEngine:'kokoro',voiceId:'af_sarah'}});
 try {
  await page.addInitScript(()=>{sessionStorage.setItem('edith.boot','1');localStorage.setItem('edith.welcome','1');});
  await page.route('**/api/chat',route=>route.continue({url:'http://127.0.0.1:3022/stream'}));
  await page.goto('/');
  const voice=page.waitForRequest(r=>r.url().endsWith('/api/voice') && r.postDataJSON()?.text==='I am ready.');
  await page.getByRole('textbox',{name:'Ask EDITH'}).fill('Start speaking early');
  await page.getByRole('textbox',{name:'Ask EDITH'}).press('Enter');
  expect((await voice).postDataJSON().text).toBe('I am ready.');
  await expect(page.getByText('EDITH IS SPEAKING…',{exact:true})).toBeVisible({timeout:20000});
  // The rest of the answer has deliberately not been released yet.
  await expect(page.getByText('This is the remaining answer.',{exact:false})).toHaveCount(0);
  release();
  await expect(page.getByText('This is the remaining answer.',{exact:false})).toBeVisible();
  await page.getByRole('button',{name:'Stop speech'}).click();
 } finally {
  release();
  await request.post('/api/data/settings',{data:before.settings});
  await new Promise<void>(resolve=>server.close(()=>resolve()));
 }
});

test("hello returns a direct greeting without invoking model narration",async({request})=>{
 const before=await (await request.get('/api/state')).json();
 const response=await request.post('/api/chat',{data:{prompt:'hello'}});
 expect(response.ok()).toBeTruthy();
 const tokens=(await response.text()).trim().split('\n').map(line=>JSON.parse(line)).filter(item=>item.type==='token').map(item=>item.content).join('');
 const name=before.settings.displayName==='Operator' ? 'Emiliano' : before.settings.displayName;
 expect(tokens).toBe(`Hello ${name}.`);
});

test("abilities import multiple documents and images, show opening greeting, and fire timers",async({page,request})=>{
 const ids:string[]=[];
 try {
  const upload=async(name:string,mimeType:string,buffer:Buffer)=>{
   const r=await request.post('/api/data/knowledge',{multipart:{file:{name,mimeType,buffer}}});
   expect(r.ok()).toBeTruthy();const file=await r.json();ids.push(file.id);return file;
  };
  await upload('ability-reference.txt','text/plain',Buffer.from('The project deadline is next Friday. Review the budget and prepare slides.'));
  const {default:sharp}=await import('sharp');
  const png=await sharp({create:{width:16,height:16,channels:3,background:'#33aaaa'}}).png().toBuffer();
  await upload('ability-image.png','image/png',png);
  const unsupported=await request.post('/api/data/knowledge',{multipart:{file:{name:'file.exe',mimeType:'application/octet-stream',buffer:Buffer.from('not supported')}}});
  expect(unsupported.status()).toBe(400);
  const invalidTimer=await request.post('/api/abilities',{data:{action:'timer',seconds:-5}});
  expect(invalidTimer.status()).toBe(400);
  const invalidPhone=await request.post('/api/abilities',{data:{action:'phone-settings',number:'123',enabled:true}});
  expect(invalidPhone.status()).toBe(400);
  const abilityState=await (await request.get('/api/abilities')).json();
  if(!abilityState.phone.configured){
   expect((await request.post('/api/abilities',{data:{action:'test-call'}})).status()).toBe(400);
   expect((await request.post('/api/abilities',{data:{action:'timer',seconds:5,notifyPhone:true}})).status()).toBe(400);
  }
  const analysis=await request.post('/api/abilities',{data:{action:'analyze',fileIds:ids,instruction:'Summarize these files'}});
  // Demo mode must reject analysis rather than claim it saw the image.
  const state=await (await request.get('/api/state')).json();
  if(state.provider==='mock')expect(analysis.status()).toBe(400);
  await page.addInitScript(()=>{sessionStorage.setItem('edith.boot','1');localStorage.setItem('edith.welcome','1');});
  await page.goto('/');
  await expect(page.getByText(/Hello .*\. Welcome back\./)).toBeVisible();
  await page.getByRole('button',{name:'Abilities',exact:true}).click();
  await expect(page.getByRole('button',{name:'ADD FILES OR IMAGES'})).toBeVisible();
  await expect(page.getByText('ability-reference.txt',{exact:true})).toBeVisible();
  const timerResponse=await request.post('/api/abilities',{data:{action:'timer',label:'Ability test',seconds:1}});
  expect(timerResponse.ok()).toBeTruthy();
  await expect(page.getByRole('alert').filter({hasText:'Ability test timer finished.'})).toBeVisible({timeout:10000});
  await page.getByRole('alert').filter({hasText:'Ability test timer finished.'}).getByRole('button',{name:'DISMISS'}).click();
  await expect(page.getByRole('alert').filter({hasText:'Ability test timer finished.'})).toHaveCount(0);
  const chat=await request.post('/api/chat',{data:{prompt:'set a timer for 20 seconds called Chat timer'}});
  expect(await chat.text()).toContain('Timer set for 20 seconds');
  const timers=(await (await request.get('/api/abilities')).json()).timers;
  for(const timer of timers.filter((t:{label:string})=>t.label==='Chat timer'))await request.post('/api/abilities',{data:{action:'dismiss-timer',id:timer.id}});
 } finally {for(const id of ids)await request.delete('/api/data/knowledge',{data:{id}});}
});
