# E.D.I.T.H. — Emiliano’s personal assistant

A private, persistent Next.js 15 / React 19 / TypeScript application with SQLite, a separate durable scheduler, a composed cyan interface, and explicitly configured integrations.

## Start locally

Use Node.js 24. Python 3 is needed only by optional local speech tooling; it is not required by the core app. From this directory:

```sh
bash scripts/setup-cloud.sh
npm run dev
```

In another terminal, **keep the scheduler running independently of the browser**:

```sh
npm run scheduler
```

Open the app on your machine’s loopback port 3000. First opening asks you to create a password of at least 12 characters. There is no default production password. The greeting is **“Hello, Emiliano.”**; voice requires clicking **Enable voice** and a configured voice service. The browser-session greeting is not automatically repeated by navigation or refresh.

For production, stop the development server, run `npm run build`, then `npm start`. A supervised scheduler process must also run. Use the existing checkout; cloud tasks are already isolated and do not need an extra Git worktree.

## What works without external credentials

- Password sign-in, seven-day revocable HTTP-only sessions, origin checks, password hashing, and private original-file storage.
- Persisted tasks, subtasks, projects, start/due dates, priorities, tags, estimates, recurrence, notes, and explicit memory.
- Today, upcoming, overdue, active, and completed task filters; a suggested plan constrained by your chosen time budget and estimates. Suggestions do not change your priorities or create calendar entries.
- Natural task/reminder commands, such as `remind me to finish my presentation tomorrow at 17:00`. An ambiguous time asks a follow-up; reply `5 pm` in the same conversation. Dates use the saved timezone, initially Europe/Helsinki. DST gaps and ambiguities are rejected for manually entered deadlines.
- Local appointments, linked task/event reminders, persistent in-app notifications, snooze, quiet hours, and daily/weekly/monthly recurrence.
- PDF, DOCX, XLSX, text, Markdown, JSON, CSV, PNG/JPEG/WebP imports, extracted-text previews, original downloads, and page/sheet/row/section citation labels. Unsupported/corrupt files report an extraction error. Blank/unreadable PDF pages and the 200-page extraction limit are identified. XLSX formulas use cached results; macros are never run.
- Demo conversation with real lexical retrieval, saved transcripts, explicit memory commands, and honest provider status. Demo mode does **not** perform AI reasoning, document analysis, or live image inference.
- Data export, conversation/document deletion with confirmation, and preferences for microphone, voice, reminders, and reduced motion.

Tasks estimated at 30 minutes use a visible default until you edit the estimate. No artificial telemetry, fake appointments, or random diagnostic values are generated.

## Configure integrations securely

### Free cloud conversation and ElevenLabs voice

Groq's [official cookbook](https://github.com/groq/groq-api-cookbook) offers API keys through a free developer account. Create your own key at [Groq API Keys](https://console.groq.com/keys). Free access has usage limits; check your account's current model availability and limits. E.D.I.T.H. does not enroll you in a paid plan.

On your Mac, open Terminal in the folder containing E.D.I.T.H.:

```sh
cd ~/Downloads/EDITH-Emiliano
nano .env
```

Replace the existing entries with your own values; do not add duplicate entries:

```dotenv
AI_PROVIDER="groq"
GROQ_API_KEY="paste_your_own_groq_key_here"
GROQ_MODEL="openai/gpt-oss-20b"
ELEVENLABS_API_KEY="paste_your_own_elevenlabs_key_here"
ELEVENLABS_VOICE_ID="paste_your_selected_voice_id_here"
```

Get the voice key from the API Keys area of your ElevenLabs account, with Text-to-Speech access. In your voice library, choose a voice your account can use and copy its voice ID. The voice ID identifies the voice; it is a separate value from the API key. ElevenLabs has its own account allowance, independent of Groq.

Save in nano with **Control+O**, **Enter**, then exit with **Control+X**. Restart the app and scheduler (Control+C in each running terminal, then `npm run dev` and `npm run scheduler` respectively). In **Integrations**, choose **Use Groq cloud AI** and **Test model connection**. Then preview your selected voice or click **Enable voice**. A successful provider response verifies the key; a saved configuration alone does not.

**The earlier download already supports Groq.** To configure that copy without replacing any files, use these existing entries instead of the Groq preset:

```dotenv
AI_PROVIDER="openai-compatible"
AI_BASE_URL="https://api.groq.com/openai/v1"
AI_MODEL="openai/gpt-oss-20b"
AI_API_KEY="paste_your_own_groq_key_here"
ELEVENLABS_API_KEY="paste_your_own_elevenlabs_key_here"
ELEVENLABS_VOICE_ID="paste_your_selected_voice_id_here"
```

Restart both processes, then test from Integrations. In the newer version, choose **Use configured cloud AI** if a different provider was previously selected. Keep your existing `.env`, database, and private storage when updating code; unzipping a replacement folder does not migrate your personal data.

Copy `.env.example` only on first setup, preserve existing values, and keep `.env` private (mode 600). Supply credentials through your deployment’s secret manager or protected server environment. Never enter API keys in chat, browser code, or documents. Restart both backend processes after server configuration changes. The Integrations screen identifies missing settings and distinguishes configuration from verified connectivity.

| Integration | Required setup | Verification |
| --- | --- | --- |
| AI | `AI_PROVIDER=openai-compatible`, `AI_BASE_URL`, `AI_MODEL`, and `AI_API_KEY` if required | Test model connection in Integrations |
| Groq cloud AI | `AI_PROVIDER=groq` and `GROQ_API_KEY`; optional `GROQ_MODEL` | Choose Groq and test model connection in Integrations |
| Local model | Running Ollama or an OpenAI-compatible loopback model; local model settings | Select local mode through the model API after the service responds |
| ElevenLabs | `ELEVENLABS_API_KEY` and your `ELEVENLABS_VOICE_ID` | Enable voice / preview; the same server-selected voice is used for calls |
| Google Calendar | Google OAuth client ID/secret and public HTTPS `EDITH_PUBLIC_URL`; register `/api/hooks/calendar` as the exact redirect URI | Explicitly connect, choose read-only or event creation, select calendars, and sync |
| Calls | Twilio account SID, raw auth token, assigned from-number, Verify service SID, public HTTPS origin, and ElevenLabs configuration | Save your E.164 number, explicitly send an SMS verification, verify the code, opt in, then confirm a test call |
| Push | VAPID public/private keys and contact subject; HTTPS or localhost; browser permission | Enable browser notifications explicitly |
| Email | TLS SMTP host/port/user/password/from and `NOTIFICATION_EMAIL` | Schedule an email reminder and inspect the provider result |
| SMS | Twilio credentials and a verified number | Explicitly choose SMS on a reminder and inspect the queued status |
| Scanned PDF OCR | Install OCRmyPDF, Tesseract/language packs and their prerequisites; set `OCR_COMMAND` to the absolute OCRmyPDF path | Import a scanned PDF; inspect the uncertainty warning and original |

The Google integration reads **only selected calendars** and polls every five minutes while the scheduler runs. Event creation needs authorized write access and confirmation of the exact event. Provider errors preserve cached events and display the failed sync. Configure approved network destinations for your chosen services: `api.elevenlabs.io`, `api.twilio.com`, `verify.twilio.com`, `accounts.google.com`, `oauth2.googleapis.com`, `www.googleapis.com`, your AI endpoint, SMTP host, and browser push endpoint. Do not disable TLS validation to troubleshoot access.

For document/memory context, the external-sharing preference defaults off. Prompts and recent conversation still go to the selected external model. Explicitly selected document analysis also requires this opt-in. Model output is grounded with supplied citation labels and bounded excerpts (12,000 characters); check important conclusions against originals. Embedded document instructions are reference data. Action items are saved as **proposals**; review and select them before tasks are created. Edited report drafts export as Markdown rather than claiming to preserve Word layout. Image analysis uses optional local Moondream and remains an interpretation.

## Scheduling and calls

`npm run scheduler` polls SQLite every five seconds. Jobs have unique occurrence/channel keys and atomic claims. A crash during an external delivery marks its outcome uncertain after fifteen minutes and **does not replay it automatically**. Quiet hours defer waiting jobs in your saved timezone. Recurring reminders keep local wall-clock time across DST. If a requested daily call falls in a spring-forward gap, it uses the next valid wall-clock time; a repeated autumn hour gets one attempt.

In-app delivery means the notification was stored in your inbox; it does not notify a closed browser. Configured push, email, or SMS are needed for an alert outside the app. Push/email acceptance and SMS queueing are not proof a person received them. There is no automatic retry of failed or ambiguous external notifications. Job and delivery records show these distinctions.

Calls require verified opt-in. Changing the number clears verification. Pause/disable cancels waiting attempts; a call that already started may continue. Before revealing private briefing details, the voice asks if now is a good time. Voicemail either receives a generic check-in with no private details or no message. Supported call commands are adding an exact task/reminder, snoozing a named reminder, and `Stop calling me`; ambiguous requests preserve existing data and direct you to the app. Signed Twilio requests are validated and repeated command webhooks are idempotent. Call history uses provider statuses and duration. An unanswered call is never redialled automatically. Pricing/balance are not supplied by the current provider APIs; consult your provider accounts.

## Deployment and backups

This is a single-operator application, not a multi-tenant service. Initialize your password locally before public deployment, use HTTPS behind a trusted reverse proxy, and restrict administrative access. `EDITH_PUBLIC_URL` must be the exact HTTPS origin seen by Twilio/Google. Session cookies become Secure for an HTTPS origin. The optional `EDITH_BOOTSTRAP_TOKEN` is for an administrator-controlled bootstrap client; the normal browser setup is local.

Example supervised web/scheduler service files are in `deploy/`; adapt the Node executable and working directories to your server. Keep the web process and scheduler independently restartable. Do not use the optional Mac/Windows launchers for public hosting; they are legacy local launchers and were not executed on those platforms.

Back up `prisma/edith.db` with an SQLite-safe backup method, private document storage, and `.edith-runtime/master.key` together. That key encrypts OAuth tokens and signs sessions/audio links. Protect it, preserve it across restarts, and do not rotate it without a migration/reauthorization plan. API secrets stay in the server environment; they are excluded from exports. Delete original documents only through the confirmed document action. Generated call audio is privately stored and accessible to the phone provider through expiring, signed URLs.

## Validation

```sh
npm run lint
npm test
npm run build
npm run typecheck
npm run test:e2e
```

Build before a type check on a fresh checkout to generate Next route types. Build and development mode both use `.next`; do not run them concurrently. Browser tests launch their own production server on port 3001, with a **separate** acceptance database and private storage under `.edith-runtime/`. The publicly known test password is used only by that isolated test database, never by the real workspace. Tests use system Chromium (`/usr/bin/chromium`); adjust that path to an installed Chromium on other systems.

The backend suite covers DST, private credential handling, authentic task persistence, original XLSX extraction/citations, reviewed task proposals, duplicate/uncertain scheduler jobs, verified call opt-in, signed callbacks, immediate disabling, and cancelled calendar events. External provider transports are mocked in automated tests. The browser voice test plays mock provider WAV audio to validate the real audio-permission gesture, interruption, and greeting suppression. **Live ElevenLabs speech, real calls, push/email delivery, and Google authorization need your actual credentials and have not been claimed as verified.**
