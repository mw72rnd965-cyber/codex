# E.D.I.T.H. — Emiliano’s personal assistant

A private, persistent Next.js 15 / React 19 / TypeScript application with SQLite, a separate durable scheduler, a composed cyan interface, and explicitly configured integrations.

## Start locally

Use Node.js 24. Python 3 is needed only by optional local speech tooling; it is not required by the core app. From this directory:

```sh
bash scripts/setup-cloud.sh
npm run dev
```

In another terminal, **keep the scheduler running independently of the browser**:

```sh
npm run scheduler
```

Open the app on your machine’s loopback port 3000. Fresh installation defaults to **Ollama on this Mac**, using `qwen2.5:3b`; open Ollama and run `ollama pull qwen2.5:3b` before testing conversation. An existing `.env` is preserved; run `npm run ai:ollama` to switch an older installation. First opening asks you to create a password of at least 12 characters. There is no default production password. The greeting is **“Hello, Emiliano.”**; voice requires clicking **Enable voice** and a configured voice service. The browser-session greeting is not automatically repeated by navigation or refresh.

For production, stop the development server, run `npm run build`, then `npm start`. A supervised scheduler process must also run. Use the existing checkout; cloud tasks are already isolated and do not need an extra Git worktree.

## What works without external credentials

- Password sign-in, seven-day revocable HTTP-only sessions, origin checks, password hashing, and private original-file storage.
- Persisted tasks, subtasks, projects, start/due dates, priorities, tags, estimates, recurrence, notes, and explicit memory.
- Today, upcoming, overdue, active, and completed task filters; a suggested plan constrained by your chosen time budget and estimates. Suggestions do not change your priorities or create calendar entries.
- Natural task/reminder commands, such as `remind me to finish my presentation tomorrow at 17:00`. An ambiguous time asks a follow-up; reply `5 pm` in the same conversation. Dates use the saved timezone, initially Europe/Helsinki. DST gaps and ambiguities are rejected for manually entered deadlines.
- Local appointments, linked task/event reminders, persistent in-app notifications, snooze, quiet hours, and daily/weekly/monthly recurrence.
- PDF, DOCX, XLSX, text, Markdown, JSON, CSV, PNG/JPEG/WebP imports, extracted-text previews, original downloads, and page/sheet/row/section citation labels. Unsupported/corrupt files report an extraction error. Blank/unreadable PDF pages and the 200-page extraction limit are identified. XLSX formulas use cached results; macros are never run.
- Demo conversation with real lexical retrieval, saved transcripts, explicit memory commands, and honest provider status. Demo mode does **not** perform AI reasoning, document analysis, or live image inference.
- Current time/date answers read the computer clock in your saved timezone, including daylight saving time. These bypass the model and work offline.
- Web search retrieves real source excerpts and links through Tavily's rate-limited keyless search. It needs internet access but no API key by default; unavailable searches report failure rather than invented facts.
- Data export, conversation/document deletion with confirmation, and preferences for microphone, voice, reminders, and reduced motion.

Tasks estimated at 30 minutes use a visible default until you edit the estimate. No artificial telemetry, fake appointments, or random diagnostic values are generated.

## Animated core

Open **Core** in the sidebar or **Open animated core** on Home. The detailed core combines counter-rotating segmented rings, radial markings, orbiting lights, a scanning glow, flowing plasma, particles and a voice animation. A smaller version appears on Home, sign-in and the conversation status strip.

Motion and color follow the assistant's actual idle, listening, processing, voice preparation, speaking and error states. The animation is decorative, not a measurement of microphone volume, processor load or neural-network activity. The surrounding panel shows your actual selected model, configuration, microphone/voice preferences and reminder worker status.

Choose **Ambient** or **Energized**, or **Pause motion**. Pausing the visual does not pause a request or speech. Your saved **Reduce interface motion** preference and the operating system's reduced-motion setting stop continuous animation; animations also suspend off-screen and when the tab is hidden. The Core screen is responsive and retains its controls on mobile. No new API key or model is required.

## Configure integrations securely

### Ollama on your Mac

Ollama runs the selected conversation model locally, without an AI API key. Keep the Ollama app running and download the model once:

```sh
ollama pull qwen2.5:3b
```

From your E.D.I.T.H. folder, run:

```sh
npm run ai:ollama
```

This command changes only the local AI entries in `.env` and the saved provider selection. It preserves existing keys, passwords, tasks and private documents. Restart the app and scheduler, then use **Integrations → Test model connection**. The **Use Ollama on this Mac** button can select local mode after Ollama is running. Configuration alone does not verify a live response.

To choose a model already downloaded on your Mac, get its exact name from `ollama list`, then use, for example, `npm run ai:ollama -- llama3.2:3b`. Model speed and memory use depend on your Mac. ElevenLabs remains a separate optional voice service, with its own API key and voice ID.

### Update your existing installation

The animated core download extracts into **EDITH-Core**, beside your existing **EDITH-Emiliano** or **EDITH-Ollama** folder. Stop your running E.D.I.T.H. app and scheduler with Control+C in their terminals, then run:

```sh
node ~/Downloads/EDITH-Core/scripts/update-existing.mjs ~/Downloads/EDITH-Emiliano
cd ~/Downloads/EDITH-Emiliano
bash scripts/setup-cloud.sh
npm run dev
```

In the second terminal, run `cd ~/Downloads/EDITH-Emiliano` and `npm run scheduler`. Keep Ollama running. The update copies application files and preserves your existing `.env`, selected model/provider, database, private storage and unrelated files. Setup applies supported database migrations without clearing data. Adjust the paths if you extracted elsewhere. Fresh installation from EDITH-Core uses the normal Start locally instructions instead.

### Accurate time and web sources

Ask **What time is it?**, **What is today's date?**, or **What time is it in New York?**. E.D.I.T.H. reads the clock of the computer running its backend and labels the timezone and source. On your local installation this is your Mac's clock. Change your timezone in Settings; the initial timezone is Europe/Helsinki. Other model requests also receive the current clock. A correct system clock and timezone are needed for an accurate answer.

Ask **Search the web for the latest NASA news** or **Search the web for Helsinki history**. Explicit web searches and questions about current news, weather, prices or similar topics retrieve up to three actual source excerpts. Replies show clickable source links, the provider and retrieval time. They are search excerpts rather than full-page analysis; check publication dates and originals for important details. Ordinary conversation continues to use your selected Ollama/cloud model. It does not have built-in browsing.

Search defaults to Tavily's public, rate-limited keyless mode, documented by its [official Python SDK](https://github.com/tavily-ai/tavily-python#usage). Existing installations use this default without editing `.env`. Only your current search query goes to the search provider, not earlier messages, document contents or saved memory. Failed, empty or rate-limited searches explain the problem and do not pass the question to the model for a guessed current answer.

Optional server settings in `.env`:

```dotenv
WEB_SEARCH_ENABLED="true"
WEB_SEARCH_PROVIDER="tavily"
TAVILY_API_KEY=""
```

Leave the key blank for keyless search. You may use your own private Tavily key for your account's allowance; account limits still apply. Set `WEB_SEARCH_ENABLED=false` to disable external searching, or `WEB_SEARCH_PROVIDER=duckduckgo` for the alternative HTML search connector. DuckDuckGo can fall back to Wikipedia excerpts for general questions, but never substitutes Wikipedia for a failed current news/weather/price search. Restart the app after changing server settings. **Integrations → Web sources** displays configuration status; it does not claim a successful live search until a query returns sources.

### Free cloud conversation and ElevenLabs voice

Groq's [official cookbook](https://github.com/groq/groq-api-cookbook) offers API keys through a free developer account. Create your own key at [Groq API Keys](https://console.groq.com/keys). Free access has usage limits; check your account's current model availability and limits. E.D.I.T.H. does not enroll you in a paid plan.

On your Mac, open Terminal in the folder containing E.D.I.T.H.:

```sh
cd ~/Downloads/EDITH-Emiliano
nano .env
```

Replace the existing entries with your own values; do not add duplicate entries:

```dotenv
AI_PROVIDER="groq"
GROQ_API_KEY="paste_your_own_groq_key_here"
GROQ_MODEL="openai/gpt-oss-20b"
ELEVENLABS_API_KEY="paste_your_own_elevenlabs_key_here"
ELEVENLABS_VOICE_ID="paste_your_selected_voice_id_here"
```

Setup and the code updater add blank `ELEVENLABS_API_KEY` and `ELEVENLABS_VOICE_ID` entries if an older `.env` is missing them. Existing values are never replaced. To add just these fields from an updated installation, run `node scripts/ensure-voice-env.mjs` in your current app folder. The small [voice setup download](https://github.com/mw72rnd965-cyber/codex/raw/refs/heads/edith-emiliano-download-20261010/EDITH-Voice-Setup.zip) also works without reinstalling the app: extract it into Downloads and run `node ~/Downloads/EDITH-Voice-Setup/add-voice-fields.mjs ~/Downloads/EDITH-Emiliano`, using your actual existing installation path. Fill in the blank entries locally and restart afterward.

Get the voice key from the API Keys area of your ElevenLabs account, with Text-to-Speech access. In your voice library, choose a voice your account can use and copy its voice ID. The voice ID identifies the voice; it is a separate value from the API key. ElevenLabs has its own account allowance, independent of Groq.

Save in nano with **Control+O**, **Enter**, then exit with **Control+X**. Restart the app and scheduler (Control+C in each running terminal, then `npm run dev` and `npm run scheduler` respectively). In **Integrations**, choose **Use Groq cloud AI** and **Test model connection**. Then preview your selected voice or click **Enable voice**. A successful provider response verifies the key; a saved configuration alone does not.

**The earlier download already supports Groq.** To configure that copy without replacing any files, use these existing entries instead of the Groq preset:

```dotenv
AI_PROVIDER="openai-compatible"
AI_BASE_URL="https://api.groq.com/openai/v1"
AI_MODEL="openai/gpt-oss-20b"
AI_API_KEY="paste_your_own_groq_key_here"
ELEVENLABS_API_KEY="paste_your_own_elevenlabs_key_here"
ELEVENLABS_VOICE_ID="paste_your_selected_voice_id_here"
```

Restart both processes, then test from Integrations. In the newer version, choose **Use configured cloud AI** if a different provider was previously selected. Keep your existing `.env`, database, and private storage when updating code; unzipping a replacement folder does not migrate your personal data.

Copy `.env.example` only on first setup, preserve existing values, and keep `.env` private (mode 600). Supply credentials through your deployment’s secret manager or protected server environment. Never enter API keys in chat, browser code, or documents. Restart both backend processes after server configuration changes. The Integrations screen identifies missing settings and distinguishes configuration from verified connectivity.

| Integration | Required setup | Verification |
| --- | --- | --- |
| AI | `AI_PROVIDER=openai-compatible`, `AI_BASE_URL`, `AI_MODEL`, and `AI_API_KEY` if required | Test model connection in Integrations |
| Groq cloud AI | `AI_PROVIDER=groq` and `GROQ_API_KEY`; optional `GROQ_MODEL` | Choose Groq and test model connection in Integrations |
| Ollama | Running Ollama and the downloaded `LOCAL_AI_MODEL`; `npm run ai:ollama` selects it | Use Ollama on this Mac, then test model connection |
| Web sources | Internet access to `api.tavily.com`; optional private `TAVILY_API_KEY` | Ask a web search question and inspect its actual links and retrieval time |
| ElevenLabs | `ELEVENLABS_API_KEY` and your `ELEVENLABS_VOICE_ID` | Enable voice / preview; the same server-selected voice is used for calls |
| Google Calendar | Google OAuth client ID/secret and public HTTPS `EDITH_PUBLIC_URL`; register `/api/hooks/calendar` as the exact redirect URI | Explicitly connect, choose read-only or event creation, select calendars, and sync |
| Calls | Twilio account SID, raw auth token, assigned from-number, Verify service SID, public HTTPS origin, and ElevenLabs configuration | Save your E.164 number, explicitly send an SMS verification, verify the code, opt in, then confirm a test call |
| Push | VAPID public/private keys and contact subject; HTTPS or localhost; browser permission | Enable browser notifications explicitly |
| Email | TLS SMTP host/port/user/password/from and `NOTIFICATION_EMAIL` | Schedule an email reminder and inspect the provider result |
| SMS | Twilio credentials and a verified number | Explicitly choose SMS on a reminder and inspect the queued status |
| Scanned PDF OCR | Install OCRmyPDF, Tesseract/language packs and their prerequisites; set `OCR_COMMAND` to the absolute OCRmyPDF path | Import a scanned PDF; inspect the uncertainty warning and original |

The Google integration reads **only selected calendars** and polls every five minutes while the scheduler runs. Event creation needs authorized write access and confirmation of the exact event. Provider errors preserve cached events and display the failed sync. Configure approved network destinations for your chosen services: `api.elevenlabs.io`, `api.twilio.com`, `verify.twilio.com`, `accounts.google.com`, `oauth2.googleapis.com`, `www.googleapis.com`, your AI endpoint, SMTP host, and browser push endpoint. Do not disable TLS validation to troubleshoot access.

For document/memory context, the external-sharing preference defaults off. Prompts and recent conversation still go to the selected external model. Explicitly selected document analysis also requires this opt-in. Model output is grounded with supplied citation labels and bounded excerpts (12,000 characters); check important conclusions against originals. Embedded document instructions are reference data. Action items are saved as **proposals**; review and select them before tasks are created. Edited report drafts export as Markdown rather than claiming to preserve Word layout. Image analysis uses optional local Moondream and remains an interpretation.

## Scheduling and calls

`npm run scheduler` polls SQLite every five seconds. Jobs have unique occurrence/channel keys and atomic claims. A crash during an external delivery marks its outcome uncertain after fifteen minutes and **does not replay it automatically**. Quiet hours defer waiting jobs in your saved timezone. Recurring reminders keep local wall-clock time across DST. If a requested daily call falls in a spring-forward gap, it uses the next valid wall-clock time; a repeated autumn hour gets one attempt.

In-app delivery means the notification was stored in your inbox; it does not notify a closed browser. Configured push, email, or SMS are needed for an alert outside the app. Push/email acceptance and SMS queueing are not proof a person received them. There is no automatic retry of failed or ambiguous external notifications. Job and delivery records show these distinctions.

Calls require verified opt-in. Changing the number clears verification. Pause/disable cancels waiting attempts; a call that already started may continue. Before revealing private briefing details, the voice asks if now is a good time. Voicemail either receives a generic check-in with no private details or no message. Supported call commands are adding an exact task/reminder, snoozing a named reminder, and `Stop calling me`; ambiguous requests preserve existing data and direct you to the app. Signed Twilio requests are validated and repeated command webhooks are idempotent. Call history uses provider statuses and duration. An unanswered call is never redialled automatically. Pricing/balance are not supplied by the current provider APIs; consult your provider accounts.

## Deployment and backups

This is a single-operator application, not a multi-tenant service. Initialize your password locally before public deployment, use HTTPS behind a trusted reverse proxy, and restrict administrative access. `EDITH_PUBLIC_URL` must be the exact HTTPS origin seen by Twilio/Google. Session cookies become Secure for an HTTPS origin. The optional `EDITH_BOOTSTRAP_TOKEN` is for an administrator-controlled bootstrap client; the normal browser setup is local.

Example supervised web/scheduler service files are in `deploy/`; adapt the Node executable and working directories to your server. Keep the web process and scheduler independently restartable. Do not use the optional Mac/Windows launchers for public hosting; they are legacy local launchers and were not executed on those platforms.

Back up `prisma/edith.db` with an SQLite-safe backup method, private document storage, and `.edith-runtime/master.key` together. That key encrypts OAuth tokens and signs sessions/audio links. Protect it, preserve it across restarts, and do not rotate it without a migration/reauthorization plan. API secrets stay in the server environment; they are excluded from exports. Delete original documents only through the confirmed document action. Generated call audio is privately stored and accessible to the phone provider through expiring, signed URLs.

## Validation

```sh
npm run lint
npm test
npm run build
npm run typecheck
npm run test:e2e
```

Build before a type check on a fresh checkout to generate Next route types. Build and development mode both use `.next`; do not run them concurrently. Browser tests launch their own production server on port 3001, with a **separate** acceptance database and private storage under `.edith-runtime/`. The publicly known test password is used only by that isolated test database, never by the real workspace. Tests use system Chromium (`/usr/bin/chromium`); adjust that path to an installed Chromium on other systems.

The backend suite covers DST, actual clock/timezone answers, source parsing and public keyless headers, failed/rate-limited search behavior, private credential handling, authentic task persistence, original XLSX extraction/citations, reviewed task proposals, duplicate/uncertain scheduler jobs, verified call opt-in, signed callbacks, immediate disabling, and cancelled calendar events. External provider transports are mocked in automated tests. Browser tests exercise the real clock route and display links from a mocked search reply; the voice test plays mock provider WAV audio to validate the real audio-permission gesture, interruption, and greeting suppression. The managed cloud network returned HTTP 403 for live Tavily/DuckDuckGo/Wikipedia attempts during this update, so live web connectivity must be checked on your Mac. **Live ElevenLabs speech, real calls, push/email delivery, and Google authorization need your actual credentials and have not been claimed as verified.**
