self.addEventListener('push', event => {
  const data = event.data ? event.data.json() : {title:'E.D.I.T.H.',body:'You have a reminder.'};
  event.waitUntil(self.registration.showNotification(data.title, {body:data.body,data:{url:'/'},tag:data.id || undefined}));
});
self.addEventListener('notificationclick', event => {
  event.notification.close();
  event.waitUntil(self.clients.matchAll({type:'window'}).then(async clients => {
    const client = clients.find(c => new URL(c.url).origin === self.location.origin);
    if(client) return client.focus();
    return self.clients.openWindow('/');
  }));
});
