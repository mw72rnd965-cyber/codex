import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { cookieOptions, hashToken, newSession, passwordHash, passwordMatches, requestToken, sessionCookie } from "@/lib/auth";
import { apiError, checkOrigin, HttpError } from "@/lib/http";
export async function GET() { return Response.json({ initialized: !!await db.operator.findUnique({ where: { id: "local" } }) }, { headers: { "Cache-Control": "no-store" } }); }
export async function POST(request: Request) {
  try {
    checkOrigin(request);
    const { password, action } = z.object({ password: z.string().min(12).max(200), action: z.enum(["setup", "signin"]) }).parse(await request.json());
    const attempts = await db.authAttempt.upsert({ where: { id: "local" }, create: {}, update: {} });
    if (attempts.blockedUntil && attempts.blockedUntil > new Date()) throw new HttpError("Too many attempts. Try again in fifteen minutes.", 429);
    const operator = await db.operator.findUnique({ where: { id: "local" } });
    if (!operator) {
      if (action !== "setup") throw new HttpError("Create your private workspace password first.");
      // Bootstrap is permitted only through a local URL, or with an administrator-provided bootstrap token.
      const host = new URL(request.url).hostname;
      const bootstrap = request.headers.get("x-edith-bootstrap");
      if ((process.env.EDITH_PUBLIC_URL || !["localhost", "127.0.0.1", "::1", "[::1]"].includes(host)) && (!process.env.EDITH_BOOTSTRAP_TOKEN || bootstrap !== process.env.EDITH_BOOTSTRAP_TOKEN)) throw new HttpError("An administrator must initialize this workspace locally before remote sign-in.", 403);
      await db.operator.create({ data: { id: "local", passwordHash: passwordHash(password) } });
    } else if (action === "setup" || !passwordMatches(password, operator.passwordHash)) {
      const failed = await db.authAttempt.update({ where: { id: "local" }, data: { failures: { increment: 1 } } });
      if (failed.failures >= 5) await db.authAttempt.update({ where: { id: "local" }, data: { blockedUntil: new Date(Date.now() + 15 * 60000) } });
      throw new HttpError("The password was not accepted.", 401);
    }
    await db.authAttempt.update({ where: { id: "local" }, data: { failures: 0, blockedUntil: null } });
    const response = NextResponse.json({ ok: true });
    response.cookies.set(sessionCookie, await newSession(), cookieOptions());
    return response;
  } catch (error) { return apiError(error); }
}
export async function DELETE(request: Request) {
  try {
    checkOrigin(request);
    const token = requestToken(request)?.split(".")[0];
    if (token) await db.authSession.deleteMany({ where: { tokenHash: hashToken(token) } });
    const response = NextResponse.json({ ok: true });
    response.cookies.set(sessionCookie, "", { ...cookieOptions(), maxAge: 0 });
    return response;
  } catch (error) { return apiError(error); }
}
