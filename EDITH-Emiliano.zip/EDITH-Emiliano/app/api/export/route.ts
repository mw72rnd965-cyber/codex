import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { apiError } from "@/lib/http";
export async function GET(request: Request) {
  try {
    await requireAuth(request); const url = new URL(request.url), noteId = url.searchParams.get("note");
    if (noteId) { const note = await db.note.findUniqueOrThrow({ where: { id: noteId } }); return new Response(`# ${note.title}\n\n${note.content}`, { headers: { "Content-Type": "text/markdown; charset=utf-8", "Content-Disposition": "attachment; filename=edith-draft.md", "Cache-Control": "private, no-store" } }); }
    const [settings, tasks, projects, notes, memories, reminders, events, conversations, documents, callSchedule, callHistory, notifications, proposals] = await Promise.all([db.userSettings.findMany(), db.task.findMany(), db.project.findMany(), db.note.findMany(), db.memory.findMany(), db.reminder.findMany(), db.calendarEvent.findMany(), db.conversation.findMany({ include: { messages: true } }), db.knowledgeFile.findMany({ select: { id: true, name: true, content: true, extractionWarning: true, chunks: { select: { content: true, locator: true } } } }), db.callSchedule.findMany(), db.callRecord.findMany({ select: { id: true, phone: true, status: true, duration: true, briefing: true, consent: true, error: true, createdAt: true } }), db.notification.findMany(), db.systemSetting.findMany({ where: { key: { startsWith: "document.proposals:" } } })]);
    return new Response(JSON.stringify({ exportedAt: new Date().toISOString(), settings, tasks, projects, notes, memories, reminders, events, conversations, documents, callSchedule, callHistory, notifications, proposals }, null, 2), { headers: { "Content-Type": "application/json", "Content-Disposition": "attachment; filename=edith-personal-data.json", "Cache-Control": "private, no-store" } });
  } catch (error) { return apiError(error); }
}
