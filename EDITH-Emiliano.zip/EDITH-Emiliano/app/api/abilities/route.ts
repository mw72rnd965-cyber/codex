import { apiError } from "@/lib/http";
import { requireAuth } from "@/lib/auth";
import {db} from '@/lib/db';
import {checkOrigin} from '@/lib/http';
import {ensureTimerWorker,createTimer} from '@/lib/abilities/timers';
import {phoneConfigured,phoneSettings,makeNotificationCall} from '@/lib/abilities/phone';
import {analyzeFiles,VISION_MODEL} from '@/lib/abilities/analysis';
import {chooseFolder,ensureFolderWorker,folderStatus,scanFolder} from '@/lib/abilities/folder';
export const runtime='nodejs';
export const dynamic='force-dynamic';
export async function GET(request:Request){
 try{
 await requireAuth(request);
 ensureTimerWorker();ensureFolderWorker();
 const [timers,phone,folder]=await Promise.all([db.timer.findMany({where:{status:{in:['WAITING','RINGING']}},orderBy:{dueAt:'asc'}}),phoneSettings(),folderStatus()]);
 return Response.json({timers,phone:{...phone,configured:phoneConfigured()},folder,visionModel:VISION_MODEL,nativeFolderChooser:['darwin','win32'].includes(process.platform)});
 }catch(error){return apiError(error);}
}
export async function POST(request:Request){
 try {
  await requireAuth(request);
    checkOrigin(request);ensureTimerWorker();ensureFolderWorker();
  const data=await request.json();
  if(data.action==='timer')return Response.json(await createTimer(data));
  if(data.action==='dismiss-timer'){await db.timer.update({where:{id:String(data.id)},data:{status:'DISMISSED'}});return Response.json({ok:true});}
  if(data.action==='phone-settings'){
   throw new Error('Manage verified phone numbers in Daily calls.');

  }
  if(data.action==='test-call'&&data.confirmed!==true)throw new Error('Confirm the real call in Daily calls first.');
  if(data.action==='test-call')return Response.json(await makeNotificationCall('Hello. This is EDITH. Your phone notification test is successful.'));
  if(data.action==='analyze')return Response.json(await analyzeFiles(data));
  if(data.action==='choose-folder')return Response.json(await chooseFolder());
  if(data.action==='scan-folder'){await scanFolder();return Response.json(await folderStatus());}
  if(data.action==='unlink-folder'){await db.systemSetting.deleteMany({where:{key:{in:['documents.folder','documents.folder.manifest']}}});return Response.json({ok:true});}
  throw new Error('Unknown ability.');
 }catch(error){return Response.json({error:error instanceof Error?error.message:'Ability failed.'},{status:400});}
}
