import { externalContextAllowed } from "@/lib/privacy";
import { disableCalls } from "@/lib/integrations/phone";
import { parseNaturalTask, saveTask } from "@/lib/organization";
import { requireAuth } from "@/lib/auth";
import { chatAbility } from "@/lib/abilities/chat";
import { greetingReply, directAnswerTokens } from "@/lib/ai/replies";
import { getModelConfiguration } from "@/lib/ai/config";
import { db } from "@/lib/db";
import { chatInput } from "@/lib/validation";
import { getContext, event, initialize } from "@/lib/service";
import {
  getProvider,
  providerConfigured,
  type AIMessage,
} from "@/lib/ai/provider";
import { apiError, checkOrigin, HttpError } from "@/lib/http";
export async function POST(request: Request) {
  try {
    await requireAuth(request);
    checkOrigin(request);
    const input = chatInput.parse(await request.json());
    await initialize();
    const conversation = input.conversationId
      ? await db.conversation.findUniqueOrThrow({
          where: { id: input.conversationId },
        })
      : await db.conversation.create({
          data: { title: input.prompt.slice(0, 70) },
        });
    const history = await db.message.findMany({
      where: { conversationId: conversation.id },
      orderBy: { createdAt: "desc" },
      take: 12,
    });
    await db.message.create({
      data: {
        conversationId: conversation.id,
        role: "user",
        content: input.prompt,
      },
    });
    await event("QUERY RECEIVED");
    const settings = await db.userSettings.findUnique({where:{id:"local"}});
    let actionResponse = greetingReply(input.prompt, settings?.displayName) ?? "";
    if (/^stop calling me[.!]?$/i.test(input.prompt.trim())) { await disableCalls(); actionResponse = "Scheduled calls are disabled."; }
    if (!actionResponse) {
      const pendingKey = "task.pending:" + conversation.id;
      const pending = await db.systemSetting.findUnique({ where: { key: pendingKey } });
      const isTimeReply = /^(?:at\s+)?(?:\d{1,2}(?::\d{2})?\s*(?:am|pm)|(?:[01]?\d|2[0-3]):[0-5]\d)[.!]?$/i.test(input.prompt.trim());
      const draft = pending && isTimeReply ? JSON.parse(pending.value) as { title: string; date: string; projectId?: string } : null;
      const taskPrompt = draft ? `remind me to ${draft.title} on ${draft.date} at ${input.prompt.replace(/^at\s+/i, "")}` : input.prompt;
      const parsed = parseNaturalTask(taskPrompt, settings?.timezone ?? "Europe/Helsinki", new Date(), await db.project.findMany({ select: { id: true, title: true } }));
      if (parsed?.pending) await db.systemSetting.upsert({ where: { key: pendingKey }, create: { key: pendingKey, value: JSON.stringify(parsed.pending) }, update: { value: JSON.stringify(parsed.pending) } });
      if (parsed?.question) actionResponse = parsed.question + " You can also use the task editor to set an exact deadline.";
      else if (parsed?.task) {
        await db.systemSetting.deleteMany({ where: { key: pendingKey } });
        const task = await saveTask({ ...parsed.task, projectId: draft?.projectId ?? parsed.task.projectId, reminderMinutes: parsed.task.dueDate ? settings?.reminderLeadMinutes ?? 15 : undefined });
        actionResponse = `Task saved: ${task.title}.${task.dueDate ? ` Due ${task.dueDate.toLocaleString("en-GB", { timeZone: settings?.timezone ?? "Europe/Helsinki" })}. An in-app reminder was scheduled; delivery depends on the backend scheduler.` : " No deadline has been set."}`;
      }
    }
    if(!actionResponse)actionResponse=await chatAbility(input.prompt) ?? "";
    const remember = input.prompt.match(/^remember(?: that)?\s+(.+)/i);
    if (remember) {
      const settings = await db.userSettings.findUnique({
        where: { id: "local" },
      });
      if (settings?.memoryEnabled) {
        await db.memory.create({
          data: {
            title: remember[1].slice(0, 100),
            content: remember[1],
            category: "CUSTOM",
          },
        });
        await event("MEMORY CREATED");
        actionResponse = `I've stored this in long-term memory: ${remember[1]}`;
      } else
        actionResponse =
          "Memory is disabled. Enable it in Settings before storing this.";
    }
    const context = await getContext(input.prompt);
    await event("MEMORY SEARCH COMPLETE");
    const modelConfig = await getModelConfiguration();
    const sendContext =
      !providerConfigured(modelConfig) ||
      modelConfig.provider === "local" ||
      await externalContextAllowed()
        ? context
        : { memories: [], knowledge: [], tasks: [], sources: [] };
    const messages: AIMessage[] = [
      ...history.reverse().filter(m => m.role !== "assistant" || !/^(?:Okay,? the user|The user (?:said|is asking)|I need to respond as EDITH)/i.test(m.content)).map((m) => ({
        role: m.role as "user" | "assistant",
        content: m.content,
      })),
      { role: "user", content: input.prompt },
    ];
    const encoder = new TextEncoder();
    const stream = new ReadableStream({
      async start(controller) {
        const send = (data: object) =>
          controller.enqueue(encoder.encode(JSON.stringify(data) + "\n"));
        let content = "";
        try {
          send({
            type: "meta",
            conversationId: conversation.id,
            sources: sendContext.sources,
            memoryCount: sendContext.memories.length,
          });
          await event("CONTEXT ASSEMBLED");
          if (actionResponse) {
            content = actionResponse;
            send({ type: "token", content });
          } else
            for await (const token of directAnswerTokens(getProvider(modelConfig).stream(
              messages,
              sendContext,
            ))) {
              content += token;
              send({ type: "token", content: token });
            }
          await db.message.create({
            data: {
              conversationId: conversation.id,
              role: "assistant",
              content,
            },
          });
          await db.conversation.update({
            where: { id: conversation.id },
            data: { updatedAt: new Date() },
          });
          await event("RESPONSE COMPLETE");
          send({ type: "done" });
        } catch (error) {
          await event("MODEL CONNECTION INTERRUPTED");
          send({
            type: "error",
            error:
              error instanceof HttpError ? error.message : "Model connection interrupted. Check your server configuration and retry.",
          });
        } finally {
          controller.close();
        }
      },
    });
    return new Response(stream, {
      headers: {
        "Content-Type": "application/x-ndjson",
        "Cache-Control": "no-cache",
      },
    });
  } catch (error) {
    return apiError(error);
  }
}
