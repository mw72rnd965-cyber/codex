import { z } from "zod";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { apiError, checkOrigin, HttpError } from "@/lib/http";
import { initialize } from "@/lib/service";
import { configuration, integrationStatus } from "@/lib/integrations/status";
import { cancelReminderJobs, dailyBriefing, queueReminder, saveTask } from "@/lib/organization";
import { localDateTime, validTimezone } from "@/lib/time";
import { settingsInput, noteInput, memoryInput } from "@/lib/validation";
import { disableCalls, startCall, verifyPhone } from "@/lib/integrations/phone";
import { calendarAuthorization, calendarChoices, google, retainSelectedCalendars, syncCalendar } from "@/lib/integrations/calendar";
import { getModelConfiguration } from "@/lib/ai/config";
import { getProvider, providerConfigured } from "@/lib/ai/provider";
const idSchema = z.string().min(1).max(200);
export async function GET(request: Request) {
  try {
    await requireAuth(request); await initialize();
    const [settings, tasks, projects, events, reminders, jobs, notifications, notes, memories, documents, conversations, calls, callSchedule, integrations, briefing, proposalRows] = await Promise.all([
      db.userSettings.findUniqueOrThrow({ where: { id: "local" } }), db.task.findMany({ orderBy: { createdAt: "desc" } }), db.project.findMany(),
      db.calendarEvent.findMany({ where: { cancelled: false }, orderBy: { startAt: "asc" } }), db.reminder.findMany({ orderBy: { dueAt: "asc" } }),
      db.scheduledJob.findMany({ orderBy: { updatedAt: "desc" }, take: 100 }), db.notification.findMany({ orderBy: { createdAt: "desc" }, take: 50 }), db.note.findMany({ orderBy: { updatedAt: "desc" } }), db.memory.findMany(),
      db.knowledgeFile.findMany({ select: { id: true, name: true, mimeType: true, extractionWarning: true, createdAt: true, _count: { select: { chunks: true } } }, orderBy: { createdAt: "desc" } }),
      db.conversation.findMany({ include: { messages: { orderBy: { createdAt: "asc" } } }, orderBy: { updatedAt: "desc" }, take: 30 }),
      db.callRecord.findMany({ select: { id: true, status: true, duration: true, error: true, consent: true, createdAt: true }, orderBy: { createdAt: "desc" }, take: 50 }),
      db.callSchedule.upsert({ where: { id: "local" }, create: {}, update: {} }), integrationStatus(), dailyBriefing(), db.systemSetting.findMany({ where: { key: { startsWith: "document.proposals:" } } }),
    ]);
    return Response.json({ settings, tasks, projects, events, reminders, jobs, notifications, notes, memories, documents, conversations, calls, callSchedule, integrations, briefing, proposals: proposalRows.map(row => ({ noteId: row.key.slice("document.proposals:".length), ...JSON.parse(row.value) })) }, { headers: { "Cache-Control": "private, no-store" } });
  } catch (error) { return apiError(error); }
}
export async function POST(request: Request) {
  try {
    await requireAuth(request); checkOrigin(request);
    const input = await request.json();
    const action = z.string().parse(input.action);
    let result: unknown = { ok: true };
    if (action === "task-save") result = await saveTask(input, input.id ? idSchema.parse(input.id) : undefined);
    else if (action === "task-delete") {
      const id = idSchema.parse(input.id);
      const reminders = await db.reminder.findMany({ where: { taskId: id } });
      await cancelReminderJobs(reminders.map(r => r.id));
      await db.reminder.updateMany({ where: { taskId: id }, data: { active: false } });
      await db.task.updateMany({ where: { parentId: id }, data: { parentId: null } });
      await db.task.delete({ where: { id } });
    } else if (action === "project-save") {
      const data = z.object({ title: z.string().trim().min(1).max(200), description: z.string().max(20000).default(""), color: z.enum(["cyan", "violet", "amber"]).default("cyan") }).parse(input);
      result = input.id ? await db.project.update({ where: { id: idSchema.parse(input.id) }, data }) : await db.project.create({ data });
    } else if (action === "project-delete") {
      const id = idSchema.parse(input.id); await db.task.updateMany({ where: { projectId: id }, data: { projectId: null } }); await db.project.delete({ where: { id } });
    } else if (action === "event-save") {
      const data = z.object({ title: z.string().trim().min(1).max(200), description: z.string().max(20000).default(""), startAt: z.string().datetime(), endAt: z.string().datetime(), reminderMinutes: z.number().int().min(0).max(10080).optional() }).parse(input);
      if (new Date(data.endAt) <= new Date(data.startAt)) throw new HttpError("An appointment must end after it starts.");
      const { reminderMinutes, ...values } = data;
      if (input.id && (await db.calendarEvent.findUniqueOrThrow({ where: { id: idSchema.parse(input.id) } })).source !== "local") throw new HttpError("Edit connected events in their calendar provider; external modifications require explicit confirmation.");
      const event = input.id ? await db.calendarEvent.update({ where: { id: input.id }, data: values }) : await db.calendarEvent.create({ data: values });
      const old = await db.reminder.findMany({ where: { eventId: event.id } }); await cancelReminderJobs(old.map(r => r.id)); await db.reminder.updateMany({ where: { eventId: event.id }, data: { active: false } });
      if (reminderMinutes !== undefined) {
        const settings = await db.userSettings.findUniqueOrThrow({ where: { id: "local" } }); const dueAt = new Date(event.startAt.getTime() - reminderMinutes * 60000);
        const reminder = await db.reminder.create({ data: { title: event.title, dueAt, timezone: settings.timezone, eventId: event.id } }); await queueReminder(reminder.id, dueAt, ["inapp"]);
      }
      result = event;
    } else if (action === "event-delete") {
      const id = idSchema.parse(input.id), event = await db.calendarEvent.findUniqueOrThrow({ where: { id } });
      if (event.source !== "local") throw new HttpError("Cancel this appointment through the connected calendar; it cannot be silently deleted remotely.");
      await db.calendarEvent.update({ where: { id }, data: { cancelled: true } }); const reminders = await db.reminder.findMany({ where: { eventId: id } }); await cancelReminderJobs(reminders.map(r => r.id)); await db.reminder.updateMany({ where: { eventId: id }, data: { active: false } });
    } else if (action === "reminder-save") {
      const data = z.object({ title: z.string().trim().min(1).max(200), dueAt: z.string().datetime(), timezone: z.string().refine(validTimezone), recurrence: z.enum(["none", "daily", "weekly", "monthly"]).default("none"), channels: z.array(z.enum(["inapp", "push", "email", "sms"])).min(1).max(4), taskId: idSchema.nullable().optional(), eventId: idSchema.nullable().optional() }).parse(input);
      if (data.taskId && !await db.task.findUnique({ where: { id: data.taskId } })) throw new HttpError("The linked task is missing.");
      if (data.eventId && !await db.calendarEvent.findUnique({ where: { id: data.eventId } })) throw new HttpError("The linked appointment is missing.");
      const config = configuration();
      for (const channel of data.channels) if (channel !== "inapp" && config[channel].missing.length) throw new HttpError(`${channel} needs ${config[channel].missing.join(", ")}. Choose in-app until it is configured.`);
      if (data.channels.includes("sms") && !(await db.callSchedule.findUnique({ where: { id: "local" } }))?.verifiedAt) throw new HttpError("Verify your phone number before selecting SMS.");
      if (data.channels.includes("push") && !await db.pushSubscription.count()) throw new HttpError("Enable browser notifications before selecting push.");
      const values = { ...data, channels: JSON.stringify([...new Set(data.channels)]), active: true };
      if (input.id) await cancelReminderJobs([idSchema.parse(input.id)]);
      const reminder = input.id ? await db.reminder.update({ where: { id: input.id }, data: values }) : await db.reminder.create({ data: values });
      await queueReminder(reminder.id, reminder.dueAt, data.channels); result = reminder;
    } else if (action === "reminder-cancel") {
      const id = idSchema.parse(input.id); await db.reminder.update({ where: { id }, data: { active: false } }); await cancelReminderJobs([id]);
    } else if (action === "reminder-snooze") {
      const minutes = z.number().int().min(1).max(1440).parse(input.minutes); const reminder = await db.reminder.findUniqueOrThrow({ where: { id: idSchema.parse(input.id) } });
      if (!reminder.active) throw new HttpError("This reminder is cancelled.");
      await cancelReminderJobs([reminder.id]); const dueAt = new Date(Date.now() + minutes * 60000); await db.reminder.update({ where: { id: reminder.id }, data: { dueAt } }); await queueReminder(reminder.id, dueAt, JSON.parse(reminder.channels));
    } else if (action === "preferences-save") result = await db.userSettings.update({ where: { id: "local" }, data: settingsInput.parse(input) });
    else if (action === "note-save") result = input.id ? await db.note.update({ where: { id: idSchema.parse(input.id) }, data: noteInput.parse(input) }) : await db.note.create({ data: noteInput.parse(input) });
    else if (action === "note-delete") { await db.note.delete({ where: { id: idSchema.parse(input.id) } }); await db.systemSetting.deleteMany({ where: { key: "document.proposals:" + input.id } }); }
    else if (action === "memory-save") result = input.id ? await db.memory.update({ where: { id: idSchema.parse(input.id) }, data: memoryInput.parse(input) }) : await db.memory.create({ data: memoryInput.parse(input) });
    else if (action === "memory-delete") await db.memory.delete({ where: { id: idSchema.parse(input.id) } });
    else if (action === "phone-save") {
      const data = z.object({ phone: z.string().regex(/^\+[1-9]\d{6,14}$/).or(z.literal("")), enabled: z.boolean(), paused: z.boolean(), localTime: z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/), timezone: z.string().refine(validTimezone), days: z.array(z.number().int().min(1).max(7)).min(1).max(7), topics: z.array(z.enum(["appointments", "tasks", "deadlines"])).min(1).max(3), maxDuration: z.number().int().min(60).max(600), voicemail: z.enum(["none", "generic"]) }).parse(input);
      const old = await db.callSchedule.findUnique({ where: { id: "local" } }); const samePhone = old?.phone === data.phone;
      if (data.enabled && (!samePhone || !old?.verifiedAt)) throw new HttpError("Verify the saved number before opting into daily calls.");
      if (data.enabled && configuration().calls.missing.length) throw new HttpError("Calling needs: " + configuration().calls.missing.join(", ") + ".");
      await db.scheduledJob.updateMany({ where: { kind: "DAILY_CALL", status: "WAITING" }, data: { status: "CANCELLED" } });
      result = await db.callSchedule.upsert({ where: { id: "local" }, create: { ...data, days: JSON.stringify(data.days), topics: JSON.stringify(data.topics) }, update: { ...data, days: JSON.stringify(data.days), topics: JSON.stringify(data.topics), ...(!samePhone ? { verifiedAt: null } : {}) } });
    } else if (action === "calls-disable") await disableCalls();
    else if (action === "calls-pause") await disableCalls(true);
    else if (action === "phone-verify-send") {
      if (input.confirmed !== true) throw new HttpError("Confirm the SMS verification request first.");
      const old = await db.systemSetting.findUnique({ where: { key: "phone.verify.last" } }); if (old && Date.now() - Number(old.value) < 60000) throw new HttpError("Wait one minute before requesting another verification code.", 429);
      await db.systemSetting.upsert({ where: { key: "phone.verify.last" }, create: { key: "phone.verify.last", value: String(Date.now()) }, update: { value: String(Date.now()) } }); result = await verifyPhone();
    } else if (action === "phone-verify-check") result = await verifyPhone(z.string().regex(/^\d{4,10}$/).parse(input.code));
    else if (action === "call-test") { if (input.confirmed !== true) throw new HttpError("Confirm the real test call before placing it."); result = await startCall(); }
    else if (action === "notification-read") await db.notification.update({ where: { id: idSchema.parse(input.id) }, data: { read: true } });
    else if (action === "push-subscribe") {
      const subscription = z.object({ endpoint: z.string().url(), expirationTime: z.number().nullable().optional(), keys: z.object({ p256dh: z.string().min(10).max(300), auth: z.string().min(10).max(100) }) }).parse(input.subscription);
      const url = new URL(subscription.endpoint);
      if (url.protocol !== "https:" || url.port || !["fcm.googleapis.com", "updates.push.services.mozilla.com", "web.push.apple.com"].includes(url.hostname) && !url.hostname.endsWith(".notify.windows.com")) throw new HttpError("Unsupported push service endpoint.");
      await db.pushSubscription.upsert({ where: { endpoint: subscription.endpoint }, create: { endpoint: subscription.endpoint, value: JSON.stringify(subscription) }, update: { value: JSON.stringify(subscription) } });
    } else if (action === "push-disconnect") await db.pushSubscription.deleteMany();
    else if (action === "proposals-accept") {
      const noteId = idSchema.parse(input.noteId), indexes = z.array(z.number().int().min(0).max(9)).min(1).max(10).parse(input.indexes);
      result = await db.$transaction(async tx => {
        const row = await tx.systemSetting.findUniqueOrThrow({ where: { key: "document.proposals:" + noteId } }); const data = JSON.parse(row.value) as { tasks: { title: string; description: string }[]; accepted: number[] };
        const saved = []; for (const index of [...new Set(indexes)]) { if (!data.tasks[index] || data.accepted.includes(index)) continue; saved.push(await tx.task.create({ data: { ...data.tasks[index], prioritySource: "suggestion" } })); data.accepted.push(index); }
        await tx.systemSetting.update({ where: { key: row.key }, data: { value: JSON.stringify(data) } }); return { saved };
      });
    } else if (action === "calendar-connect") result = { url: await calendarAuthorization(z.boolean().parse(input.writable)) };
    else if (action === "calendar-list") result = { calendars: await calendarChoices() };
    else if (action === "calendar-select") {
      const ids = z.array(z.string()).min(1).max(20).parse(input.ids), available = await calendarChoices(); const selected = available.filter(c => ids.includes(c.id));
      if (selected.length !== new Set(ids).size) throw new HttpError("Some selected calendars are unavailable.");
      await retainSelectedCalendars(ids); await db.calendarConnection.update({ where: { id: "google" }, data: { calendars: JSON.stringify(selected) } }); result = await syncCalendar();
    } else if (action === "calendar-sync") result = await syncCalendar();
    else if (action === "calendar-disconnect") { await retainSelectedCalendars([]); await db.calendarConnection.deleteMany(); await db.systemSetting.deleteMany({ where: { key: "calendar.oauth" } }); }
    else if (action === "calendar-create") {
      if (input.confirmed !== true) throw new HttpError("Confirm the exact appointment before writing to your calendar.");
      const data = z.object({ calendarId: idSchema, title: z.string().trim().min(1).max(200), startAt: z.string().datetime(), endAt: z.string().datetime() }).parse(input);
      if (new Date(data.endAt) <= new Date(data.startAt)) throw new HttpError("The appointment must end after it starts.");
      const connection = await db.calendarConnection.findUniqueOrThrow({ where: { id: "google" } });
      const selected = JSON.parse(connection.calendars) as { id: string; accessRole: string }[];
      if (!connection.writable || !selected.some(c => c.id === data.calendarId && ["owner", "writer"].includes(c.accessRole))) throw new HttpError("This calendar has not been authorized for modifications.", 403);
      result = await google(`calendars/${encodeURIComponent(data.calendarId)}/events`, { method: "POST", body: JSON.stringify({ summary: data.title, start: { dateTime: data.startAt }, end: { dateTime: data.endAt } }) }); await syncCalendar();
    } else if (action === "privacy-context") {
      const enabled = z.boolean().parse(input.enabled); await db.systemSetting.upsert({ where: { key: "privacy.externalContext" }, create: { key: "privacy.externalContext", value: String(enabled) }, update: { value: String(enabled) } });
    } else if (action === "ai-test") {
      const config = await getModelConfiguration(); if (!providerConfigured(config)) throw new HttpError("Configure a real model before testing its connection.");
      const answer = await getProvider(config).generate([{ role: "user", content: "Reply with online." }], { memories: [], knowledge: [], tasks: [], sources: [] }); if (!answer.trim()) throw new HttpError("The model returned an empty response.", 503); result = { ok: true, status: "Provider responded." };
    } else if (action === "local-time") result = { instant: localDateTime(z.string().parse(input.value), z.string().refine(validTimezone).parse(input.timezone)).toISOString() };
    else throw new HttpError("Unknown workspace action.");
    return Response.json(result);
  } catch (error) { return apiError(error); }
}
