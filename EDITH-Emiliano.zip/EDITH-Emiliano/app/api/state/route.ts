import { apiError } from "@/lib/http";
import { externalContextAllowed } from "@/lib/privacy";
import { requireAuth } from "@/lib/auth";
import { ensureTimerWorker } from "@/lib/abilities/timers";
import { ensureFolderWorker } from "@/lib/abilities/folder";
import { db } from "@/lib/db";
import { initialize } from "@/lib/service";
import {
  configurationName,
  getModelConfiguration,
  localModelStatus,
  voiceStatus,
} from "@/lib/ai/config";
export const dynamic = "force-dynamic";
export async function GET(request: Request) {
 try {
  await requireAuth(request);
  await initialize();
  ensureTimerWorker();ensureFolderWorker();
  const [memories, tasks, notes, knowledge, conversations, activity, settings] =
    await Promise.all([
      db.memory.findMany({ orderBy: { createdAt: "desc" } }),
      db.task.findMany({ orderBy: { createdAt: "desc" } }),
      db.note.findMany({
        orderBy: [{ pinned: "desc" }, { updatedAt: "desc" }],
      }),
      db.knowledgeFile.findMany({
        select: {
          id: true,
          name: true,
          createdAt: true,
          _count: { select: { chunks: true } },
        },
        orderBy: { createdAt: "desc" },
      }),
      db.conversation.findMany({
        include: { messages: { orderBy: { createdAt: "asc" } } },
        orderBy: { updatedAt: "desc" },
        take: 30,
      }),
      db.activityEvent.findMany({ orderBy: { createdAt: "desc" }, take: 30 }),
      db.userSettings.findUnique({ where: { id: "local" } }),
    ]);
  const [config, localModel, voice] = await Promise.all([
    getModelConfiguration(),
    localModelStatus(),
    voiceStatus(),
  ]);
  return Response.json({
    memories,
    tasks,
    notes,
    knowledge,
    conversations,
    activity,
    settings,
    provider: config.provider,
    model: configurationName(config),
    localModel,
    voice,
    externalContext: await externalContextAllowed(),
  });
 } catch (error) { return apiError(error); }
}
