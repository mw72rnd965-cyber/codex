import { saveTask, cancelReminderJobs } from "@/lib/organization";
import { requireAuth } from "@/lib/auth";
import { importFile } from "@/lib/abilities/documents";
import { getModelConfiguration, setModelMode } from "@/lib/ai/config";
import { MemoryService } from "@/lib/memory/service";
import { db } from "@/lib/db";
import { event } from "@/lib/service";
import { apiError, checkOrigin } from "@/lib/http";
import { noteInput, settingsInput } from "@/lib/validation";
type Context = { params: Promise<{ kind: string }> };
export async function POST(req: Request, ctx: Context) {
  try {
    await requireAuth(req);
    checkOrigin(req);
    const { kind } = await ctx.params;
    if (kind === "knowledge") {
      const form = await req.formData();
      const file = form.get("file");
      if (!(file instanceof File))
        throw new Error("Invalid file");
      const row = await importFile(file);
      await event("KNOWLEDGE INDEXED");
      return Response.json(row);
    }
    const body = await req.json();
    let row;
    if (kind === "memory") row = await MemoryService.createMemory(body);
    else if (kind === "tasks") {
      row = await saveTask(body);
    } else if (kind === "notes")
      row = await db.note.create({ data: noteInput.parse(body) });
    else if (kind === "settings")
      row = await db.userSettings.upsert({
        where: { id: "local" },
        update: settingsInput.parse(body),
        create: { id: "local", ...settingsInput.parse(body) },
      });
    else if (kind === "model") {
      if (body.mode !== "local" && body.mode !== "mock")
        throw new Error("Invalid model selection");
      await setModelMode(body.mode);
      await event("MODEL MODE UPDATED");
      return Response.json({ ok: true });
    } else if (kind === "provider-test") {
      const { getProvider } = await import("@/lib/ai/provider");
      await getProvider(await getModelConfiguration()).generate(
        [{ role: "user", content: "Respond with online." }],
        { memories: [], knowledge: [], tasks: [], sources: [] },
      );
      return Response.json({ ok: true });
    } else throw new Error("Unknown collection");
    await event(`${kind.toUpperCase()} SAVED`);
    return Response.json(row);
  } catch (error) {
    return apiError(error);
  }
}
export async function PATCH(req: Request, ctx: Context) {
  try {
    await requireAuth(req);
    checkOrigin(req);
    const { kind } = await ctx.params;
    const { id, ...body } = await req.json();
    if (typeof id !== "string") throw new Error("Missing ID");
    let row;
    if (kind === "memory") row = await MemoryService.updateMemory(id, body);
    else if (kind === "tasks") {
      row = await saveTask(body, id);
    } else if (kind === "notes")
      row = await db.note.update({
        where: { id },
        data: noteInput.parse(body),
      });
    else throw new Error("Unknown collection");
    await event(`${kind.toUpperCase()} UPDATED`);
    return Response.json(row);
  } catch (error) {
    return apiError(error);
  }
}
export async function DELETE(req: Request, ctx: Context) {
  try {
    await requireAuth(req);
    checkOrigin(req);
    const { kind } = await ctx.params;
    const { id } = await req.json();
    if (typeof id !== "string") throw new Error("Missing ID");
    if (kind === "memory") await MemoryService.deleteMemory(id);
    else if (kind === "tasks") {
      const reminders = await db.reminder.findMany({ where: { taskId: id } });
      await cancelReminderJobs(reminders.map(r => r.id));
      await db.reminder.updateMany({ where: { taskId: id }, data: { active: false } });
      await db.task.delete({ where: { id } });
    }
    else if (kind === "notes") await db.note.delete({ where: { id } });
    else if (kind === "knowledge") throw new Error("Use the document deletion endpoint with explicit confirmation.");
    else if (kind === "conversations")
      await db.conversation.delete({ where: { id } });
    else throw new Error("Unknown collection");
    await event(`${kind.toUpperCase()} REMOVED`);
    return Response.json({ ok: true });
  } catch (error) {
    return apiError(error);
  }
}

export async function GET(req: Request, ctx: Context) {
  try {
    await requireAuth(req);
    const { kind } = await ctx.params;
    if (kind !== "knowledge") throw new Error("Unknown collection");
    const id = new URL(req.url).searchParams.get("id");
    if (!id) throw new Error("Missing ID");
    return Response.json(
      await db.knowledgeFile.findUniqueOrThrow({ where: { id } }),
    );
  } catch (error) {
    return apiError(error);
  }
}
