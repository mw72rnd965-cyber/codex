import { readCallAudio } from "@/lib/integrations/phone";
import { apiError } from "@/lib/http";
export async function GET(request: Request, context: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await context.params, url = new URL(request.url);
    const audio = await readCallAudio(id, url.searchParams.get("segment") ?? "", url.searchParams.get("token") ?? "");
    return new Response(new Uint8Array(audio), { headers: { "Content-Type": "audio/mpeg", "Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff" } });
  } catch (error) { return apiError(error); }
}
