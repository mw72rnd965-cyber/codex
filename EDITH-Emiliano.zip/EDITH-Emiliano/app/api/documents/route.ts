import { readFile, rm } from "node:fs/promises";
import { resolve } from "node:path";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { privateRoot } from "@/lib/security/keys";
import { apiError, checkOrigin, HttpError } from "@/lib/http";
import { importFile } from "@/lib/abilities/documents";
import { analyzeFiles } from "@/lib/abilities/analysis";
import { z } from "zod";
export async function GET(request: Request) {
  try {
    await requireAuth(request); const url = new URL(request.url), id = url.searchParams.get("id"); if (!id) throw new HttpError("Select a document.");
    const file = await db.knowledgeFile.findUniqueOrThrow({ where: { id }, include: { chunks: { orderBy: { position: "asc" } } } });
    if (url.searchParams.get("mode") === "original") {
      if (!file.storageKey || !/^[\w-]+$/.test(file.storageKey)) throw new HttpError("The original file is unavailable for this older import.", 404);
      const original = await readFile(resolve(privateRoot(), "documents", file.storageKey));
      return new Response(new Uint8Array(original), { headers: { "Content-Type": file.mimeType, "Content-Disposition": `attachment; filename="${file.name}"`, "Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff" } });
    }
    return Response.json({ id: file.id, name: file.name, content: file.content, warning: file.extractionWarning, sections: file.chunks.map(c => ({ locator: c.locator, content: c.content })) });
  } catch (error) { return apiError(error); }
}
export async function POST(request: Request) {
  try {
    await requireAuth(request); checkOrigin(request);
    if (request.headers.get("content-type")?.includes("multipart/form-data")) {
      const form = await request.formData(), file = form.get("file"); if (!(file instanceof File)) throw new HttpError("Choose a file to upload."); return Response.json(await importFile(file));
    }
    return Response.json(await analyzeFiles(await request.json()));
  } catch (error) { return apiError(error); }
}
export async function DELETE(request: Request) {
  try {
    await requireAuth(request); checkOrigin(request);
    const input = z.object({ id: z.string(), confirmed: z.literal(true) }).parse(await request.json());
    const file = await db.knowledgeFile.findUniqueOrThrow({ where: { id: input.id } });
    if (file.storageKey && /^[\w-]+$/.test(file.storageKey)) await rm(resolve(privateRoot(), "documents", file.storageKey), { force: true });
    await db.knowledgeFile.delete({ where: { id: file.id } }); return Response.json({ ok: true });
  } catch (error) { return apiError(error); }
}
