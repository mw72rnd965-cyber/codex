import {z} from 'zod';
import {db} from '@/lib/db';
import {requireAuth} from '@/lib/auth';
import {apiError,checkOrigin,HttpError} from '@/lib/http';
import {elevenSpeech} from '@/lib/integrations/voice';
import {speechText} from '@/lib/voice/text';
export async function POST(request:Request){
 try{
  await requireAuth(request);checkOrigin(request);
  const input=z.object({text:z.string().trim().min(1).max(4000),engine:z.enum(['elevenlabs','kokoro']).optional(),voice:z.string().max(100).optional(),speed:z.number().min(.75).max(1.25).optional()}).parse(await request.json());
  const settings=await db.userSettings.findUnique({where:{id:'local'}});
  if((input.engine??settings?.voiceEngine??'elevenlabs')==='elevenlabs')return new Response(new Uint8Array(await elevenSpeech(input.text)),{headers:{'Content-Type':'audio/mpeg','Cache-Control':'private, no-store'}});
  const voice=input.voice??settings?.voiceId??'af_sarah';
  if(!['af_sarah','af_bella','af_heart','bf_emma'].includes(voice))throw new HttpError('Choose a supported Kokoro voice.');
  const response=await fetch('http://127.0.0.1:8881/speech',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text:speechText(input.text),voice,speed:input.speed??settings?.voiceRate??.94}),signal:AbortSignal.timeout(60000)});
  if(!response.ok)throw new HttpError('The local voice service is unavailable. Your text is preserved.',503);
  return new Response(response.body,{headers:{'Content-Type':'audio/wav','Cache-Control':'private, no-store'}});
 }catch(error){return apiError(error);}
}
