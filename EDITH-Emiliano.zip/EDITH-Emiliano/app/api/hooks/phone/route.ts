import { hashToken } from "@/lib/auth";
import { db } from "@/lib/db";
import { apiError, HttpError } from "@/lib/http";
import { audioUrl, disableCalls, publicUrl, verifyTwilioRequest } from "@/lib/integrations/phone";
import { cancelReminderJobs, parseNaturalTask, queueReminder, saveTask } from "@/lib/organization";
const escape = (value: string) => value.replace(/[&<>"']/g, character => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&apos;" })[character]!);
export async function POST(request: Request) {
  try {
    const form = new URLSearchParams(await request.text()); await verifyTwilioRequest(request, form);
    const url = new URL(request.url), id = url.searchParams.get("call"), stage = url.searchParams.get("stage");
    if (!id) throw new HttpError("Unknown call.", 404);
    const call = await db.callRecord.findUniqueOrThrow({ where: { id } });
    if (call.providerId && call.providerId !== form.get("CallSid")) throw new HttpError("Call identity mismatch.", 403);
    if (stage === "status") {
      const status = (form.get("CallStatus") ?? "unknown").toUpperCase();
      if (!["QUEUED", "INITIATED", "RINGING", "IN-PROGRESS", "COMPLETED", "BUSY", "FAILED", "NO-ANSWER", "CANCELED"].includes(status)) throw new HttpError("Invalid call status.");
      await db.callRecord.update({ where: { id }, data: { status, duration: form.get("CallDuration") ? Number(form.get("CallDuration")) : null } });
      return new Response("", { status: 204 });
    }
    const schedule = await db.callSchedule.findUniqueOrThrow({ where: { id: "local" } });
    const play = (segment: string) => `<Play>${escape(audioUrl(id, segment, call.expiresAt))}</Play>`;
    const gather = (segment: string, next: string) => `<Gather input="speech" language="en-US" timeout="6" speechTimeout="auto" action="${escape(publicUrl(`/api/hooks/phone?call=${id}&stage=${next}`))}" method="POST">${play(segment)}</Gather><Hangup/>`;
    let xml = "<Hangup/>";
    const spoken = (form.get("SpeechResult") ?? "").trim();
    if (/\bstop calling me\b|\bdisable (?:daily )?calls\b/i.test(spoken)) {
      await disableCalls(); xml = play("stopped") + "<Hangup/>";
    } else if (!schedule.enabled || schedule.paused || !schedule.verifiedAt || schedule.phone !== call.phone) xml = "<Hangup/>";
    else if (stage === "welcome") {
      const machine = form.get("AnsweredBy")?.startsWith("machine");
      xml = machine ? (schedule.voicemail === "generic" ? play("voicemail") : "") + "<Hangup/>" : gather("welcome", "consent");
    } else if (stage === "consent") {
      if (/\b(?:yes|okay|sure|good time|go ahead|ready)\b/i.test(spoken) && !/\b(?:no|not|later)\b/i.test(spoken)) {
        await db.callRecord.update({ where: { id }, data: { consent: true } }); xml = gather("briefing", "command");
      } else xml = play("goodbye") + "<Hangup/>";
    } else if (stage === "command" && call.consent) {
      const receiptKey = "call.command:" + id + ":" + hashToken(spoken.toLowerCase());
      const receipt = await db.systemSetting.findUnique({ where: { key: receiptKey } });
      if (receipt) return new Response(`<Response>${receipt.value === "PROCESSING" ? "<Hangup/>" : receipt.value}</Response>`, { headers: { "Content-Type": "text/xml" } });
      try { await db.systemSetting.create({ data: { key: receiptKey, value: "PROCESSING" } }); }
      catch { return new Response("<Response><Hangup/></Response>", { headers: { "Content-Type": "text/xml" } }); }
      const task = parseNaturalTask(spoken, schedule.timezone);
      if (task?.task) {
        const created = await saveTask({ ...task.task, reminderMinutes: task.task.dueDate ? 15 : undefined });
        await db.notification.create({ data: { title: "Task added during your call", body: created.title, channel: "inapp", status: "DELIVERED" } }); xml = play("success") + "<Hangup/>";
      } else {
        const snooze = spoken.match(/^snooze (?:the )?(.+?)(?: reminder)? for (\d+) minutes?[.!]?$/i);
        if (snooze && Number(snooze[2]) <= 1440 && Number(snooze[2]) > 0) {
          const reminders = await db.reminder.findMany({ where: { active: true, title: { equals: snooze[1].trim() } } });
          if (reminders.length === 1) {
            const reminder = reminders[0], dueAt = new Date(Date.now() + Number(snooze[2]) * 60000); await cancelReminderJobs([reminder.id]); await db.reminder.update({ where: { id: reminder.id }, data: { dueAt } }); await queueReminder(reminder.id, dueAt, JSON.parse(reminder.channels)); xml = play("success") + "<Hangup/>";
          } else xml = play("ambiguous") + "<Hangup/>";
        } else xml = play(task?.question ? "ambiguous" : "goodbye") + "<Hangup/>";
      }
    }
    if (stage === "command" && call.consent && !/\bstop calling me\b|\bdisable (?:daily )?calls\b/i.test(spoken)) {
      await db.systemSetting.updateMany({ where: { key: "call.command:" + id + ":" + hashToken(spoken.toLowerCase()) }, data: { value: xml } });
    }
    return new Response(`<?xml version="1.0" encoding="UTF-8"?><Response>${xml}</Response>`, { headers: { "Content-Type": "text/xml", "Cache-Control": "no-store" } });
  } catch (error) { return apiError(error); }
}
