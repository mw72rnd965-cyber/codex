import { requireAuth } from "@/lib/auth";
import { finishCalendarAuthorization } from "@/lib/integrations/calendar";
import { NextResponse } from "next/server";
export async function GET(request: Request) {
  try {
    await requireAuth(request);
    const url = new URL(request.url), code = url.searchParams.get("code"), state = url.searchParams.get("state");
    if (!code || !state) throw new Error("Authorization not completed");
    await finishCalendarAuthorization(code, state);
    return NextResponse.redirect(new URL("/?view=integrations&calendar=connected", request.url));
  } catch { return NextResponse.redirect(new URL("/?view=integrations&calendar=failed", request.url)); }
}
