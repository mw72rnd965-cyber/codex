import { AssistantApp } from "@/components/assistant/AssistantApp";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { requireSession, sessionCookie } from "@/lib/auth";
export default async function Home() {
  const jar = await cookies();
  try { await requireSession(jar.get(sessionCookie)?.value); }
  catch { redirect("/signin"); }
  return <AssistantApp />;
}
