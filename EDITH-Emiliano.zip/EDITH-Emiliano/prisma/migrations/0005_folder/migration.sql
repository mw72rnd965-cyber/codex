ALTER TABLE KnowledgeFile ADD COLUMN sourcePath TEXT;
CREATE UNIQUE INDEX KnowledgeFile_sourcePath_key ON KnowledgeFile(sourcePath);
