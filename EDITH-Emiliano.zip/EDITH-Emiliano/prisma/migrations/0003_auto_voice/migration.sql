-- Enable the requested neural voice once for existing installations.
-- Future explicit changes to voice settings remain persistent.
UPDATE UserSettings SET voiceOutput = 1, voiceEngine = 'kokoro', voiceId = 'af_sarah', voiceRate = 0.94, voicePitch = 1;
