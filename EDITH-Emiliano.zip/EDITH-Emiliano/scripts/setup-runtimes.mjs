import { existsSync, mkdirSync, renameSync, createReadStream } from "node:fs";
import { createHash } from "node:crypto";
import { execFileSync } from "node:child_process";
const root = process.env.EDITH_RUNTIME_ROOT ?? "/workspace";
const assets = [
  {
    file: `${root}/models/kokoro/kokoro-v1.0.onnx`,
    url: "https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.1/kokoro-v1.0.onnx",
    sha: "beb0d1848dee9a49da392cc3df26958d46cfa35d321edf434f52949153f0df3a",
  },
  {
    file: `${root}/models/kokoro/voices-v1.0.bin`,
    url: "https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.1/voices-v1.0.bin",
    sha: "bca610b8308e8d99f32e6fe4197e7ec01679264efed0cac9140fe9c29f1fbf7d",
  },
  {
    file: `${root}/tools/llama-b11429/archive.tar.gz`,
    url: "https://github.com/ggml-org/llama.cpp/releases/download/b11429/llama-b11429-bin-ubuntu-x64.tar.gz",
    sha: "f6d25dde8f51133143d1453da4fd5f73b145127177612a283bf7995957af3392",
  },
];
for (const asset of assets.filter(a => process.platform === "linux" || !a.file.includes("llama-b11429"))) {
  mkdirSync(asset.file.slice(0, asset.file.lastIndexOf("/")), {
    recursive: true,
  });
  const file = existsSync(asset.file) ? asset.file : asset.file + ".part";
  if (!existsSync(asset.file))
    execFileSync(
      "curl",
      [
        "--fail",
        "--location",
        "--silent",
        "--show-error",
        "--retry",
        "2",
        "--max-time",
        "300",
        asset.url,
        "--output",
        file,
      ],
      { stdio: "inherit" },
    );
  const hash = createHash("sha256");
  for await (const chunk of createReadStream(file)) hash.update(chunk);
  if (hash.digest("hex") !== asset.sha)
    throw new Error("Official artifact checksum mismatch: " + asset.file);
  if (file !== asset.file) renameSync(file, asset.file);
  console.log("Verified: " + asset.file);
}
if (process.platform === "linux") execFileSync(
  "tar",
  [
    "--extract",
    "--gzip",
    "--no-same-owner",
    "--file",
    `${root}/tools/llama-b11429/archive.tar.gz`,
    "--strip-components=1",
    "--directory",
    `${root}/tools/llama-b11429`,
  ],
  { stdio: "inherit" },
);
const python = process.platform === "win32" ? `${root}/tools/edith-voice/Scripts/python.exe` : `${root}/tools/edith-voice/bin/python`;
if (!existsSync(python))
  execFileSync(process.env.EDITH_PYTHON ?? "python3", ["-m", "venv", `${root}/tools/edith-voice`], {
    stdio: "inherit",
  });
execFileSync(
  python,
  [
    "-m",
    "pip",
    "install",
    "--disable-pip-version-check",
    "--cache-dir",
    `${root}/.pip-cache`,
    "-r",
    "services/voice/requirements.txt",
  ],
  { stdio: "inherit" },
);
console.log(
  "Local speech and model runtime installed. Qwen model weights are a separate ai:setup step.",
);
