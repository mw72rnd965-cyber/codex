import "dotenv/config";
import { schedulerTick } from "../lib/scheduler";
import { db } from "../lib/db";
let stopped = false;
process.on("SIGINT", () => { stopped = true; });
process.on("SIGTERM", () => { stopped = true; });
console.log("E.D.I.T.H. durable scheduler started. Keep this backend process running while browsers are closed.");
async function main() {
  const heartbeat = setInterval(() => { void db.systemSetting.upsert({ where: { key: "scheduler.heartbeat" }, create: { key: "scheduler.heartbeat", value: String(Date.now()) }, update: { value: String(Date.now()) } }).catch(() => {}); }, 10000);
  heartbeat.unref();
  do {
    await schedulerTick();
    if (process.argv.includes("--once")) break;
    for (let tick = 0; tick < 10 && !stopped; tick++) await new Promise(resolve => setTimeout(resolve, 500));
  } while (!stopped);
  await db.$disconnect();
  clearInterval(heartbeat);
}
main().catch(async () => { console.error("Scheduler failed. Check database availability and configuration. No credentials were logged."); await db.$disconnect(); process.exitCode = 1; });
