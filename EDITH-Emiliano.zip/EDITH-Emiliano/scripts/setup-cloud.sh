#!/usr/bin/env bash
set -euo pipefail
umask 077
cd "$(dirname "${BASH_SOURCE[0]}")/.."
node -e 'if (Number(process.versions.node.split(".")[0]) !== 24) throw new Error("Activate Node.js 24 before setup")'
report_changes() {
  if [ -e .git ] || [ -e ../.git ]; then git status --short; fi
}
report_changes
edith_cache="${EDITH_NPM_CACHE:-}"
if [ -z "$edith_cache" ]; then
  if [ -d /workspace ] && [ -w /workspace ]; then
    edith_cache=/workspace/.npm-cache
  else
    edith_cache="$PWD/.edith-runtime/npm-cache"
  fi
fi
npm ci --cache "$edith_cache" --no-audit --no-fund
if [ ! -e .env ]; then cp .env.example .env; fi
chmod 600 .env
npm run db:setup
report_changes
