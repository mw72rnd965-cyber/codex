import { cpSync, existsSync, readFileSync, realpathSync } from "node:fs";
import { dirname, relative, resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";
import { ensureVoiceEnvironment } from "./ensure-voice-env.mjs";

// Copy application files into an existing installation, preserving private data.
const source = realpathSync(resolve(dirname(fileURLToPath(import.meta.url)), ".."));
const argument = process.argv[2];
if (!argument) throw new Error("Provide your existing E.D.I.T.H. folder: node scripts/update-existing.mjs ~/Downloads/EDITH-Emiliano");
if (!existsSync(resolve(argument, "package.json"))) throw new Error("The destination must be your existing E.D.I.T.H. folder.");
const target = realpathSync(resolve(argument));
if (source === target || source.startsWith(target + sep) || target.startsWith(source + sep)) throw new Error("Extract the update beside your existing folder before updating.");
if (JSON.parse(readFileSync(resolve(target, "package.json"), "utf8")).name !== "edith") throw new Error("The destination is not an E.D.I.T.H. installation.");
const excluded = new Set([".git", "node_modules", ".next", ".edith-runtime", "generated", "test-results", "playwright-report", "__pycache__"]);
cpSync(source, target, {
 recursive: true,
 filter(path) {
  const parts = relative(source, path).split(sep);
  return !parts.some(part => excluded.has(part) || (part.startsWith(".env") && part !== ".env.example") || /\.(?:db(?:-.*)?|pyc|tsbuildinfo)$/.test(part));
 },
});
const voiceSetup = ensureVoiceEnvironment(target);
console.log("Application files updated. Your existing private settings, selected model, database and storage were preserved." + (voiceSetup.added.length ? " Missing ElevenLabs fields were added as blank entries in .env." : voiceSetup.created ? " A private .env was created from the template." : "") + " From your existing folder, run bash scripts/setup-cloud.sh, then restart the app and scheduler. If you still need to switch to Ollama, run npm run ai:ollama first.");
