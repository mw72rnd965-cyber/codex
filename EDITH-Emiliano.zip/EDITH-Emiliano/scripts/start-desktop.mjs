import {existsSync,mkdirSync,openSync,closeSync,renameSync,copyFileSync} from 'node:fs';
import {join,dirname,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawn,execFileSync} from 'node:child_process';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
process.chdir(root);
if(process.platform!=='win32')throw new Error('Use the Mac launcher on macOS. This desktop launcher is for Windows.');
if(Number(process.versions.node.split('.')[0])<24)throw new Error('Install Node.js 24 LTS from nodejs.org.');
const runtime=join(root,'.edith-runtime');
mkdirSync(join(runtime,'logs'),{recursive:true});
function run(command,args){execFileSync(command,args,{stdio:'inherit',cwd:root,windowsHide:true});}
function resolveNpm(){
 const candidates=[join(dirname(process.execPath),'node_modules','npm','bin','npm-cli.js')];
 try{for(const path of execFileSync('where.exe',['npm'],{encoding:'utf8',windowsHide:true}).trim().split(/\r?\n/))candidates.push(join(dirname(path),'node_modules','npm','bin','npm-cli.js'));}catch{}
 const cli=candidates.find(existsSync);if(!cli)throw new Error('Cannot find npm. Install the official Node.js 24 installer, including npm.');return cli;
}
const npm=resolveNpm();
function npmRun(...args){run(process.execPath,[npm,...args]);}
let python='';
for(const [command,args] of [['py',['-3.13']],['py',['-3.12']],['python',[]],['python3',[]]]){
 try{python=execFileSync(command,[...args,'-c','import sys; assert (3,12) <= sys.version_info[:2] < (3,14); print(sys.executable)'],{encoding:'utf8',windowsHide:true,timeout:15000}).trim();if(python)break;}catch{}
}
if(!python)throw new Error('Install Python 3.13 (or 3.12, not 3.14+) from python.org. Include the Python launcher when installing.');
let ollama='ollama';
try{execFileSync(ollama,['--version'],{windowsHide:true,stdio:'ignore'});}catch{
 ollama=join(process.env.LOCALAPPDATA??'', 'Programs','Ollama','ollama.exe');
 if(!existsSync(ollama))throw new Error('Install Ollama from https://ollama.com/download/windows, then restart this launcher.');
}
Object.assign(process.env,{EDITH_RUNTIME_ROOT:runtime,EDITH_PYTHON:python,EDITH_VOICE_MODEL_DIR:join(runtime,'models','kokoro'),AI_PROVIDER:'local',LOCAL_AI_MODEL:process.env.EDITH_MODEL??'qwen2.5:3b',LOCAL_AI_TRANSPORT:'ollama',LOCAL_AI_BASE_URL:'http://127.0.0.1:11434/v1',LOCAL_VISION_MODEL:'moondream'});
const children=[];
function start(command,args,log){
 const fd=openSync(join(runtime,'logs',log),'a');
 try{const child=spawn(command,args,{cwd:root,env:process.env,stdio:['ignore',fd,fd],windowsHide:true});child.on('error',e=>console.error(e.message));children.push(child);return child;}finally{closeSync(fd);}
}
function cleanup(){for(const child of children){if(child.pid&&child.exitCode===null){try{execFileSync('taskkill.exe',['/PID',String(child.pid),'/T','/F'],{stdio:'ignore',windowsHide:true});}catch{}}}}
process.on('exit',cleanup);for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>process.exit(0));
const wait=ms=>new Promise(r=>setTimeout(r,ms));
async function healthy(url){try{return (await fetch(url,{signal:AbortSignal.timeout(1200)})).ok;}catch{return false;}}
async function portFree(port){const {createServer}=await import('node:net');await new Promise((resolve,reject)=>{const server=createServer();server.once('error',()=>reject(new Error(`Port ${port} is already in use. Close the other EDITH launcher and retry.`)));server.listen(port,'127.0.0.1',()=>server.close(resolve));});}
await portFree(3000);await portFree(8881);
if(!await healthy('http://127.0.0.1:11434/api/tags')){
 start(ollama,['serve'],'ollama.log');
 for(let n=0;n<60&&!await healthy('http://127.0.0.1:11434/api/tags');n++)await wait(1000);
}
if(!await healthy('http://127.0.0.1:11434/api/tags'))throw new Error('Ollama did not start. Check .edith-runtime/logs/ollama.log.');
console.log('Preparing EDITH. First startup downloads chat, image and voice models and dependencies.');
run(ollama,['pull',process.env.LOCAL_AI_MODEL]);run(ollama,['pull',process.env.LOCAL_VISION_MODEL]);
npmRun('ci','--cache',join(runtime,'npm-cache'),'--no-audit','--no-fund');
if(!existsSync('.env'))copyFileSync('.env.example','.env');
npmRun('run','db:setup');
const voiceDir=join(runtime,'tools','edith-voice');const voicePython=join(voiceDir,'Scripts','python.exe');
if(existsSync(voicePython)){try{execFileSync(voicePython,['-c','import sys; assert (3,12) <= sys.version_info[:2] < (3,14)'],{stdio:'ignore',windowsHide:true});}catch{renameSync(voiceDir,voiceDir+'-backup-'+Date.now());}}
npmRun('run','runtimes:setup');npmRun('run','build');
const voice=start(voicePython,['-m','uvicorn','services.voice.server:app','--host','127.0.0.1','--port','8881','--no-access-log'],'voice.log');
const app=start(process.execPath,['node_modules/next/dist/bin/next','start','--hostname','127.0.0.1'],'app.log');
let ready=false;
for(let n=0;n<90;n++){
 if(await healthy('http://127.0.0.1:3000/api/state')&&await healthy('http://127.0.0.1:8881/health')){ready=true;break;}
 if(app.exitCode!==null||voice.exitCode!==null)break;
 await wait(1000);
}
if(!ready)throw new Error('EDITH startup failed. Check .edith-runtime/logs/app.log and voice.log.');
const state=await (await fetch('http://127.0.0.1:3000/api/state')).json();
for(const [kind,data] of [['model',{mode:'local'}],['settings',{...state.settings,voiceOutput:true,voiceEngine:'kokoro',voiceId:'af_sarah',voiceRate:0.94}]]){
 const response=await fetch('http://127.0.0.1:3000/api/data/'+kind,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(data)});
 if(!response.ok)throw new Error('Could not configure '+kind);
}
console.log('Warming the model...');
const warmed=await fetch('http://127.0.0.1:11434/api/generate',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({model:process.env.LOCAL_AI_MODEL,prompt:'',stream:false,keep_alive:'30m',options:{num_ctx:4096},...(/qwen3/i.test(process.env.LOCAL_AI_MODEL)?{think:false}:{})}),signal:AbortSignal.timeout(180000)});
if(!warmed.ok)throw new Error('Model warmup failed.');
await warmed.json();
// Use a fixed browser URL without shell interpolation or execution-policy changes.
run('rundll32.exe',['url.dll,FileProtocolHandler','http://127.0.0.1:3000']);
console.log('EDITH is ready. Keep this window open. Press Ctrl+C to stop EDITH.');
await new Promise((resolve,reject)=>{app.once('exit',code=>code===0?resolve():reject(new Error('App exited. Check app.log.')));voice.once('exit',()=>reject(new Error('Voice service exited. Check voice.log.')));});
