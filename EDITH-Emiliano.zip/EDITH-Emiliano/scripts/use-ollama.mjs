import { readFileSync, existsSync, lstatSync, writeFileSync, renameSync, chmodSync, unlinkSync } from "node:fs";
import { resolve } from "node:path";
import { randomUUID } from "node:crypto";
import { DatabaseSync } from "node:sqlite";
import dotenv from "dotenv";

// Change only local AI settings. Existing keys and personal data stay private.
const envPath = resolve(".env");
if (existsSync(envPath) && lstatSync(envPath).isSymbolicLink()) throw new Error("Use a regular private .env file before configuring Ollama.");
const existing = existsSync(envPath) ? readFileSync(envPath, "utf8") : readFileSync(new URL("../.env.example", import.meta.url), "utf8");
const parsed = dotenv.parse(existing);
const model = process.argv[2] || parsed.LOCAL_AI_MODEL || "qwen2.5:3b";
if (model.length > 160 || !/^[a-zA-Z0-9][a-zA-Z0-9._:/-]*$/.test(model)) throw new Error("Use an exact model name from ollama list.");
const databaseUrl = process.env.DATABASE_URL || parsed.DATABASE_URL || "file:./prisma/edith.db";
if (!databaseUrl.startsWith("file:")) throw new Error("Ollama setup expects the existing local SQLite workspace.");
const settings = {
 AI_PROVIDER: "local",
 LOCAL_AI_BASE_URL: "http://127.0.0.1:11434/v1",
 LOCAL_AI_MODEL: model,
 LOCAL_AI_TRANSPORT: "ollama",
};
let updated = existing;
for (const [name, value] of Object.entries(settings)) {
 const expression = new RegExp(`^(?:export\\s+)?${name}\\s*=.*(?:\\r?\\n|$)`, "gm");
 updated = updated.replace(expression, "");
 if (updated && !updated.endsWith("\n")) updated += "\n";
 updated += `${name}="${value}"\n`;
}
const temporary = envPath + ".ollama-" + randomUUID();
try {
 writeFileSync(temporary, updated, { mode: 0o600, flag: "wx" });
 renameSync(temporary, envPath);
 chmodSync(envPath, 0o600);
} finally {
 if (existsSync(temporary)) unlinkSync(temporary);
}
dotenv.config({ quiet: true });
process.env.DATABASE_URL = databaseUrl;
await import("./init-db.mjs");
const database = new DatabaseSync(resolve(databaseUrl.slice(5)));
try {
 database.prepare('INSERT INTO "SystemSetting" ("key", "value", "updatedAt") VALUES (?, ?, ?) ON CONFLICT("key") DO UPDATE SET "value"=excluded."value", "updatedAt"=excluded."updatedAt"').run("ai.mode", "local", new Date().toISOString());
} finally {
 database.close();
}
console.log(`Ollama selected: ${model}. Restart E.D.I.T.H. and its scheduler. Open Ollama and run ollama pull ${model} if the model is not downloaded, then test the connection in Integrations.`);
