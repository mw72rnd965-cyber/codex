"use client";
import {useEffect,useState,useRef} from 'react';
import type {AbilitiesState,TimerRow} from './AbilitiesPanel';
export function TimerAlerts(){
 const [timers,setTimers]=useState<TimerRow[]>([]);
 const [error,setError]=useState('');
 const audio=useRef<AudioContext|null>(null);
 const sounded=useRef(new Set<string>());
 useEffect(()=>{
  const enable=()=>{if(!audio.current)audio.current=new AudioContext();void audio.current.resume();};
  window.addEventListener('pointerdown',enable);
  return()=>{window.removeEventListener('pointerdown',enable);void audio.current?.close();};
 },[]);
 useEffect(()=>{
  for(const timer of timers){
   if(sounded.current.has(timer.id)||audio.current?.state!=='running')continue;
   sounded.current.add(timer.id);
   const context=audio.current;
   for(let i=0;i<3;i++){
    const oscillator=context.createOscillator();const gain=context.createGain();
    oscillator.frequency.value=880;gain.gain.value=0.06;
    oscillator.connect(gain);gain.connect(context.destination);
    oscillator.start(context.currentTime+i*0.3);oscillator.stop(context.currentTime+i*0.3+0.15);
   }
  }
 },[timers]);
 useEffect(()=>{
  let alive=true,loading=false;
  const load=async()=>{if(loading)return;loading=true;try{const r=await fetch('/api/abilities');if(r.ok){const a=await r.json() as AbilitiesState;if(alive)setTimers(a.timers.filter(t=>t.status==='RINGING'));}}catch{}finally{loading=false;}};
  void load();const poll=setInterval(()=>void load(),1000);
  return()=>{alive=false;clearInterval(poll);};
 },[]);
 return <>{timers.map(timer=><div className="timer-alert" role="alert" key={timer.id}><strong>{timer.label} timer finished.</strong>{timer.callStatus==='FAILED'&&<span> Phone call failed; check notification settings.</span>}<button className="outline-button" onClick={async()=>{try{const r=await fetch('/api/abilities',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'dismiss-timer',id:timer.id})});if(!r.ok)throw new Error('Could not dismiss timer');setTimers(t=>t.filter(row=>row.id!==timer.id));}catch(e){setError(e instanceof Error?e.message:'Request failed');}}}>DISMISS</button></div>)}{error&&<p role="alert">{error}</p>}</>;
}
