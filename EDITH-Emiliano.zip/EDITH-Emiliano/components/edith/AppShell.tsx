"use client";
import { isFilePickerCommand } from "@/lib/abilities/chat-intent";
import { takeSpeechChunk } from "@/lib/voice/text";
import { useCallback, useEffect, useRef, useState } from "react";
import {
  Activity,
  ArrowUpRight,
  AudioLines,
  BrainCircuit,
  Check,
  ChevronRight,
  Database,
  Hexagon,
  Layers,
  Menu,
  MessageSquare,
  Network,
  Settings as SettingsIcon,
  Shield,
  StickyNote,
  X,
} from "lucide-react";
import { NeuralGraph } from "./NeuralGraph";
import { HUDPanel } from "./HUDPanel";
import { CommandInput } from "./CommandInput";
import { CommandPalette } from "./CommandPalette";
import { ConversationFeed } from "./ConversationFeed";
import { AbilitiesPanel } from "./AbilitiesPanel";
import { OpeningGreeting } from "./OpeningGreeting";
import { TimerAlerts } from "./TimerAlerts";
import { DataWorkspace } from "./DataWorkspace";
import { useSpeech } from "./useSpeech";
import { SettingsPanel } from "./SettingsPanel";
import type { State, View, Message, Conversation } from "./types";
const navigation: { id: View; label: string; icon: typeof Hexagon }[] = [
  { id: "core", label: "Core", icon: Hexagon },
  { id: "conversation", label: "Conversation", icon: MessageSquare },
  { id: "neural", label: "Neural map", icon: Network },
  { id: "memory", label: "Memory", icon: Database },
  { id: "knowledge", label: "Knowledge", icon: Layers },
  { id: "abilities", label: "Abilities", icon: BrainCircuit },
  { id: "tasks", label: "Tasks", icon: Check },
  { id: "notes", label: "Notes", icon: StickyNote },
  { id: "system", label: "System", icon: Activity },
  { id: "settings", label: "Settings", icon: SettingsIcon },
];
const descriptions: Record<View, string> = {
  abilities: "Files, tasks, timers, and notifications.",
  core: "A quieter kind of intelligence.",
  conversation: "A direct line to your intelligence.",
  neural: "Every connection has a context.",
  memory: "The things worth remembering.",
  knowledge: "Your knowledge, connected.",
  tasks: "Intent becomes action.",
  notes: "A place for your next thought.",
  system: "One system. Connected capabilities.",
  settings: "Intelligence, on your terms.",
};
export function AppShell() {
  const [state, setState] = useState<State | null>(null);
  const speech = useSpeech(state?.settings);
  const [view, setView] = useState<View>("core");
  const [time, setTime] = useState("");
  const [palette, setPalette] = useState(false);
  const [mobileNav, setMobileNav] = useState(false);
  const [rightOpen, setRightOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [conversationId, setConversationId] = useState<string>();
  const [sources, setSources] = useState<string[]>([]);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [boot, setBoot] = useState(false);
  const [bootLine, setBootLine] = useState(0);
  const [welcome, setWelcome] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const fileRef = useRef<HTMLInputElement>(null);
  const uploadFromChat=useRef(false);
  const refresh = useCallback(async () => {
    const response = await fetch("/api/state");
    if (!response.ok)
      throw new Error("Local database is unavailable. Run npm run db:setup.");
    const next: State = await response.json();
    setState(next);
    return next;
  }, []);
  useEffect(() => {
    void refresh()
      .then((s) => {
        if (!sessionStorage.getItem("edith.boot") && s.settings.boot) {
          setBoot(true);
          sessionStorage.setItem("edith.boot", "1");
        }
        if (!localStorage.getItem("edith.welcome")) setWelcome(true);
      })
      .catch((e) => setError(e.message));
    const tick = () => {
      setTime(new Date().toLocaleTimeString("en-GB"));
      setElapsed((t) => t + 1);
    };
    tick();
    const interval = setInterval(tick, 1000);
    return () => clearInterval(interval);
  }, [refresh]);
  useEffect(() => {
    if (!boot) return;
    const interval = setInterval(() => setBootLine((v) => v + 1), 300);
    const timeout = setTimeout(() => setBoot(false), 2400);
    return () => {
      clearInterval(interval);
      clearTimeout(timeout);
    };
  }, [boot]);
  useEffect(() => {
    const listener = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setPalette((p) => !p);
      }
      if (e.key === "Escape") {
        setPalette(false);
        setMobileNav(false);
      }
    };
    window.addEventListener("keydown", listener);
    return () => window.removeEventListener("keydown", listener);
  }, []);
  useEffect(() => {
    if (view === "conversation")
      document
        .getElementById("conversation-end")
        ?.scrollIntoView({ behavior: "instant", block: "end" });
  }, [messages, view]);
  const navigate = (target: View, fresh = false) => {
    if (fresh && busy) return;
    setView(target);
    setMobileNav(false);
    if (fresh) {
      setMessages([]);
      setConversationId(undefined);
      setSources([]);
    }
    setError("");
  };
  useEffect(() => {
    document
      .querySelector(".workspace")
      ?.scrollTo({ top: 0, behavior: "instant" });
  }, [view]);
  useEffect(() => {
    if (!notice) return;
    const timer = setTimeout(() => setNotice(""), 3500);
    return () => clearTimeout(timer);
  }, [notice]);
  const mutate = async (kind: string, body: unknown, method = "POST") => {
    const res = await fetch(`/api/data/${kind}`, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    if (!res.ok) {
      const data = await res.json();
      setError(data.error);
      throw new Error(data.error);
    }
    await refresh();
    setNotice(
      `${kind.toUpperCase()} ${method === "DELETE" ? "REMOVED" : "SAVED"}`,
    );
  };
  const upload = async (file: File) => {
    if (file.size > 10_000_000 || !/\.(txt|md|json|csv|pdf|docx|png|jpe?g|webp)$/i.test(file.name)) {
      setError("Choose a document or image under 10 MB.");
      return;
    }
    const form = new FormData();
    form.set("file", file);
    const response = await fetch("/api/data/knowledge", {
      method: "POST",
      body: form,
    });
    if (!response.ok) {
      setError("Could not index this file. Check its format and contents.");
      return;
    }
    await refresh();
    if(!uploadFromChat.current)navigate("knowledge");
    setNotice("KNOWLEDGE INDEXED");
  };
  const send = async (prompt: string) => {
    speech.stop();
    if(isFilePickerCommand(prompt)){
      uploadFromChat.current=true;
      setNotice("Choose the documents or images to import.");
      fileRef.current?.click();
      return;
    }
    const routes: Record<string, View> = {
      "/memory": "memory",
      "/tasks": "tasks",
      "/notes": "notes",
      "/knowledge": "knowledge",
      "/status": "system",
    };
    if (routes[prompt.trim()]) {
      navigate(routes[prompt.trim()]);
      return;
    }
    if (prompt.trim() === "/clear") {
      navigate("conversation", true);
      return;
    }
    if (prompt.trim() === "/help") {
      setPalette(true);
      return;
    }
    if (busy) return;
    setBusy(true);
    setError("");
    setView("conversation");
    setSources([]);
    const user: Message = {
      id: crypto.randomUUID(),
      role: "user",
      content: prompt,
      createdAt: new Date().toISOString(),
    };
    const assistant: Message = {
      id: crypto.randomUUID(),
      role: "assistant",
      content: "",
      createdAt: new Date().toISOString(),
    };
    setMessages((m) => [...m, user, assistant]);
    let text = "";
    let voiceBuffer = "";
    const neuralSpeech = state?.settings.voiceOutput && state.settings.voiceEngine === "kokoro";
    const drainSpeech = (flush=false) => {
      while(voiceBuffer) {
        const [chunk,rest]=takeSpeechChunk(voiceBuffer,flush);
        if(!chunk)break;
        voiceBuffer=rest;
        speech.enqueue(chunk);
      }
    };
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt, conversationId }),
      });
      if (!res.ok || !res.body)
        throw new Error("Query rejected. Check input and retry.");
      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let pending = "";
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        pending += decoder.decode(value, { stream: true });
        const lines = pending.split("\n");
        pending = lines.pop() ?? "";
        for (const line of lines) {
          if (!line.trim()) continue;
          const data = JSON.parse(line);
          if (data.type === "meta") {
            setConversationId(data.conversationId);
            setSources(data.sources);
          }
          if (data.type === "token") {
            text += data.content;
            if(neuralSpeech) {voiceBuffer+=data.content; drainSpeech();}
            setMessages((m) =>
              m.map((item) =>
                item.id === assistant.id ? { ...item, content: text } : item,
              ),
            );
          }
          if (data.type === "error") throw new Error(data.error);
        }
      }
      if(neuralSpeech) drainSpeech(true);
      else if (state?.settings.voiceOutput) void speech.speak(text);
      await refresh();
    } catch (e) {
      speech.stop();
      setError(e instanceof Error ? e.message : "Connection interrupted");
      await refresh().catch(() => {});
    } finally {
      setBusy(false);
    }
  };
  const selectConversation = (c: Conversation) => {
    setConversationId(c.id);
    setMessages(c.messages);
    setSources([]);
  };
  const session = `${Math.floor(elapsed / 3600)
    .toString()
    .padStart(2, "0")}:${Math.floor((elapsed / 60) % 60)
    .toString()
    .padStart(2, "0")}:${(elapsed % 60).toString().padStart(2, "0")}`;
  if (!state)
    return (
      <main className="startup">
        <BrainCircuit size={50} />
        <h1>EDITH</h1>
        <p role="status">{error || "ESTABLISHING LOCAL CONNECTION…"}</p>
        {error && (
          <button
            className="outline-button"
            onClick={() => void refresh().catch((e) => setError(e.message))}
          >
            RETRY
          </button>
        )}
      </main>
    );
  return (
    <div
      className={`app-shell ${state.settings.reducedMotion ? "reduced-motion" : ""}`}
    >
      <header className="top-bar">
        <button
          className="mobile-menu icon-button"
          onClick={() => setMobileNav((n) => !n)}
          aria-label="Toggle navigation"
        >
          <Menu size={20} />
        </button>
        <button className="brand" onClick={() => navigate("core")}>
          <span className="brand-symbol">
            <Hexagon size={32} strokeWidth={1} />
            <span>E</span>
          </span>
          <span>
            EDITH<small>PERSONAL INTELLIGENCE SYSTEM</small>
          </span>
        </button>
        <div className="top-status">
          <span>
            <i className="dot" />
            CORE ONLINE
          </span>
          <span>
            <i className="dot" />
            MEMORY LINKED
          </span>
          <span className="demo-tag">
            {state.provider === "mock" ? "DEMO MODE" : "MODEL CONNECTED"}
          </span>
        </div>
        <div className="top-time">
          <span>{time}</span>
          <small>LOCAL TIME / SESSION 01</small>
        </div>
        <button
          className="icon-button intelligence-toggle"
          aria-label="Toggle intelligence panel"
          onClick={() => setRightOpen((r) => !r)}
        >
          <Activity size={19} />
        </button>
      </header>
      <div className="main-layout">
        <nav
          className={`navigation ${mobileNav ? "open" : ""}`}
          aria-label="Main navigation"
        >
          <span className="nav-heading">WORKSPACE</span>
          {navigation.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => navigate(id)}
              aria-current={view === id ? "page" : undefined}
              className={`nav-item ${view === id ? "active" : ""}`}
            >
              <Icon size={18} strokeWidth={1.5} />
              <span>{label}</span>
              {view === id && (
                <ChevronRight size={12} className="nav-chevron" />
              )}
            </button>
          ))}
          <div className="nav-bottom">
            <span className="monogram">
              {state.settings.displayName.slice(0, 2).toUpperCase()}
            </span>
            <div>
              <strong>{state.settings.displayName}</strong>
              <small>LOCAL OPERATOR</small>
            </div>
            <Shield size={13} />
          </div>
        </nav>
        <main className={`workspace view-${view}`}>
<OpeningGreeting name={state.settings.displayName} enabled={state.settings.voiceOutput&&!boot&&!welcome} speech={speech}/><TimerAlerts/>
          <div className="workspace-heading">
            <div>
              <div className="eyebrow">
                EDITH / {view === "core" ? "OVERVIEW" : view.toUpperCase()}{" "}
                <span className="heading-line" />
              </div>
              <h1>
                {view === "core"
                  ? "Intelligence, connected."
                  : navigation.find((n) => n.id === view)?.label}
              </h1>
              <p>{descriptions[view]}</p>
            </div>
            <span className="workspace-state">
              <i className="dot" />
              {busy ? "PROCESSING" : "SYSTEM NOMINAL"}
            </span>
          </div>
          {error && (
            <div className="alert" role="alert">
              {error}
              <button
                className="icon-button"
                aria-label="Dismiss error"
                onClick={() => setError("")}
              >
                <X size={15} />
              </button>
            </div>
          )}
          {view === "core" && (
            <>
              <div className="core-stage">
                <div className="stage-label left">
                  <span className="eyebrow">NEURAL ENGINE</span>
                  <strong>
                    Context-aware.
                    <br />
                    Always connected.
                  </strong>
                  <span className="micro">TOPOLOGY / SIMULATED</span>
                </div>
                <div className="stage-label right">
                  <span className="eyebrow">MEMORY LINK</span>
                  <strong>
                    {state.memories.length.toString().padStart(2, "0")}
                    <small>STORED NODES</small>
                  </strong>
                  <span className="tiny-bars">▏▎▍▌▋▍▎▌▍▎▏</span>
                </div>
                <NeuralGraph
                  memories={state.memories}
                  reduced={state.settings.reducedMotion}
                  processing={busy}
                />
                <div className="stage-bottom">
                  <span className="eyebrow">YOUR PERSONAL INTELLIGENCE</span>
                  <h2>
                    Good{" "}
                    {new Date().getHours() < 12
                      ? "morning"
                      : new Date().getHours() < 18
                        ? "afternoon"
                        : "evening"}
                    , {state.settings.displayName}.
                  </h2>
                  <p>
                    Your thoughts, knowledge, and next steps. One connected
                    system.
                  </p>
                </div>
              </div>
              <div className="overview-cards">
                {[
                  {
                    view: "memory" as View,
                    label: "LONG-TERM MEMORY",
                    number: state.memories.length,
                    unit: "stored memories",
                    icon: Database,
                  },
                  {
                    view: "knowledge" as View,
                    label: "KNOWLEDGE BASE",
                    number: state.knowledge.length,
                    unit: "indexed sources",
                    icon: Layers,
                  },
                  {
                    view: "tasks" as View,
                    label: "TASK QUEUE",
                    number: state.tasks.filter(
                      (t) => t.status === "ACTIVE" || t.status === "PENDING",
                    ).length,
                    unit: "open objectives",
                    icon: Check,
                  },
                ].map(({ view: target, label, number, unit, icon: Icon }) => (
                  <button
                    key={target}
                    className="overview-card"
                    onClick={() => navigate(target)}
                  >
                    <div>
                      <Icon size={18} strokeWidth={1.4} />
                      <span className="micro">{label}</span>
                      <ArrowUpRight size={14} />
                    </div>
                    <strong>
                      {number.toString().padStart(2, "0")}
                      <span>{unit}</span>
                    </strong>
                    <div className="meter">
                      <i
                        style={{ width: `${Math.min(100, 12 + number * 5)}%` }}
                      />
                    </div>
                  </button>
                ))}
              </div>
              <div className="quick-start">
                <span className="micro">QUICK ACTION</span>
                <button onClick={() => navigate("conversation", true)}>
                  Start a conversation <ArrowUpRight size={14} />
                </button>
                <button onClick={() => navigate("memory")}>
                  Store a memory <ArrowUpRight size={14} />
                </button>
                <button onClick={() => fileRef.current?.click()}>
                  Connect your knowledge <ArrowUpRight size={14} />
                </button>
              </div>
            </>
          )}
          {view === "neural" && (
            <NeuralGraph
              expanded
              memories={state.memories}
              reduced={state.settings.reducedMotion}
              processing={busy}
            />
          )}
          {view === "conversation" && (
            <ConversationFeed
              messages={messages}
              conversations={state.conversations}
              activeId={conversationId}
              select={selectConversation}
              fresh={() => navigate("conversation", true)}
              remove={(id) => {
                void mutate("conversations", { id }, "DELETE")
                  .then(() => {
                    if (id === conversationId) navigate("conversation", true);
                  })
                  .catch(() => {});
              }}
              busy={busy}
              sources={sources}
            />
          )}
          {["memory", "knowledge", "tasks", "notes"].includes(view) && (
            <DataWorkspace
              key={view}
              view={view}
              state={state}
              mutate={mutate}
              upload={() => fileRef.current?.click()}
            />
          )}
          {view === "abilities" && <AbilitiesPanel state={state} refresh={refresh}/>}
          {view === "settings" && (
            <SettingsPanel state={state} mutate={mutate} speech={speech} />
          )}
          {view === "system" && (
            <div className="system-grid">
              {[
                {
                  title: "LANGUAGE MODEL",
                  detail: state.model,
                  status: state.provider === "mock" ? "DEMO" : "CONFIGURED",
                  icon: BrainCircuit,
                },
                {
                  title: "MEMORY ENGINE",
                  detail: `${state.memories.length} persistent records`,
                  status: "ONLINE",
                  icon: Database,
                },
                {
                  title: "KNOWLEDGE INDEX",
                  detail: `${state.knowledge.length} indexed documents`,
                  status: "ONLINE",
                  icon: Layers,
                },
                {
                  title: "TASK ENGINE",
                  detail: `${state.tasks.length} total objectives`,
                  status: "ONLINE",
                  icon: Check,
                },
                {
                  title: "CONVERSATION",
                  detail: `${state.conversations.length} saved sessions`,
                  status: "ONLINE",
                  icon: MessageSquare,
                },
                {
                  title: "LOCAL DATABASE",
                  detail: "SQLite / Prisma · persistent",
                  status: "CONNECTED",
                  icon: Shield,
                },
              ].map(({ title, detail, status, icon: Icon }) => (
                <HUDPanel
                  key={title}
                  title={title}
                  subtitle="EDITH ARCHITECTURE"
                >
                  <div className="system-module">
                    <Icon size={32} strokeWidth={1} />
                    <p>{detail}</p>
                    <span className="status-label">{status}</span>
                  </div>
                </HUDPanel>
              ))}
              <HUDPanel title="ACTIVITY LOG" className="full-width">
                <div className="system-events">
                  {state.activity.map((a) => (
                    <div key={a.id}>
                      <time>{new Date(a.createdAt).toLocaleTimeString()}</time>
                      <span>{a.label}</span>
                    </div>
                  ))}
                  {!state.activity.length && (
                    <p className="empty">NO EVENTS YET</p>
                  )}
                </div>
              </HUDPanel>
            </div>
          )}
        </main>
        <aside className={`intelligence-panel ${rightOpen ? "open" : ""}`}>
          <header>
            <span className="eyebrow">INTELLIGENCE PANEL</span>
            <span className="dot" />
          </header>
          <section className="edith-status">
            <div className="mini-core">
              <Hexagon size={49} strokeWidth={0.75} />
              <span>
                <BrainCircuit size={23} strokeWidth={1} />
              </span>
            </div>
            <h2>EDITH</h2>
            <span className="status-label">
              {busy ? "PROCESSING" : "ONLINE & READY"}
            </span>
            <p>Even Dead, I&apos;m The Hero</p>
          </section>
          <section className="right-section">
            <h3>
              CORE TELEMETRY <AudioLines size={14} />
            </h3>
            <dl>
              <dt>Provider</dt>
              <dd>
                {state.provider === "mock"
                  ? "Demo engine"
                  : state.provider === "local"
                    ? "Free local model"
                    : "Compatible API"}
              </dd>
              <dt>Memory</dt>
              <dd>{state.memories.length} nodes</dd>
              <dt>Knowledge</dt>
              <dd>{state.knowledge.length} sources</dd>
              <dt>Session</dt>
              <dd>{session}</dd>
            </dl>
            <div className="signal-bars">
              {Array.from({ length: 35 }, (_, i) => (
                <i key={i} style={{ height: `${10 + ((i * 7) % 25)}px` }} />
              ))}
            </div>
            <div className="signal-caption">
              <span>VISUAL SIGNAL SIMULATION</span>
              <span>NOMINAL</span>
            </div>
          </section>
          <section className="right-section activity-section">
            <h3>
              ACTIVITY STREAM{" "}
              <span>{state.activity.length.toString().padStart(2, "0")}</span>
            </h3>
            {busy && (
              <div className="activity-event current">
                <i className="dot" />
                <span>
                  {elapsed % 3 === 0
                    ? "SEARCHING MEMORY"
                    : elapsed % 3 === 1
                      ? "ASSEMBLING CONTEXT"
                      : "GENERATING RESPONSE"}
                  <small>NOW</small>
                </span>
              </div>
            )}
            {state.activity.slice(0, 6).map((a) => (
              <div className="activity-event" key={a.id}>
                <i className="dot" />
                <span>
                  {a.label}
                  <small>{new Date(a.createdAt).toLocaleTimeString()}</small>
                </span>
              </div>
            ))}
            {!state.activity.length && (
              <p className="quiet">
                Awaiting your first command.
                <br />
                Activity will appear here.
              </p>
            )}
          </section>
          <section className="connection-note">
            <Shield size={16} />
            <div>
              <strong>Local by design.</strong>
              <p>
                Your memory stays on this device.
                <br />
                You control what gets shared.
              </p>
            </div>
          </section>
          <div className="right-foot">
            <span className="micro">LOCAL DATABASE</span>
            <span className="status-label">CONNECTED</span>
          </div>
        </aside>
      </div>
      <CommandInput
        send={send}
        speechStatus={speech.status}
        stopSpeech={speech.stop}
        busy={busy}
        palette={() => setPalette(true)}
        upload={() => fileRef.current?.click()}
      />
      <input
        ref={fileRef}
        type="file"
        multiple
        hidden
        accept=".txt,.md,.json,.csv,.pdf,.docx,.png,.jpg,.jpeg,.webp"
        onChange={(e) => {
          const files=Array.from(e.target.files??[]);
          e.target.value = "";
          void (async()=>{try{for(const file of files.slice(0,100))await upload(file);}finally{uploadFromChat.current=false;}})();
        }}
      />
      {palette && (
        <CommandPalette close={() => setPalette(false)} navigate={navigate} />
      )}
      {speech.error && (
        <div className="toast voice-error" role="alert">
          {speech.error}
          <button
            className="icon-button"
            aria-label="Dismiss voice error"
            onClick={speech.clearError}
          >
            <X size={13} />
          </button>
        </div>
      )}
      {notice && (
        <div className="toast" role="status">
          <Check size={14} />
          {notice}
          <button
            className="icon-button"
            aria-label="Dismiss notification"
            onClick={() => setNotice("")}
          >
            <X size={13} />
          </button>
        </div>
      )}
      {boot && (
        <div className="boot-screen">
          <Hexagon size={45} strokeWidth={1} />
          <h1>E D I T H</h1>
          <span className="eyebrow">SYSTEM INITIALIZATION</span>
          <div>
            {[
              "CORE................ONLINE",
              "MEMORY..............ONLINE",
              "KNOWLEDGE...........ONLINE",
              "INTERFACE...........READY",
              "VOICE...............BROWSER DEPENDENT",
            ]
              .slice(0, bootLine)
              .map((line) => (
                <p key={line}>{line}</p>
              ))}
          </div>
          <button onClick={() => setBoot(false)}>SKIP INITIALIZATION →</button>
        </div>
      )}
      {welcome && !boot && (
        <div className="modal-backdrop">
          <div
            className="welcome-modal"
            role="dialog"
            aria-modal="true"
            aria-label="Welcome to EDITH"
          >
            <BrainCircuit size={42} strokeWidth={1} />
            <span className="eyebrow">PERSONAL INTELLIGENCE / INITIALIZED</span>
            <h2>Welcome to EDITH.</h2>
            <p>
              Your local intelligence workspace is ready. Begin with the demo
              engine, store your first memory, or connect your documents. No API
              key required.
            </p>
            <ul>
              <li>
                <Database size={16} />
                Persistent local memory
              </li>
              <li>
                <Shield size={16} />
                External context sharing disabled by default
              </li>
              <li>
                <Network size={16} />
                Interactive neural topology
              </li>
            </ul>
            <button
              autoFocus
              className="primary-button"
              onClick={() => {
                localStorage.setItem("edith.welcome", "1");
                setWelcome(false);
              }}
            >
              CONTINUE IN{" "}
              {state.provider === "mock" ? "DEMO MODE" : "CONFIGURED MODE"}
              <ArrowUpRight size={15} />
            </button>
            <button
              className="quiet-button"
              onClick={() => {
                localStorage.setItem("edith.welcome", "1");
                setWelcome(false);
                navigate("settings");
              }}
            >
              Configure your workspace
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
