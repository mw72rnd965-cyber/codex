export type View =
  | "abilities"
  | "core"
  | "conversation"
  | "neural"
  | "memory"
  | "knowledge"
  | "tasks"
  | "notes"
  | "system"
  | "settings";
export type Memory = {
  id: string;
  category: string;
  title: string;
  content: string;
  importance: number;
  confidence: number;
  source: string;
  createdAt: string;
  updatedAt: string;
};
export type Task = {
  id: string;
  title: string;
  description: string;
  status: string;
  priority: string;
  dueDate: string | null;
  createdAt: string;
};
export type Note = {
  id: string;
  title: string;
  content: string;
  tags: string;
  pinned: boolean;
  createdAt: string;
  updatedAt: string;
};
export type Message = {
  id: string;
  role: string;
  content: string;
  createdAt: string;
};
export type Conversation = {
  id: string;
  title: string;
  messages: Message[];
  createdAt: string;
};
export type Settings = {
  displayName: string;
  voiceOutput: boolean;
  voiceEngine: "elevenlabs" | "kokoro" | "browser";
  voiceId: string;
  voiceRate: number;
  voicePitch: number;
  boot: boolean;
  reducedMotion: boolean;
  memoryEnabled: boolean;
  retrievalCount: number;
};
export type State = {
  memories: Memory[];
  tasks: Task[];
  notes: Note[];
  knowledge: {
    id: string;
    name: string;
    createdAt: string;
    _count: { chunks: number };
  }[];
  conversations: Conversation[];
  activity: { id: string; label: string; createdAt: string }[];
  settings: Settings;
  provider: string;
  model: string;
  externalContext: boolean;
  localModel: { available: boolean; name: string; local: boolean; installed:boolean };
  voice: { available: boolean; engine: string; local: boolean };
};
export type Mutate = (
  kind: string,
  body: unknown,
  method?: string,
) => Promise<void>;
