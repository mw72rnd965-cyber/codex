"use client";
import {useEffect,useRef,useState} from 'react';
import {HUDPanel} from './HUDPanel';
import type {State} from './types';
export type TimerRow={id:string;label:string;dueAt:string;status:string;callStatus:string|null};
export type AbilitiesState={timers:TimerRow[];phone:{number:string;enabled:boolean;configured:boolean};folder:{path:string;lastScan?:string;imported?:number;skipped?:number;error?:string}|null;visionModel:string;nativeFolderChooser:boolean};
export function AbilitiesPanel({state,refresh}:{state:State;refresh:()=>Promise<unknown>}){
 const [abilities,setAbilities]=useState<AbilitiesState>();
 const [error,setError]=useState('');const [notice,setNotice]=useState('');const [busy,setBusy]=useState(false);
 const [number,setNumber]=useState('');const [enabled,setEnabled]=useState(false);
 const [label,setLabel]=useState('Timer');const [seconds,setSeconds]=useState(300);const [call,setCall]=useState(false);
 const [selected,setSelected]=useState<string[]>([]);const [instruction,setInstruction]=useState('Summarize the selected files and identify the next steps.');const [createTasks,setCreateTasks]=useState(false);const [answer,setAnswer]=useState('');
 const fileRef=useRef<HTMLInputElement>(null);
 const load=async()=>{const r=await fetch('/api/abilities');if(!r.ok)throw new Error('Abilities unavailable');const a=await r.json() as AbilitiesState;setAbilities(a);return a;};
 useEffect(()=>{void load().then(a=>{setNumber(a.phone.number);setEnabled(a.phone.enabled);}).catch(e=>setError(e.message));},[]);
 const act=async(data:object)=>{setError('');setNotice('');setBusy(true);try{const r=await fetch('/api/abilities',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});const result=await r.json();if(!r.ok)throw new Error(result.error);await load();await refresh();return result;}catch(e){setError(e instanceof Error?e.message:'Request failed');return null;}finally{setBusy(false);}};
 const upload=async(files:FileList|null)=>{
  if(!files)return;setBusy(true);setError('');setNotice('');let count=0;const ids:string[]=[];const errors:string[]=[];
  try{
   for(const file of Array.from(files).slice(0,100)){
    const form=new FormData();form.set('file',file);
    const r=await fetch('/api/data/knowledge',{method:'POST',body:form});const result=await r.json();
    if(r.ok){count++;ids.push(result.id);}else errors.push(file.name);
   }
   setSelected(ids.slice(0,8));await refresh();setNotice(`${count} files imported${errors.length?`; failed: ${errors.slice(0,5).join(', ')}`:''}.`);
  }catch(e){setError(e instanceof Error?e.message:'Import failed');}finally{setBusy(false);if(fileRef.current)fileRef.current.value='';}
 };
 return <div className="data-workspace abilities-workspace">
  <p className="privacy-note">Choose what EDITH can read. Analysis is saved in Notes; requested action items are saved in Tasks. Keep EDITH running for folder updates and timer alerts.</p>
  {error&&<div role="alert" className="ability-error">{error}</div>}{notice&&<p role="status">{notice}</p>}
  <HUDPanel title="DOCUMENTS AND IMAGES" subtitle="PDF / DOCX / TEXT / PNG / JPG / WEBP · 10 MB EACH">
   <div className="ability-actions">
    <button className="primary-button" disabled={busy} onClick={()=>fileRef.current?.click()}>ADD FILES OR IMAGES</button>
    <input ref={fileRef} hidden type="file" multiple accept=".txt,.md,.json,.csv,.pdf,.docx,.png,.jpg,.jpeg,.webp" onChange={e=>void upload(e.target.files)}/>
    <button className="outline-button" disabled={busy||!abilities?.nativeFolderChooser} onClick={()=>void act({action:'choose-folder'})}>CHOOSE LINKED FOLDER</button>
   </div>
   {!abilities?.nativeFolderChooser&&<p className="micro">The native folder chooser is available in EDITH on Windows and Mac.</p>}
   {abilities?.folder&&<div className="ability-folder"><p>Linked folder: {abilities.folder.path}</p><p className="micro">Refreshed every 30 seconds while EDITH runs. Last scan: {abilities.folder.lastScan?new Date(abilities.folder.lastScan).toLocaleTimeString():'pending'}. {abilities.folder.skipped||0} unreadable/oversized files skipped. Dot files and symbolic links are skipped.</p>{abilities.folder.error&&<p role="alert">{abilities.folder.error}</p>}<button className="outline-button" disabled={busy} onClick={()=>void act({action:'scan-folder'})}>REFRESH FOLDER</button><button className="outline-button" disabled={busy} onClick={()=>void act({action:'unlink-folder'})}>DISCONNECT FOLDER</button><p className="micro">Imported copies stay in Knowledge until you delete them.</p></div>}
   <div className="ability-files">{state.knowledge.map(file=><label key={file.id}><input type="checkbox" checked={selected.includes(file.id)} disabled={!selected.includes(file.id)&&selected.length>=8} onChange={e=>setSelected(ids=>e.target.checked?[...ids,file.id]:ids.filter(id=>id!==file.id))}/>{file.name}</label>)}</div>
   <label className="setting-field">What should EDITH do with the selected files?<textarea rows={3} value={instruction} onChange={e=>setInstruction(e.target.value)}/></label>
   <label className="ability-checkbox"><input type="checkbox" checked={createTasks} onChange={e=>setCreateTasks(e.target.checked)}/>Create task entries from my instruction</label>
   <button className="primary-button" disabled={busy||!selected.length||!instruction.trim()} onClick={()=>void act({action:'analyze',fileIds:selected,instruction,createTasks}).then(r=>{if(r){setAnswer(r.answer);setNotice(`Analysis saved in Notes. ${r.tasks.length} tasks created.`);}})}>{busy?'WORKING…':createTasks?'ANALYZE AND CREATE TASKS':'ANALYZE SELECTED FILES'}</button>
   <p className="micro">Select up to 8 files. Image analysis uses the local {abilities?.visionModel??'moondream'} vision model. Scanned PDFs need OCR; upload their pages as images. Large documents use bounded excerpts.</p>
   {answer&&<div className="ability-answer" role="status">{answer}</div>}
  </HUDPanel>
  <HUDPanel title="TIMERS" subtitle="PERSISTENT / LOCAL ALERTS">
   <div className="form-columns"><label className="setting-field">Timer name<input value={label} maxLength={200} onChange={e=>setLabel(e.target.value)}/></label><label className="setting-field">Duration in seconds<input type="number" min={1} max={604800} value={seconds} onChange={e=>setSeconds(Number(e.target.value))}/></label></div>
   <label className="ability-checkbox"><input type="checkbox" disabled={!abilities?.phone.configured||!abilities.phone.enabled} checked={call} onChange={e=>setCall(e.target.checked)}/>Call my phone when this timer finishes</label>
   <button className="primary-button" disabled={busy} onClick={()=>void act({action:'timer',label,seconds,notifyPhone:call}).then(r=>{if(r)setNotice('Timer started.');})}>START TIMER</button>
   <p className="micro">You can also say “set a timer for 5 minutes called pasta”. Alerts run while EDITH is open and your computer is awake; overdue timers alert after restart/wake.</p>
   {abilities?.timers.map(timer=><div className="ability-timer" key={timer.id}><span>{timer.label} · {timer.status==='RINGING'?'FINISHED':new Date(timer.dueAt).toLocaleTimeString()}{timer.callStatus?` · call ${timer.callStatus.toLowerCase()}`:''}</span><button className="outline-button" disabled={busy} onClick={()=>void act({action:'dismiss-timer',id:timer.id})}>{timer.status==='RINGING'?'DISMISS':'CANCEL'}</button></div>)}
  </HUDPanel>
  <HUDPanel title="PHONE NOTIFICATIONS" subtitle={abilities?.phone.configured?'CALLING PROVIDER CONNECTED':'CALLING PROVIDER NOT CONFIGURED'}>
   <label className="setting-field">Your phone number, including country code<input type="tel" placeholder="+358…" value={number} onChange={e=>setNumber(e.target.value)}/></label>
   <label className="ability-checkbox"><input type="checkbox" disabled={!abilities?.phone.configured} checked={enabled} onChange={e=>setEnabled(e.target.checked)}/>Enable calls to my number</label>
   <div className="ability-actions"><button className="primary-button" disabled={busy} onClick={()=>void act({action:'phone-settings',number,enabled}).then(r=>{if(r)setNotice('Phone preferences saved.');})}>SAVE PHONE SETTINGS</button><button className="outline-button" disabled={busy||!abilities?.phone.configured||!abilities.phone.enabled} onClick={()=>{if(confirm('Place a real notification call to your saved number?'))void act({action:'test-call'}).then(r=>{if(r)setNotice('Call queued by the provider.');});}}>TEST CALL</button></div>
   <p className="micro">Without a calling provider, EDITH can save your number but cannot place calls. Twilio support requires account credentials and a calling number in .env; provider charges may apply. Only timers explicitly marked for a call trigger phone notifications.</p>
  </HUDPanel>
 </div>;
}
