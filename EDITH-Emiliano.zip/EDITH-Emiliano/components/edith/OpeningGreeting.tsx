"use client";
import {useEffect,useRef} from 'react';
import type {SpeechController} from './useSpeech';
export function OpeningGreeting({name,enabled,speech}:{name:string;enabled:boolean;speech:SpeechController}){
 const greeted=useRef(false);
 const {speak}=speech;
 const displayName=name==='Operator'?'Emiliano':name;
 useEffect(()=>{
  if(!enabled)return;
  // Safari needs user interaction to permit audio; greet once on the first interaction.
  const greet=()=>{if(greeted.current)return;greeted.current=true;void speak(`Hello ${displayName}. Welcome back.`);};
  window.addEventListener('pointerdown',greet,{once:true});
  window.addEventListener('keydown',greet,{once:true});
  return()=>{window.removeEventListener('pointerdown',greet);window.removeEventListener('keydown',greet);};
 },[enabled,displayName,speak]);
 return <div className="opening-greeting" role="status">Hello {displayName}. Welcome back.</div>;
}
