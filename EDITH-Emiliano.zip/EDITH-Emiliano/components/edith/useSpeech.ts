"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import type { Settings } from "./types";
import { chooseBrowserVoice } from "@/lib/voice/browser";
import { speechText } from "@/lib/voice/text";
export type VoicePreferences = Pick<
  Settings,
  "voiceEngine" | "voiceId" | "voiceRate" | "voicePitch"
>;
export function useSpeech(settings?: VoicePreferences) {
  const [status, setStatus] = useState<"idle" | "preparing" | "speaking">(
    "idle",
  );
  const [error, setError] = useState("");
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const active = useRef<{
    audio?: HTMLAudioElement;
    url?: string;
    controller?: AbortController;
  }>({});
  const sequence = useRef(0);
  const generation = useRef<Promise<unknown>>(Promise.resolve());
  const playback = useRef<Promise<unknown>>(Promise.resolve());
  const controllers = useRef(new Set<AbortController>());
  const releasePlayback = useRef<(() => void) | undefined>(undefined);
  const queued = useRef(0);
  const stop = useCallback(() => {
    sequence.current++;
    for (const controller of controllers.current) controller.abort();
    controllers.current.clear();
    releasePlayback.current?.();
    releasePlayback.current = undefined;
    generation.current = playback.current = Promise.resolve();
    queued.current = 0;
    active.current.controller?.abort();
    active.current.audio?.pause();
    if (active.current.url) URL.revokeObjectURL(active.current.url);
    active.current = {};
    if ("speechSynthesis" in window) window.speechSynthesis.cancel();
    setStatus("idle");
  }, []);
  useEffect(() => {
    if (!("speechSynthesis" in window)) return;
    const update = () => setVoices(window.speechSynthesis.getVoices());
    update();
    window.speechSynthesis.addEventListener("voiceschanged", update);
    return () =>
      window.speechSynthesis.removeEventListener("voiceschanged", update);
  }, []);
  useEffect(
    () => () => {
      sequence.current++;
      for (const controller of controllers.current) controller.abort();
      releasePlayback.current?.();
      active.current.controller?.abort();
      active.current.audio?.pause();
      if (active.current.url) URL.revokeObjectURL(active.current.url);
      if ("speechSynthesis" in window) window.speechSynthesis.cancel();
    },
    [],
  );
  const enqueue = useCallback((text: string, override?: VoicePreferences) => {
    const prefs = override ?? settings;
    const clean = speechText(text);
    if (!clean || !prefs || prefs.voiceEngine !== "kokoro") return;
    const current = sequence.current;
    queued.current++;
    setError("");
    if (!active.current.audio) setStatus("preparing");
    const prepared = generation.current.then(async () => {
      if (sequence.current !== current) return null;
      const controller = new AbortController();
      controllers.current.add(controller);
      try {
        const response = await fetch("/api/voice", {
          method: "POST", headers: {"Content-Type":"application/json"},
          body: JSON.stringify({text:clean,voice:prefs.voiceId,speed:prefs.voiceRate}),
          signal:controller.signal,
        });
        if(!response.ok) throw new Error((await response.json()).error ?? "Voice generation failed");
        return await response.blob();
      } finally {controllers.current.delete(controller);}
    });
    generation.current = prepared.catch(()=>{});
    // Attach a handler immediately even when previous audio is still playing.
    const ready = prepared.then(blob=>({blob,error:null as Error|null}), error=>({blob:null,error:error as Error}));
    playback.current = playback.current.then(async()=>{
      const result=await ready;
      if(sequence.current !== current) return;
      if(result.error) throw result.error;
      if(!result.blob) return;
      const url=URL.createObjectURL(result.blob);
      const audio=new Audio(url);
      active.current={audio,url};
      try {
        await new Promise<void>((resolve,reject)=>{
          releasePlayback.current=resolve;
          audio.onended=()=>resolve();
          audio.onerror=()=>reject(new Error("Audio playback failed"));
          void audio.play().then(()=>{if(sequence.current===current)setStatus("speaking");}).catch(reject);
        });
      } finally {
        URL.revokeObjectURL(url);
        if(sequence.current===current) {
          active.current={}; releasePlayback.current=undefined;
          queued.current--;
          setStatus(queued.current ? "preparing" : "idle");
        }
      }
    }).catch(error=>{
      if(sequence.current===current){stop();setError(error instanceof Error ? error.message : "Speech failed");}
    });
  },[settings,stop]);
  const speak = useCallback(
    async (text: string, override?: VoicePreferences) => {
      stop();
      setError("");
      const current = sequence.current;
      const prefs = override ??
        settings ?? {
          voiceEngine: "kokoro",
          voiceId: "af_sarah",
          voiceRate: 0.94,
          voicePitch: 1,
        };
      if (prefs.voiceEngine === "kokoro") { enqueue(text,prefs); return; }
      const clean = speechText(text);
      if (!clean) return;
      try {
        setStatus("preparing");
        if (prefs.voiceEngine === "browser") {
          if (!("speechSynthesis" in window))
            throw new Error("This browser does not support speech output.");
          const available = window.speechSynthesis.getVoices();
          if (!available.length)
            throw new Error(
              "No browser voices are installed. Select EDITH neural voice instead.",
            );
          const utterance = new SpeechSynthesisUtterance(clean);
          const selected = chooseBrowserVoice(available, prefs.voiceId);
          if (selected) {
            utterance.voice = selected;
            utterance.lang = selected.lang;
          }
          utterance.rate = prefs.voiceRate;
          utterance.pitch = prefs.voicePitch;
          utterance.onstart = () => {
            if (sequence.current === current) setStatus("speaking");
          };
          utterance.onend = () => {
            if (sequence.current === current) setStatus("idle");
          };
          utterance.onerror = () => {
            if (sequence.current === current) {
              setStatus("idle");
              setError(
                "Browser speech playback failed. Try EDITH neural voice.",
              );
            }
          };
          window.speechSynthesis.speak(utterance);
          return;
        }
      } catch (e) {
        if (sequence.current === current) {
          stop();
          setError(e instanceof Error ? e.message : "Speech failed");
        }
      }
    },
    [settings, stop, enqueue],
  );
  return { speak, enqueue, stop, status, error, voices, clearError: () => setError("") };
}
export type SpeechController = ReturnType<typeof useSpeech>;
