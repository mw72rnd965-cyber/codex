export type Task = { id: string; title: string; description: string; status: string; priority: string; prioritySource: string; dueDate: string | null; startDate: string | null; projectId: string | null; parentId: string | null; tags: string; recurrence: string; estimatedMinutes: number };
export type Settings = { displayName: string; timezone: string; voiceOutput: boolean; voiceEngine: "elevenlabs" | "kokoro" | "browser"; voiceId: string; voiceVolume: number; voiceRate: number; voicePitch: number; microphoneEnabled: boolean; reducedMotion: boolean; memoryEnabled: boolean; retrievalCount: number; boot: boolean; reminderLeadMinutes: number; quietStart: string; quietEnd: string; quietHours: boolean; snoozeMinutes: number; planningMinutes: number };
export type Calendar = { id: string; summary: string; accessRole: string };
type Config = { missing: string[] };
export type Workspace = {
 settings: Settings;
 tasks: Task[];
 projects: { id: string; title: string; description: string; color: string }[];
 events: { id: string; title: string; description: string; startAt: string; endAt: string; source: string; allDay: boolean }[];
 reminders: { id: string; title: string; dueAt: string; active: boolean; timezone: string; recurrence: string; channels: string; taskId?: string | null; eventId?: string | null }[];
 jobs: { id: string; kind: string; dueAt: string; status: string; payload: string; result: string | null; error: string | null }[];
 notifications: { id: string; title: string; body: string; read: boolean; channel: string; status: string; createdAt: string }[];
 notes: { id: string; title: string; content: string; tags: string; pinned: boolean }[];
 memories: { id: string; title: string; content: string; category: string; importance: number }[];
 documents: { id: string; name: string; mimeType: string; extractionWarning: string; createdAt: string; _count: { chunks: number } }[];
 conversations: { id: string; title: string; messages: Message[] }[];
 calls: { id: string; status: string; error: string | null; duration: number | null; consent: boolean; createdAt: string }[];
 callSchedule: { id: string; phone: string; verifiedAt: string | null; enabled: boolean; paused: boolean; localTime: string; timezone: string; days: string; topics: string; maxDuration: number; voicemail: string; updatedAt: string };
 integrations: { externalContext: boolean; ai: Config & { demo: boolean; name: string; model: string | null }; web: Config & { enabled: boolean; provider: string }; voice: Config; calls: Config; sms: Config; email: Config; ocr: Config; push: Config & { publicKey: string | null; subscriptions: number }; calendar: Config & { connected: boolean; connection: { calendars: string; writable: boolean; syncedAt: string | null; error: string | null } | null }; scheduler: { connected: boolean; lastSeen: string | null } };
 briefing: { greeting: string; update: string; briefing: string };
 proposals: { noteId: string; tasks: { title: string; description: string }[]; accepted: number[] }[];
};
export type Message = { id: string; role: string; content: string; createdAt?: string };
export type View = "home" | "core" | "conversation" | "tasks" | "calendar" | "reminders" | "documents" | "notes" | "calls" | "integrations" | "privacy";
export type Edit = { kind: "task" | "project" | "event" | "reminder" | "note" | "memory"; value?: Record<string, unknown> };
export type Act = (body: Record<string, unknown>) => Promise<Record<string, unknown>>;
export function formatDate(value: string | null, timezone: string, options: Intl.DateTimeFormatOptions = {}) { return value ? new Date(value).toLocaleString("en-GB", { timeZone: timezone, day: "numeric", month: "short", hour: "2-digit", minute: "2-digit", ...options }) : "No date set"; }
export function localInput(value: string | undefined, timezone: string) {
 if (!value) return "";
 const parts = new Intl.DateTimeFormat("en-CA", { timeZone: timezone, year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).formatToParts(new Date(value));
 const get = (key: string) => parts.find(p => p.type === key)?.value;
 return `${get("year")}-${get("month")}-${get("day")}T${get("hour")}:${get("minute")}`;
}
