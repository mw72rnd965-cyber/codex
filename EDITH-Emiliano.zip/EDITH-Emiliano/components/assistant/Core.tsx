"use client";

import { useEffect, useRef, useState, type CSSProperties } from "react";
import { Activity, ArrowUpRight, AudioLines, Cpu, Mic, Pause, Play, Radio, ShieldCheck, Sparkles } from "lucide-react";
import type { Workspace } from "./types";

const states = {
 idle: { label: "Standing by", title: "Ready when you are.", detail: "A thought, a question, a next step. I'm here." },
 listening: { label: "Listening", title: "You have my attention.", detail: "Listening through your microphone. Review your words before sending." },
 processing: { label: "Processing", title: "Thinking it through.", detail: "Your request is in progress. The core follows the assistant's activity." },
 preparing: { label: "Preparing voice", title: "Finding my voice.", detail: "Preparing the audio for your reply." },
 speaking: { label: "Speaking", title: "Let's talk.", detail: "Voice playback is active. You can interrupt it at any time." },
 error: { label: "Attention needed", title: "A little attention needed.", detail: "Check the message below. Your workspace remains available." },
} as const;
type CoreState = keyof typeof states;
function stateFor(value: string): CoreState { return value in states ? value as CoreState : "idle"; }
function point(angle: number, radius: number) {
 const radians = (angle - 90) * Math.PI / 180;
 return { x: +(240 + Math.cos(radians) * radius).toFixed(3), y: +(240 + Math.sin(radians) * radius).toFixed(3) };
}
const ticks = Array.from({ length: 120 }, (_, i) => ({ from: point(i * 3, i % 5 ? 216 : 210), to: point(i * 3, 222), major: i % 5 === 0 }));
const nodes = Array.from({ length: 12 }, (_, i) => ({ ...point(i * 30 + 15, 190), delay: -(i * .7) }));

/** Decorative state visualization; it does not simulate hardware telemetry. */
export function Orb({ state = "idle", small = false, large = false, paused = false, reducedMotion = false, intensity = "ambient" }: {
 state?: string; small?: boolean; large?: boolean; paused?: boolean; reducedMotion?: boolean; intensity?: "ambient" | "energized";
}) {
 const root = useRef<HTMLDivElement>(null);
 const [visible, setVisible] = useState(true);
 const [systemReduced, setSystemReduced] = useState(false);
 useEffect(() => {
  const preference = window.matchMedia("(prefers-reduced-motion: reduce)");
  const motion = () => setSystemReduced(preference.matches);
  motion(); preference.addEventListener("change", motion);
  let intersecting = true;
  const update = () => setVisible(intersecting && !document.hidden);
  const observer = typeof IntersectionObserver === "undefined" ? null : new IntersectionObserver(([entry]) => { intersecting = entry.isIntersecting; update(); });
  if (root.current) observer?.observe(root.current);
  document.addEventListener("visibilitychange", update); update();
  return () => { preference.removeEventListener("change", motion); observer?.disconnect(); document.removeEventListener("visibilitychange", update); };
 }, []);
 const actual = stateFor(state);
 const motion = reducedMotion || systemReduced ? "reduced" : paused ? "paused" : visible ? "running" : "suspended";
 return <div ref={root} className={`assistant-orb neural-core ${small ? "small" : ""} ${large ? "core-large" : ""}`} data-state={actual} data-motion={motion} data-intensity={intensity} role="img" aria-label={`Assistant ${actual}`}>
  <div className="core-art" aria-hidden="true">
   <div className="core-halo"/><div className="core-scan"/>
   <svg className="core-rings" viewBox="0 0 480 480" fill="none">
    <circle className="core-boundary" cx="240" cy="240" r="232"/>
    <g className="core-ticks">{ticks.map((tick, i) => <line key={i} x1={tick.from.x} y1={tick.from.y} x2={tick.to.x} y2={tick.to.y} className={tick.major ? "major" : ""}/>)}</g>
    <g className="core-outer-track"><circle cx="240" cy="240" r="201"/><circle className="core-outer-accent" cx="240" cy="240" r="201" strokeDasharray="76 108 12 64 28 153"/><circle className="core-guide" cx="240" cy="240" r="194"/></g>
    <g className="core-middle-track"><circle cx="240" cy="240" r="174"/><circle className="core-middle-accent" cx="240" cy="240" r="174" strokeDasharray="160 54 18 118 48 148"/></g>
    <g className="core-data-track"><circle cx="240" cy="240" r="153" strokeDasharray="2 10"/><circle className="core-data-accent" cx="240" cy="240" r="142" strokeDasharray="69 154 17 90 110 120"/></g>
    <g className="core-orbit-track"><ellipse cx="240" cy="240" rx="128" ry="65" transform="rotate(-32 240 240)"/><ellipse cx="240" cy="240" rx="128" ry="65" transform="rotate(46 240 240)"/><circle cx="347" cy="174" r="4"/><circle cx="162" cy="156" r="3"/></g>
    <g className="core-particles">{nodes.map((node, i) => <circle key={i} cx={node.x} cy={node.y} r={i % 3 === 0 ? 2.6 : 1.4} style={{ "--particle-delay": node.delay + "s" } as CSSProperties}/>)}</g>
    <g className="core-connectors"><path d="M240 8v18m0 428v18M8 240h18m428 0h18M73 73l12 12m310 310 12 12M73 407l12-12M395 85l12-12"/><path d="M220 42h40M220 438h40M42 220v40M438 220v40"/></g>
   </svg>
   <div className="core-plasma"><div className="core-plasma-flow"/><div className="core-plasma-inner"/><div className="core-iris"/><div className="core-center"><svg viewBox="0 0 80 80" fill="none"><path d="M40 7 69 24v32L40 73 11 56V24L40 7Z"/><path d="m40 19 19 11v20L40 61 21 50V30l19-11Z"/><path d="M40 7v12M69 24l-10 6M69 56l-10-6M40 73V61M11 56l10-6M11 24l10 6"/><path className="core-center-mark" d="M48 31H33v18h15M33 40h12"/></svg></div></div>
   <div className="core-waveform">{Array.from({ length: 17 }, (_, i) => <i key={i} style={{ "--bar-size": `${6 + (8 - Math.abs(8 - i)) * 2}px`, "--bar-delay": `${-(i % 7) * .13}s` } as CSSProperties}/>)}</div>
  </div>
 </div>;
}

export function CorePanel({ workspace, activity }: { workspace: Workspace; activity: string }) {
 const [paused, setPaused] = useState(false);
 const [intensity, setIntensity] = useState<"ambient" | "energized">("ambient");
 const [systemReduced, setSystemReduced] = useState(false);
 useEffect(() => {
  const preference = window.matchMedia("(prefers-reduced-motion: reduce)");
  const update = () => setSystemReduced(preference.matches);
  update(); preference.addEventListener("change", update);
  return () => preference.removeEventListener("change", update);
 }, []);
 const actual = stateFor(activity), info = states[actual];
 const reduced = workspace.settings.reducedMotion || systemReduced;
 const aiStatus = workspace.integrations.ai.demo ? "Demo mode" : workspace.integrations.ai.missing.length ? "Needs setup" : "Configured";
 return <section className="core-console" data-state={actual} aria-label="E.D.I.T.H. animated core">
  <div className="core-console-header"><div className="core-console-brand"><span className="core-brand-icon"><Sparkles size={17}/></span><div><strong>E.D.I.T.H.</strong><span>PERSONAL INTELLIGENCE CORE</span></div></div><span className="core-state-pill" role="status"><i/>{info.label}</span></div>
  <div className="core-console-grid">
   <aside className="core-side core-side-left"><span className="core-section-label">YOUR CONNECTION</span><div className="core-info-block"><Cpu size={17}/><span>Conversation model</span><strong>{workspace.integrations.ai.name}</strong><small>{workspace.integrations.ai.model ?? "Local workspace retrieval"}</small><span className="core-config-tag">{aiStatus}</span></div><div className="core-info-block"><ShieldCheck size={17}/><span>Workspace</span><strong>{workspace.settings.displayName}</strong><small>Private documents & memory</small></div><div className="core-status-line"><Radio size={13}/><span>{workspace.integrations.scheduler.connected ? "Reminder worker online" : "Reminder worker offline"}</span></div></aside>
   <div className="core-visual-stage"><div className="core-stage-grid" aria-hidden="true"/><div className="core-stage-crosshairs" aria-hidden="true"><i/><i/><i/><i/></div><span className="core-stage-coordinate coordinate-top" aria-hidden="true">E / D / I / T / H</span><Orb state={actual} large paused={paused} reducedMotion={reduced} intensity={intensity}/><div className="core-stage-caption"><span className="core-stage-label">{info.label}</span><h2>{info.title}</h2><p>{info.detail}</p></div></div>
   <aside className="core-side core-side-right"><span className="core-section-label">ASSISTANT ACTIVITY</span><div className="core-state-list">{Object.entries(states).map(([key, value]) => <div className={key === actual ? "current" : ""} key={key}><i/><span>{value.label}</span>{key === actual && <ArrowUpRight size={13}/>}</div>)}</div><div className="core-status-line"><Mic size={13}/><span>{workspace.settings.microphoneEnabled ? "Push to talk enabled" : "Microphone disabled"}</span></div><div className="core-status-line"><AudioLines size={13}/><span>{workspace.settings.voiceOutput ? "Voice output enabled" : "Voice output disabled"}</span></div></aside>
  </div>
  <div className="core-console-footer"><div className="core-motion-controls" role="group" aria-label="Core animation intensity"><span>MOTION</span><button aria-pressed={intensity === "ambient"} onClick={() => setIntensity("ambient")} disabled={reduced}>Ambient</button><button aria-pressed={intensity === "energized"} onClick={() => setIntensity("energized")} disabled={reduced}>Energized</button></div><button className="core-pause-button" aria-label={paused ? "Resume core animations" : "Pause core animations"} aria-pressed={paused} disabled={reduced} onClick={() => setPaused(value => !value)}>{reduced ? <ShieldCheck size={14}/> : paused ? <Play size={14}/> : <Pause size={14}/>}<span>{reduced ? "Reduced motion" : paused ? "Motion paused" : "Pause motion"}</span></button></div>
  <div className="core-console-note"><Activity size={12}/><span>Motion follows assistant activity. Model configuration is shown separately from a verified connection.</span></div>
 </section>;
}
