"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { ArrowUp, Mic, Square, Volume2, VolumeX } from "lucide-react";
import type { Settings } from "./types";
type Recognition = { lang: string; continuous: boolean; interimResults: boolean; onstart: (() => void) | null; onresult: ((event: { results: { [index: number]: { [index: number]: { transcript: string } } } }) => void) | null; onend: (() => void) | null; onerror: ((event: { error: string }) => void) | null; start: () => void; stop: () => void; abort: () => void };
type SpeechWindow = Window & { SpeechRecognition?: new () => Recognition; webkitSpeechRecognition?: new () => Recognition };
export function useAssistantVoice(settings?: Settings) {
 const [status, setStatus] = useState<"idle" | "preparing" | "speaking">("idle");
 const [error, setError] = useState("");
 const [enabled, setEnabled] = useState(false);
 const [muted, setMuted] = useState(false);
 const active = useRef<{ audio?: HTMLAudioElement; url?: string; abort?: AbortController }>({});
 const sequence = useRef(0);
 const stop = useCallback(() => { sequence.current++; active.current.abort?.abort(); active.current.audio?.pause(); if (active.current.url) URL.revokeObjectURL(active.current.url); active.current = {}; if ("speechSynthesis" in window) window.speechSynthesis.cancel(); setStatus("idle"); }, []);
 useEffect(() => { setEnabled(sessionStorage.getItem("edith.voice.enabled") === "yes"); return () => { active.current.abort?.abort(); active.current.audio?.pause(); if (active.current.url) URL.revokeObjectURL(active.current.url); if ("speechSynthesis" in window) window.speechSynthesis.cancel(); }; }, []);
 const speak = useCallback(async (text: string, force = false) => {
  if (!settings?.voiceOutput || muted || !enabled && !force) return;
  stop(); setError(""); const current = sequence.current; setStatus("preparing");
  try {
   if (settings.voiceEngine === "browser") {
    if (!("speechSynthesis" in window)) throw new Error("Browser speech is unavailable. Text remains available.");
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.volume = settings.voiceVolume; utterance.rate = settings.voiceRate;
    const voices = window.speechSynthesis.getVoices(); const selected = voices.find(v => v.voiceURI === settings.voiceId) ?? voices.find(v => v.lang.startsWith("en")); if (selected) utterance.voice = selected;
    utterance.onstart = () => { if (current === sequence.current) setStatus("speaking"); }; utterance.onend = () => { if (current === sequence.current) setStatus("idle"); }; utterance.onerror = () => { if (current === sequence.current) { setStatus("idle"); setError("Audio permission or browser speech failed. Please continue using text."); } };
    window.speechSynthesis.speak(utterance); return;
   }
   const abort = new AbortController(); active.current = { abort };
   const response = await fetch("/api/voice", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ text: text.slice(0, 4000), engine: settings.voiceEngine }), signal: abort.signal });
   if (!response.ok) throw new Error((await response.json()).error);
   const blob = await response.blob(); if (current !== sequence.current) return;
   const url = URL.createObjectURL(blob), audio = new Audio(url); active.current = { audio, url, abort };
   audio.volume = settings.voiceVolume; audio.playbackRate = settings.voiceRate;
   audio.onended = () => { if (current === sequence.current) stop(); };
   audio.onerror = () => { if (current === sequence.current) { stop(); setError("Speech playback failed. Your text is preserved."); } };
   await audio.play(); if (current === sequence.current) setStatus("speaking");
  } catch (failure) { if (current === sequence.current) { stop(); setError(failure instanceof Error ? failure.message : "Voice unavailable; text remains available."); } }
 }, [settings, muted, enabled, stop]);
 const enable = async (greeting: string) => { sessionStorage.setItem("edith.voice.enabled", "yes"); setEnabled(true); await speak(greeting, true); };
 return { status, error, enabled, muted, stop, speak, enable, clearError: () => setError(""), toggleMute: () => { stop(); setMuted(value => !value); } };
}
export type AssistantVoice = ReturnType<typeof useAssistantVoice>;
export function Composer({ settings, voice, busy, send, activity }: { settings: Settings; voice: AssistantVoice; busy: boolean; send: (text: string) => Promise<void>; activity: (listening: boolean) => void }) {
 const [value, setValue] = useState(""); const [listening, setListening] = useState(false); const [supported, setSupported] = useState(false); const [microphoneError, setMicrophoneError] = useState(""); const recognition = useRef<Recognition | null>(null);
 useEffect(() => { const w = window as SpeechWindow; setSupported(!!(w.SpeechRecognition || w.webkitSpeechRecognition)); return () => recognition.current?.abort(); }, []);
 useEffect(() => { if (!settings.microphoneEnabled) { recognition.current?.abort(); setListening(false); activity(false); } }, [settings.microphoneEnabled, activity]);
 const listen = () => {
  if (listening) { recognition.current?.stop(); return; } voice.stop(); setMicrophoneError("");
  const w = window as SpeechWindow, Constructor = w.SpeechRecognition || w.webkitSpeechRecognition;
  if (!Constructor) return; const instance = new Constructor(); instance.lang = "en-US"; instance.continuous = false; instance.interimResults = false;
  instance.onstart = () => { setListening(true); activity(true); };
  instance.onresult = event => setValue(event.results[0][0].transcript);
  instance.onend = () => { setListening(false); activity(false); };
  instance.onerror = event => { setListening(false); activity(false); setMicrophoneError(event.error === "not-allowed" ? "Microphone permission was denied. Enable it in browser settings or use text." : "Speech recognition failed. Your typed text is preserved."); };
  recognition.current = instance; try { instance.start(); } catch { setMicrophoneError("Microphone could not start. Please use text."); }
 };
 const submit = async () => { if (!value.trim() || busy) return; const text = value; try { await send(text); setValue(""); } catch { /* Preserve text for retry. */ } };
 return <div className="composer-wrap"><div className="composer"><textarea aria-label="Message E.D.I.T.H." placeholder="Ask E.D.I.T.H., or tell her what needs doing…" value={value} onChange={event => setValue(event.target.value)} onKeyDown={event => { if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); void submit(); } }} rows={1}/><button className={listening ? "icon-btn active" : "icon-btn"} aria-label={listening ? "Stop listening" : "Push to talk"} title={!supported ? "Speech recognition is unsupported in this browser" : !settings.microphoneEnabled ? "Microphone disabled in privacy settings" : "Push to talk; review the transcript before sending"} disabled={!supported || !settings.microphoneEnabled || busy} onClick={listen}>{listening ? <Square size={18}/> : <Mic size={19}/>}</button><button className="icon-btn" aria-label={voice.muted ? "Unmute voice" : "Mute voice"} onClick={voice.toggleMute}>{voice.muted ? <VolumeX size={18}/> : <Volume2 size={18}/>}</button>{voice.status !== "idle" && <button className="icon-btn active" aria-label="Interrupt speech" onClick={voice.stop}><Square size={18}/></button>}<button className="send-btn" aria-label="Send message" disabled={busy || !value.trim()} onClick={() => void submit()}><ArrowUp size={20}/></button></div><div className="composer-caption"><span>{listening ? "Listening · microphone permission granted" : busy ? "Processing your request" : "Text is saved privately · voice starts only when you ask"}</span><span>Enter to send · Shift + Enter for a new line</span></div>{microphoneError && <p className="inline-error" role="alert">{microphoneError}</p>}</div>;
}
export function Orb({ state = "idle", small = false }: { state?: string; small?: boolean }) { return <div className={`assistant-orb ${small ? "small" : ""}`} data-state={state} aria-label={`Assistant ${state}`}><div className="orb-aura"/><div className="orb-ring ring-one"/><div className="orb-ring ring-two"/><div className="orb-core"><span/><span/><span/><span/><span/></div></div>; }
