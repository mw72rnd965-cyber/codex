import {defineConfig} from '@playwright/test';
import {resolve} from 'node:path';
const database='file:'+resolve('.edith-runtime/acceptance.db');
process.env.EDITH_TEST_DATABASE_URL=database;
export default defineConfig({
 testDir:'./tests',testMatch:'browser.spec.ts',workers:1,timeout:45000,
 use:{baseURL:'http://127.0.0.1:3001',launchOptions:{executablePath:'/usr/bin/chromium',args:['--no-sandbox']}},
 reporter:'list',
 webServer:{command:'npm run db:setup && npm start -- --port 3001',url:'http://127.0.0.1:3001/signin',reuseExistingServer:false,timeout:120000,
  env:{DATABASE_URL:database,EDITH_PRIVATE_ROOT:resolve('.edith-runtime/acceptance-private'),EDITH_PUBLIC_URL:'',AI_PROVIDER:'mock',AI_MODEL:'',AI_API_KEY:'',ALLOW_EXTERNAL_CONTEXT:'false',ELEVENLABS_API_KEY:'test-only-client-exposure-canary',ELEVENLABS_VOICE_ID:'',TWILIO_ACCOUNT_SID:'',TWILIO_AUTH_TOKEN:'',TWILIO_VERIFY_SERVICE_SID:'',TWILIO_FROM_NUMBER:'',VAPID_PUBLIC_KEY:'',VAPID_PRIVATE_KEY:'',SMTP_HOST:'',GOOGLE_CLIENT_ID:'',GOOGLE_CLIENT_SECRET:''}},
});
