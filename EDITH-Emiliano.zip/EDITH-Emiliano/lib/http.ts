export function checkOrigin(request: Request) {
  if (request.headers.get("sec-fetch-site") === "cross-site") throw new HttpError("Cross-origin request rejected.", 403);
  const value = request.headers.get("origin");
  if (!value) return;
  const origin = new URL(value);
  const host = request.headers.get("host") ?? new URL(request.url).host;
  if (!["http:", "https:"].includes(origin.protocol) || origin.host !== host)
    throw new HttpError("Cross-origin request rejected.", 403);
}
export function apiError(error: unknown) {
  return Response.json(
    { error: error instanceof HttpError ? error.message : error instanceof Error && error.name === "ZodError" ? "Check the highlighted values: a required field is missing or invalid." : "The request could not be completed. Check input and integration status, then try again." },
    { status: error instanceof HttpError ? error.status : 400 },
  );
}
export class HttpError extends Error { constructor(message: string, public status = 400) { super(message); } }
