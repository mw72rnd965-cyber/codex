import {db} from '@/lib/db';
import {makeNotificationCall,phoneConfigured,phoneSettings} from './phone';
import {timerInput} from './inputs';
export async function createTimer(input:unknown){
 const data=timerInput.parse(input);
 if(data.notifyPhone){const phone=await phoneSettings();if(!phone.enabled||!phoneConfigured())throw new Error('Configure and enable phone notifications first.');}
 return db.timer.create({data:{label:data.label,notifyPhone:data.notifyPhone,dueAt:new Date(Date.now()+data.seconds*1000)}});
}
export async function tickTimers(){
 const due=await db.timer.findMany({where:{status:'WAITING',dueAt:{lte:new Date()}},take:50});
 for(const timer of due){
  const claim=await db.timer.updateMany({where:{id:timer.id,status:'WAITING'},data:{status:'RINGING',callStatus:timer.notifyPhone?'SENDING':null}});
  if(!claim.count)continue;
  if(timer.notifyPhone){
   try {await makeNotificationCall(`Hello. This is EDITH. Your ${timer.label} timer has finished.`);await db.timer.update({where:{id:timer.id},data:{callStatus:'QUEUED'}});}
   catch {await db.timer.update({where:{id:timer.id},data:{callStatus:'FAILED'}});}
  }
 }
}
const globalWorker=globalThis as unknown as {edithTimerWorker?:ReturnType<typeof setInterval>};
export function ensureTimerWorker(){
 if(globalWorker.edithTimerWorker)return;
 let running=false;
 globalWorker.edithTimerWorker=setInterval(async()=>{if(running)return;running=true;try{await tickTimers();}catch{console.error('Timer scheduler unavailable');}finally{running=false;}},1000);
 globalWorker.edithTimerWorker.unref();
}
