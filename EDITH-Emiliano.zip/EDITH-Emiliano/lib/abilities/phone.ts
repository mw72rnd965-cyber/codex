import {db} from '@/lib/db';
import {configuration} from '@/lib/integrations/status';
import {startCall} from '@/lib/integrations/phone';
export function phoneConfigured(){return !configuration().calls.missing.length;}
export async function phoneSettings(){const row=await db.callSchedule.findUnique({where:{id:'local'}});return {number:row?.phone??'',enabled:!!row?.enabled&&!row.paused&&!!row.verifiedAt};}
export async function makeNotificationCall(message:string){if(!message.trim())throw new Error("Notification text is required.");return startCall();}
