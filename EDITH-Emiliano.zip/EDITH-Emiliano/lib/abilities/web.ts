import { commandText } from "./chat-intent";

export type WebSource = { title: string; url: string; excerpt: string };
export type WebResult = { status: "ok" | "unavailable" | "disabled"; query: string; provider: string; checkedAt: string; sources: WebSource[]; message?: string };
export function webConfiguration() {
 const provider = process.env.WEB_SEARCH_PROVIDER || "tavily";
 return { enabled: process.env.WEB_SEARCH_ENABLED !== "false", provider, missing: !["duckduckgo", "tavily"].includes(provider) ? ["WEB_SEARCH_PROVIDER"] : [] };
}
export function webQuery(prompt: string): string | null {
 const text = commandText(prompt);
 const explicit = text.match(/^(?:search (?:the )?(?:web|internet)(?: for)?|look up|find (?:web )?sources (?:for|about))\s+(.+)$/i);
 if (explicit) return explicit[1].trim();
 if (/\b(?:my|our)\s+(?:tasks?|files?|documents?|calendar|appointments?|notes?|memories|reminders?)\b/i.test(text)) return null;
 if (/\b(?:latest|current|up.to.date|recent|real.time|right now|today|tonight|this week|this month|weather|forecast|news|prices?|exchange rate|stock market)\b/i.test(text)) return text;
 return null;
}
function decode(value: string) {
 return value.replace(/&(?:amp|lt|gt|quot|apos|nbsp|#\d+|#x[\da-f]+);/gi, token => {
  const named: Record<string, string> = { "&amp;": "&", "&lt;": "<", "&gt;": ">", "&quot;": '"', "&apos;": "'", "&nbsp;": " " };
  if (named[token.toLowerCase()]) return named[token.toLowerCase()];
  const number = token.toLowerCase().startsWith("&#x") ? parseInt(token.slice(3, -1), 16) : parseInt(token.slice(2, -1), 10);
  return number > 0 && number <= 0x10ffff ? String.fromCodePoint(number) : "";
 });
}
function plain(value: string) { return decode(value.replace(/<(?:script|style)\b[^>]*>[\s\S]*?<\/(?:script|style)>/gi, "").replace(/<[^>]*>/g, " ")).replace(/\s+/g, " ").trim(); }
function publicUrl(value: string): string | null {
 try {
  let url = new URL(decode(value), "https://html.duckduckgo.com");
  if (url.hostname === "duckduckgo.com" || url.hostname.endsWith(".duckduckgo.com")) {
   const destination = url.searchParams.get("uddg");
   if (!destination) return null;
   url = new URL(destination);
  }
  if (!["http:", "https:"].includes(url.protocol) || url.username || url.password || !url.hostname.includes(".") || /^(?:\[|\d+(?:\.\d+){3}$)/.test(url.hostname) || url.hostname.endsWith(".localhost") || url.hostname.endsWith(".local") || url.hostname.endsWith(".internal")) return null;
  return url.toString();
 } catch { return null; }
}
function cleanSources(values: WebSource[]) {
 const seen = new Set<string>();
 return values.flatMap(source => {
  const url = publicUrl(source.url), title = plain(source.title).slice(0, 180), excerpt = plain(source.excerpt).slice(0, 650);
  if (!url || !title || seen.has(url)) return [];
  seen.add(url); return [{ title, url, excerpt }];
 }).slice(0, 3);
}
export function duckDuckGoSources(html: string): WebSource[] {
 const links = [...html.matchAll(/<a\b([^>]*\bclass=["'][^"']*\bresult__a\b[^"']*["'][^>]*)>([\s\S]*?)<\/a>/gi)];
 return cleanSources(links.map((link, index) => {
  const href = link[1].match(/\bhref\s*=\s*["']([^"']+)["']/i)?.[1] ?? "";
  const following = html.slice((link.index ?? 0) + link[0].length, links[index + 1]?.index ?? html.length);
  const snippet = following.match(/<(?:a|div|span)\b[^>]*\bclass=["'][^"']*\bresult__snippet\b[^"']*["'][^>]*>([\s\S]*?)<\/(?:a|div|span)>/i)?.[1] ?? "";
  return { title: link[2], url: href, excerpt: snippet };
 }));
}
class SearchLimit extends Error {}
async function fetchText(url: string, options: RequestInit = {}) {
 const response = await fetch(url, { ...options, redirect: "error", signal: AbortSignal.timeout(8000), headers: { "User-Agent": "EDITH/0.1 (personal assistant search)", ...options.headers } });
 if ([429, 432, 433].includes(response.status)) throw new SearchLimit();
 if (!response.ok || !response.body) throw new Error("Search unavailable");
 const reader = response.body.getReader(), decoder = new TextDecoder();
 let text = "", bytes = 0;
 try {
  while (true) {
   const part = await reader.read(); if (part.done) break;
   bytes += part.value.byteLength;
   if (bytes > 1_000_000) { await reader.cancel(); throw new Error("Search response too large"); }
   text += decoder.decode(part.value, { stream: true });
  }
  return text + decoder.decode();
 } finally { reader.releaseLock(); }
}
async function wikipedia(query: string) {
 const parameters = new URLSearchParams({ action: "query", generator: "search", gsrsearch: query, gsrlimit: "3", prop: "extracts|info", explaintext: "1", exintro: "1", exchars: "700", inprop: "url", format: "json", formatversion: "2" });
 const data = JSON.parse(await fetchText("https://en.wikipedia.org/w/api.php?" + parameters));
 const pages = Array.isArray(data.query?.pages) ? data.query.pages : [];
 return cleanSources(pages.map((page: { title?: string; fullurl?: string; extract?: string }) => ({ title: page.title ?? "", url: page.fullurl ?? "", excerpt: page.extract ?? "" })));
}
export async function searchWeb(query: string): Promise<WebResult> {
 const config = webConfiguration();
 const result: WebResult = { status: "unavailable", query, provider: config.provider, checkedAt: new Date().toISOString(), sources: [] };
 if (!config.enabled) return { ...result, status: "disabled", message: "Web search is disabled. I cannot verify current internet facts for this question." };
 if (query.length > 400) return { ...result, message: "Use a shorter web query, up to 400 characters. I have not verified this question online." };
 if (config.missing.length) return { ...result, message: `Web search needs ${config.missing.join(", ")} in your private .env file. I have not verified this question online.` };
 try {
  if (config.provider === "tavily") {
   const key = process.env.TAVILY_API_KEY;
   const data = JSON.parse(await fetchText("https://api.tavily.com/search", { method: "POST", headers: { "Content-Type": "application/json", "X-Client-Source": key ? "edith" : "edith-keyless", ...(key ? { Authorization: "Bearer " + key } : { "X-Tavily-Access-Mode": "keyless" }) }, body: JSON.stringify({ query, max_results: 3, search_depth: "basic", include_answer: false, include_raw_content: false }) }));
   if (data.error && /limit|quota|cap/i.test(String(data.error.code))) throw new SearchLimit();
   if (Array.isArray(data.results)) result.sources = cleanSources(data.results.map((item: { title?: string; url?: string; content?: string }) => ({ title: item.title ?? "", url: item.url ?? "", excerpt: item.content ?? "" })));
  } else {
   try { result.sources = duckDuckGoSources(await fetchText("https://html.duckduckgo.com/html/?" + new URLSearchParams({ q: query }))); } catch { /* A blocked provider must not become a guessed answer. */ }
   if (!result.sources.length && !/\b(?:latest|current|recent|today|tonight|weather|forecast|news|prices?|exchange rate|stock market)\b/i.test(query)) {
    result.sources = await wikipedia(query);
    result.provider = "Wikipedia";
   }
  }
 } catch (error) {
  if (error instanceof SearchLimit) result.message = "Web search reached its usage limit. Please wait and retry, or configure your own Tavily key for your account's allowance. I have not verified current facts for this question.";
 }
 result.checkedAt = new Date().toISOString();
 if (result.sources.length) result.status = "ok";
 else result.message ??= "I couldn't retrieve usable web sources for this question. The search provider may be unavailable or blocking automated requests. I cannot verify current facts here; please retry later.";
 return result;
}
function markdown(value: string) { return value.replace(/([\\`*_{}\[\]<>])/g, "\\$1"); }
export function webReply(result: WebResult, timezone = "Europe/Helsinki") {
 if (result.status !== "ok") return result.message ?? "I could not verify this question online.";
 const checked = new Date(result.checkedAt).toLocaleString("en-GB", { timeZone: timezone, hour12: false });
 const sources = result.sources.map((source, index) => `${index + 1}. [${markdown(source.title)}](<${source.url.replace(/>/g, "%3E")}>)\n\n   ${markdown(source.excerpt || "No excerpt was supplied; open the source to read it.")}`).join("\n\n");
 return `Web sources for “${markdown(result.query)}”:\n\n${sources}\n\nRetrieved ${checked} (${timezone}) via ${result.provider === "duckduckgo" ? "DuckDuckGo" : result.provider === "tavily" ? "Tavily" : result.provider}. These are search excerpts; I have not opened the full pages. Check the source's publication date before treating an excerpt as current.`;
}
