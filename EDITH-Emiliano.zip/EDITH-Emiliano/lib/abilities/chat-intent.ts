export function commandText(prompt:string){
 return prompt.trim().replace(/^(?:(?:can|could|would|will)\s+(?:you|u)\s+(?:please\s+)?|please\s+|edith[,\s]+)/i,'').replace(/[.!?]+$/,'').trim();
}
export function isFilePickerCommand(prompt:string){return /^(?:please\s+)?(?:upload|attach|add|import)\s+(?:(?:a|an?|some|my|several|these)\s+)?(?:files?|documents?|images?|photos?|pictures?)(?:\s+(?:for analysis|to edith))?[.!\s]*$/i.test(commandText(prompt));}
