import {z} from 'zod';
export const timerInput=z.object({label:z.string().trim().min(1).max(200).default('Timer'),seconds:z.number().int().min(1).max(604800),notifyPhone:z.boolean().default(false)});
export const phoneInput=z.object({number:z.string().regex(/^\+[1-9]\d{6,14}$/).or(z.literal('')),enabled:z.boolean()}).refine(v=>!v.enabled||!!v.number,{message:'Enter a phone number with country code.'});
export const analysisInput=z.object({fileIds:z.array(z.string()).min(1).max(8),instruction:z.string().trim().min(1).max(4000),createTasks:z.boolean().default(false)});
export function parseTimer(prompt:string){
 const m=prompt.trim().match(/^(?:please\s+)?(?:set|start)(?:\s+a)?\s+timer\s+(?:for\s+)?(\d+(?:\.\d+)?)\s*(seconds?|secs?|minutes?|mins?|hours?|hrs?)(?:\s+(?:called|named|for)\s+(.+))?[.!]?$/i);
 if(!m)return null;
 const multiplier=/^(min)/i.test(m[2])?60:/^(h)/i.test(m[2])?3600:1;
 return timerInput.parse({label:m[3]?.replace(/[.!]$/,'')||'Timer',seconds:Math.round(Number(m[1])*multiplier)});
}
