import { commandText } from "./chat-intent";
import { validTimezone } from "@/lib/time";

const places: Record<string, string> = {
 helsinki: "Europe/Helsinki", finland: "Europe/Helsinki", london: "Europe/London", uk: "Europe/London",
 paris: "Europe/Paris", berlin: "Europe/Berlin", rome: "Europe/Rome", madrid: "Europe/Madrid",
 "new york": "America/New_York", "los angeles": "America/Los_Angeles", chicago: "America/Chicago",
 tokyo: "Asia/Tokyo", singapore: "Asia/Singapore", sydney: "Australia/Sydney", utc: "UTC", gmt: "UTC",
};
export function currentClock(timezone = "Europe/Helsinki", now = new Date()) {
 const zone = validTimezone(timezone) ? timezone : "Europe/Helsinki";
 return {
  timezone: zone, iso: now.toISOString(),
  time: new Intl.DateTimeFormat("en-GB", { timeZone: zone, hour: "2-digit", minute: "2-digit", second: "2-digit", hourCycle: "h23" }).format(now),
  date: new Intl.DateTimeFormat("en-GB", { timeZone: zone, weekday: "long", day: "numeric", month: "long", year: "numeric" }).format(now),
 };
}
export function clockReply(prompt: string, timezone = "Europe/Helsinki", now = new Date()): { content: string; source: string | null } | null {
 let text = commandText(prompt).replace(/’/g, "'").toLowerCase().replace(/^(?:tell|give|show) me\s+/, "");
 const place = text.match(/\s+(?:in|for)\s+(.+)$/);
 if (place) text = text.slice(0, place.index).trim();
 text = text.replace(/\s+(?:(?:right )?now|currently|here|please)$/, "").trim();
 const time = /^(?:what time (?:is it|it is)|what(?:'s| is) (?:the )?(?:current )?(?:local )?time(?: of (?:the )?day)?|(?:the )?(?:current )?(?:local )?time|time of (?:the )?day|is it (?:morning|afternoon|evening|night|day)(?: or (?:morning|afternoon|evening|night|day))*)(?: today)?$/i.test(text);
 const date = /^(?:what(?:'s| is) (?:the )?(?:current |today's )?(?:date|day|date and time|time and date)|what (?:day|date) (?:is it|is today|are we on)|(?:current )?(?:date|date and time|time and date)|what day of the week is it)(?: today)?$/i.test(text);
 if (!time && !date) return null;
 let zone = timezone;
 if (place) {
  const requested = place[1].replace(/\s+(?:right now|now|currently|please)$/, "").trim();
  zone = /^(?:me|my timezone|my location)$/.test(requested) ? timezone : places[requested] ?? requested;
  if (!validTimezone(zone)) return { content: "Which timezone should I use? Give a city such as Helsinki or an IANA timezone such as Europe/Helsinki.", source: null };
 }
 const clock = currentClock(zone, now);
 const answer = date && !/\btime\b/.test(text) ? `Today is ${clock.date} in ${clock.timezone}.` : `It's ${clock.time} on ${clock.date} in ${clock.timezone}.`;
 return { content: answer + "\n\nSource: your computer clock, read when you asked.", source: "Computer clock · " + clock.timezone };
}
