import sharp from "sharp";
import mammoth from "mammoth";
import ExcelJS from "exceljs";
import {randomUUID} from "node:crypto";
import {execFile} from "node:child_process";
import {promisify} from "node:util";
import {mkdir,writeFile,rm} from "node:fs/promises";
import {resolve} from "node:path";
import {db} from "@/lib/db";
import {chunkText} from "@/lib/retrieval";
import {safeFilename} from "@/lib/validation";
import {privateRoot} from "@/lib/security/keys";
import {HttpError} from "@/lib/http";
const run=promisify(execFile);
type Section={locator:string;content:string};
export function checkOfficeArchive(bytes:Buffer){
 let expanded=0,count=0;
 for(let index=0;index+46<bytes.length;index++){
  if(bytes.readUInt32LE(index)!==0x02014b50)continue;
  expanded+=bytes.readUInt32LE(index+24);count++;
  index+=45+bytes.readUInt16LE(index+28)+bytes.readUInt16LE(index+30)+bytes.readUInt16LE(index+32);
 }
 if(expanded>100_000_000||count>10000||expanded>Math.max(bytes.length*300,10_000_000))throw new HttpError("This Office archive expands beyond the safe document limit.");
}
export async function importFile(file:File,sourcePath?:string){
 if(file.size>10_000_000||!file.size)throw new HttpError("Use a nonempty file under 10 MB.");
 const name=safeFilename(file.name),bytes=Buffer.from(await file.arrayBuffer());
 let content="",mimeType="text/plain",imageData:string|null=null,extractionWarning="";
 let sections:Section[]=[];
 const root=resolve(privateRoot(),"documents");
 await mkdir(root,{recursive:true,mode:0o700});
 const storageKey=randomUUID();
 const original=resolve(root,storageKey);
 await writeFile(original,bytes,{mode:0o600,flag:"wx"});
 try{
  if(/\.(png|jpe?g|webp)$/i.test(name)){
   const image=sharp(bytes,{limitInputPixels:25_000_000});const meta=await image.metadata();
   if(!["png","jpeg","webp"].includes(meta.format??""))throw new HttpError("The image format could not be decoded.");
   imageData=(await image.rotate().resize(1024,1024,{fit:"inside",withoutEnlargement:true}).png().toBuffer()).toString("base64");
   mimeType="image/"+(meta.format==="jpeg"?"jpeg":meta.format);
   content=`Image: ${name}. Not yet analyzed.`;extractionWarning="Image analysis requires a configured local Moondream vision model.";
  }else if(/\.pdf$/i.test(name)){
   mimeType="application/pdf";
   const parse=async(data:Uint8Array)=>{const {PDFParse}=await import("pdf-parse");const parser=new PDFParse({data});try{return await parser.getText({first:200});}finally{await parser.destroy();}};
   let result=await parse(new Uint8Array(bytes));
   let unreadable=result.pages.filter(page=>!page.text.trim());
   if(unreadable.length&&process.env.OCR_COMMAND){
    const output=original+".ocr.pdf";
    try{
     if(!process.env.OCR_COMMAND.startsWith("/"))throw new HttpError("OCR_COMMAND must be an absolute path to the local OCRmyPDF executable.");
     await run(process.env.OCR_COMMAND,["--skip-text","--quiet","--jobs","2",original,output],{timeout:120000,maxBuffer:100000});
     const {readFile}=await import("node:fs/promises");result=await parse(new Uint8Array(await readFile(output)));
     extractionWarning="OCR was used. Extracted text may contain errors; inspect the original pages.";
     unreadable=result.pages.filter(page=>!page.text.trim());
    }catch{extractionWarning="OCR failed. Unreadable pages are identified below; the original PDF is preserved.";}finally{await rm(output,{force:true});}
   }
   if(unreadable.length)extractionWarning+=` Unreadable or blank pages: ${unreadable.map(page=>page.num).join(", ")}. No text was extracted from these pages.`;
   if(result.total>result.pages.length)extractionWarning+=` Only ${result.pages.length} of ${result.total} pages were extracted (200-page limit).`;
   sections=result.pages.map(page=>({locator:`page ${page.num}`,content:page.text.trim()||"[No readable text extracted from this page.]"}));
   content=sections.map(section=>`[${section.locator}]\n${section.content}`).join("\n\n");
  }else if(/\.docx$/i.test(name)){
   checkOfficeArchive(bytes);const result=await mammoth.extractRawText({buffer:bytes});content=result.value;
   mimeType="application/vnd.openxmlformats-officedocument.wordprocessingml.document";
   extractionWarning=result.messages.length?"Some Word elements could not be extracted. Check the original document.":"Word page numbers are not preserved; citations use text sections.";
  }else if(/\.xlsx$/i.test(name)){
   checkOfficeArchive(bytes);const workbook=new ExcelJS.Workbook();await workbook.xlsx.load(new Uint8Array(bytes).buffer);
   workbook.eachSheet(sheet=>{
    let cells=0;const rows:string[]=[];
    sheet.eachRow((row,n)=>{if(n>10000)throw new HttpError("A sheet exceeds 10,000 rows.");const values:string[]=[];row.eachCell({includeEmpty:true},cell=>{cells++;if(cells>100000)throw new HttpError("A sheet exceeds 100,000 cells.");values.push(cell.text);});rows.push(`Row ${n}: `+values.join(" | "));});
    sections.push({locator:`sheet ${sheet.name}`,content:rows.join("\n")});
   });content=sections.map(section=>`[${section.locator}]\n${section.content}`).join("\n\n");
   mimeType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";extractionWarning="Formulas use stored results; macros are never executed.";
  }else if(/\.(txt|md|json|csv)$/i.test(name)){
   content=new TextDecoder("utf-8",{fatal:true}).decode(bytes);if(/\.json$/i.test(name))JSON.parse(content);
   if(/\.csv$/i.test(name)){mimeType="text/csv";sections=content.split(/\r?\n/).filter(Boolean).map((line,index)=>({locator:`row ${index+1}`,content:line}));}
  }else throw new HttpError("Supported: PDF, DOCX, XLSX, TXT, Markdown, JSON, CSV, PNG, JPG, and WebP. Convert older DOC/XLS files first.");
  if(!content.trim())throw new HttpError("No readable content was extracted. The upload was not saved; check its format or configure OCR.");
  if(Buffer.byteLength(content)>1_000_000)throw new HttpError("Extracted text exceeds 1 MB; split the document into smaller files.");
  if(!sections.length)sections=chunkText(content).map((content,index)=>({locator:`section ${index+1}`,content}));
  const chunks=sections.flatMap(section=>chunkText(section.content).map(content=>({content,locator:section.locator}))).map((chunk,position)=>({...chunk,position}));
  const data={name,content,mimeType,imageData,storageKey,extractionWarning,chunks:{create:chunks}};
  if(sourcePath){
   const existing=await db.knowledgeFile.findUnique({where:{sourcePath}});
   if(existing){const result=await db.$transaction(async tx=>{await tx.knowledgeChunk.deleteMany({where:{fileId:existing.id}});return tx.knowledgeFile.update({where:{id:existing.id},data,select:{id:true,name:true,mimeType:true,extractionWarning:true}});});return result;}
  }
  return await db.knowledgeFile.create({data:{sourcePath,...data},select:{id:true,name:true,mimeType:true,extractionWarning:true}});
 }catch(error){await rm(original,{force:true});if(error instanceof HttpError)throw error;throw new HttpError("The file could not be extracted. Check for a corrupt, encrypted, or unsupported document.");}
}
