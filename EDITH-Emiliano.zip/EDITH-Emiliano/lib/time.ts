import { Temporal } from "@js-temporal/polyfill";
export const validTimezone = (value: string) => { try { Temporal.Now.zonedDateTimeISO(value); return true; } catch { return false; } };
export function localDateTime(value: string, timezone: string) {
  try { return new Date(Temporal.PlainDateTime.from(value).toZonedDateTime(timezone, { disambiguation: "reject" }).epochMilliseconds); }
  catch { throw new Error("That local time is invalid or ambiguous because of a clock change. Choose another time or supply an explicit UTC offset."); }
}
export function nextRecurrence(date: Date, recurrence: string, timezone: string, after = new Date()) {
  if (recurrence === "none") return null;
  let current = Temporal.Instant.fromEpochMilliseconds(date.getTime()).toZonedDateTimeISO(timezone);
  do { current = current.add(recurrence === "daily" ? { days: 1 } : recurrence === "weekly" ? { weeks: 1 } : { months: 1 }); }
  while (current.epochMilliseconds <= after.getTime());
  return new Date(current.epochMilliseconds);
}
export function nextCallTime(localTime: string, timezone: string, days: number[], now = new Date()) {
  const current = Temporal.Instant.fromEpochMilliseconds(now.getTime()).toZonedDateTimeISO(timezone);
  for (let offset = 0; offset < 8; offset++) {
    const day = current.toPlainDate().add({ days: offset });
    if (!days.includes(day.dayOfWeek)) continue;
    const time = day.toPlainDateTime(Temporal.PlainTime.from(localTime)).toZonedDateTime(timezone, { disambiguation: "compatible" });
    if (time.epochMilliseconds > now.getTime()) return new Date(time.epochMilliseconds);
  }
  throw new Error("Select at least one calling day.");
}
export function todayBounds(timezone: string, now = new Date()) {
  const day = Temporal.Instant.fromEpochMilliseconds(now.getTime()).toZonedDateTimeISO(timezone).startOfDay();
  return { start: new Date(day.epochMilliseconds), end: new Date(day.add({ days: 1 }).epochMilliseconds) };
}
export function quietUntil(now: Date, timezone: string, start: string, end: string) {
  const local = Temporal.Instant.fromEpochMilliseconds(now.getTime()).toZonedDateTimeISO(timezone);
  const clock = local.toPlainTime().toString().slice(0, 5);
  const quiet = start < end ? clock >= start && clock < end : clock >= start || clock < end;
  if (!quiet || start === end) return null;
  const day = local.toPlainDate().add({ days: start > end && clock >= start ? 1 : 0 });
  return new Date(day.toPlainDateTime(Temporal.PlainTime.from(end)).toZonedDateTime(timezone).epochMilliseconds);
}
