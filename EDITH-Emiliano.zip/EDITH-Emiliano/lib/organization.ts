import * as chrono from "chrono-node";
import { Temporal } from "@js-temporal/polyfill";
import { db } from "@/lib/db";
import { HttpError } from "@/lib/http";
import { taskInput } from "@/lib/validation";
import { nextRecurrence, todayBounds } from "@/lib/time";
export async function cancelReminderJobs(ids: string[], client: Pick<typeof db, "scheduledJob"> = db) {
  for (const id of ids) await client.scheduledJob.updateMany({ where: { status: "WAITING", dedupeKey: { startsWith: `reminder:${id}:` } }, data: { status: "CANCELLED" } });
}
export async function saveTask(input: unknown, id?: string) {
  const { reminderMinutes, ...data } = taskInput.parse(input);
  return db.$transaction(async tx => {
  if (data.parentId === id && id) throw new HttpError("A task cannot be its own subtask.");
  if (data.projectId && !await tx.project.findUnique({ where: { id: data.projectId } })) throw new HttpError("Choose an existing project.");
  if (data.parentId && !await tx.task.findUnique({ where: { id: data.parentId } })) throw new HttpError("Choose an existing parent task.");
  if (id && data.parentId) {
    let current: string | null = data.parentId;
    const visited = new Set<string>([id]);
    while (current) { if (visited.has(current)) throw new HttpError("Subtasks cannot form a cycle."); visited.add(current); current = (await tx.task.findUnique({ where: { id: current } }))?.parentId ?? null; }
  }
  if (data.startDate && data.dueDate && new Date(data.startDate) > new Date(data.dueDate)) throw new HttpError("A start date must be before the due date.");
  const previous = id ? await tx.task.findUniqueOrThrow({ where: { id } }) : null;
  const values = { ...data, prioritySource: previous && previous.priority === data.priority ? previous.prioritySource : "user", dueDate: data.dueDate ? new Date(data.dueDate) : null, startDate: data.startDate ? new Date(data.startDate) : null, completedAt: data.status === "COMPLETED" ? new Date() : null };
  const task = id ? await tx.task.update({ where: { id }, data: values }) : await tx.task.create({ data: values });
  if (previous && previous.status !== "COMPLETED" && task.status === "COMPLETED" && previous.recurrence !== "none" && previous.dueDate) {
    const settings = await tx.userSettings.findUnique({ where: { id: "local" } });
    const dueDate = nextRecurrence(previous.dueDate, previous.recurrence, settings?.timezone ?? "Europe/Helsinki");
    const nextTask = await tx.task.create({ data: { ...values, status: "PENDING", completedAt: null, dueDate, startDate: null } });
    const reminders = await tx.reminder.findMany({ where: { taskId: task.id, active: true } });
    if (dueDate) for (const reminder of reminders) {
      const nextDue = new Date(dueDate.getTime() - (previous.dueDate.getTime() - reminder.dueAt.getTime()));
      const copy = await tx.reminder.create({ data: { title: nextTask.title, taskId: nextTask.id, dueAt: nextDue, timezone: reminder.timezone, channels: reminder.channels } });
      await queueReminder(copy.id, nextDue, JSON.parse(copy.channels), tx);
    }
  }
  if (["COMPLETED", "ARCHIVED"].includes(task.status) || previous?.dueDate?.getTime() !== task.dueDate?.getTime() || reminderMinutes !== undefined) {
    const old = await tx.reminder.findMany({ where: { taskId: task.id, active: true } });
    await tx.reminder.updateMany({ where: { taskId: task.id }, data: { active: false } });
    await cancelReminderJobs(old.map(r => r.id), tx);
  }
  if (reminderMinutes !== undefined && task.dueDate && !["COMPLETED", "ARCHIVED"].includes(task.status)) {
    const settings = await tx.userSettings.findUnique({ where: { id: "local" } });
    const dueAt = new Date(task.dueDate.getTime() - reminderMinutes * 60000);
    const reminder = await tx.reminder.create({ data: { title: task.title, dueAt, taskId: task.id, timezone: settings?.timezone ?? "Europe/Helsinki" } });
    await queueReminder(reminder.id, dueAt, ["inapp"], tx);
  }
  return task;
  });
}
export async function queueReminder(id: string, dueAt: Date, channels: string[], client: Pick<typeof db, "scheduledJob"> = db) {
  for (const channel of channels) {
    const dedupeKey = `reminder:${id}:${dueAt.toISOString()}:${channel}`;
    await client.scheduledJob.upsert({ where: { dedupeKey }, update: {}, create: { kind: "REMINDER", dueAt, dedupeKey, payload: JSON.stringify({ reminderId: id, channel, occurrence: dueAt.toISOString() }) } });
  }
}
export function parseNaturalTask(prompt: string, timezone: string, now = new Date(), projects: { id: string; title: string }[] = []) {
  const match = prompt.trim().replace(/^E\.?D\.?I\.?T\.?H\.?[,\s]+/i, "").match(/^(?:please\s+)?(?:can you\s+)?(?:remind me to|add (?:a )?task to|create (?:a )?task to)\s+(.+)/i);
  if (!match) return null;
  let text = match[1].replace(/[.!]$/, "");
  let projectId: string | undefined;
  for (const project of [...projects].sort((a, b) => b.title.length - a.title.length)) {
    const escaped = project.title.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const mention = new RegExp(`\\b(?:in|for) (?:the )?${escaped} project\\b`, "i");
    if (mention.test(text)) {
      if (projectId) return { question: "Which project should this task belong to? Please name one saved project." };
      projectId = project.id; text = text.replace(mention, "").replace(/\s+/g, " ").trim();
    }
  }
  const localNow = Temporal.Instant.fromEpochMilliseconds(now.getTime()).toZonedDateTimeISO(timezone);
  const dates = chrono.parse(text, { instant: now, timezone: localNow.offsetNanoseconds / 60e9 }, { forwardDate: true });
  if (!dates.length) {
    if (/\b(?:tomorrow|today|next|at|morning|evening|tonight)\b/i.test(text)) return { question: "What date and time should I use? Please include AM/PM or a 24-hour time." };
    return { task: { title: text, dueDate: null, projectId } };
  }
  const date = dates[0];
  if (!date.start.isCertain("hour") || (!date.start.isCertain("meridiem") && !/\b(?:[01]?\d|2[0-3]):[0-5]\d\b|\b(?:1[3-9]|2[0-3])\b/.test(date.text))) return { question: `What time do you mean by “${date.text}”? Please include AM/PM or a 24-hour time.`, pending: { title: text.slice(0, date.index).trim().replace(/\s+(?:on|by|at|for)$/, ""), date: `${date.start.get("year")}-${String(date.start.get("month")).padStart(2, "0")}-${String(date.start.get("day")).padStart(2, "0")}`, projectId } };
  const parts = Object.fromEntries(["year", "month", "day", "hour", "minute"].map(key => [key, date.start.get(key as "year")]));
  try {
    const due = Temporal.ZonedDateTime.from({ timeZone: timezone, year: parts.year!, month: parts.month!, day: parts.day!, hour: parts.hour!, minute: parts.minute!, second: 0 }, { disambiguation: "reject" });
    const title = text.slice(0, date.index).trim().replace(/\s+(?:on|by|at|for)$/, "") || text;
    return { task: { title, dueDate: new Date(due.epochMilliseconds).toISOString(), projectId } };
  } catch { return { question: "That local time crosses a daylight saving clock change. Please choose an unambiguous time." }; }
}
export async function dailyBriefing(topics = ["appointments", "tasks", "deadlines"], overrideTimezone?: string) {
  const settings = await db.userSettings.findUnique({ where: { id: "local" } });
  const timezone = overrideTimezone ?? settings?.timezone ?? "Europe/Helsinki";
  const { start, end } = todayBounds(timezone);
  const [tasks, events] = await Promise.all([
    db.task.findMany({ where: { status: { in: ["PENDING", "ACTIVE"] } }, orderBy: { dueDate: "asc" } }),
    db.calendarEvent.findMany({ where: { cancelled: false, startAt: { gte: start, lt: end } }, orderBy: { startAt: "asc" } }),
  ]);
  const due = tasks.filter(t => t.dueDate && t.dueDate < end);
  const next = events.find(e => e.endAt > new Date());
  const greeting = `Hello, ${settings?.displayName ?? "Emiliano"}.`;
  const update = [next ? `Your next appointment is ${next.title}${next.allDay ? " (all day)" : " at " + next.startAt.toLocaleTimeString("en-GB", { timeZone: timezone, hour: "2-digit", minute: "2-digit" })}.` : "", due.length ? `${due.length} task${due.length === 1 ? " is" : "s are"} due or overdue.` : ""].filter(Boolean).join(" ") || "How can I help you today?";
  const briefing = [topics.includes("appointments") ? events.length ? `Today's appointments: ${events.slice(0, 5).map(e => `${e.title} ${e.allDay ? "(all day)" : "at " + e.startAt.toLocaleTimeString("en-GB", { timeZone: timezone, hour: "2-digit", minute: "2-digit" })}`).join("; ")}.` : "No appointments are saved for today." : "", topics.includes("tasks") ? tasks.length ? `Important tasks: ${tasks.filter(t => t.priority === "HIGH" || t.dueDate && t.dueDate < end).slice(0, 5).map(t => t.title).join("; ") || "No high-priority or due tasks"}.` : "Your task list is clear." : "", topics.includes("deadlines") && due.length ? `There are ${due.length} due or overdue tasks. ${due.slice(0, 3).map(t => t.title).join("; ")}.` : ""].filter(Boolean).join(" ");
  return { greeting, update, briefing, tasks, events };
}
