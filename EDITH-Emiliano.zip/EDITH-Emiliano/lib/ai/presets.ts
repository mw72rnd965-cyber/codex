import type { ProviderConfig } from "./provider";
export const GROQ_BASE_URL = "https://api.groq.com/openai/v1";
export const GROQ_DEFAULT_MODEL = "openai/gpt-oss-20b";
export function groqConfiguration(): ProviderConfig {
  return { provider: "openai-compatible", service: "groq", baseUrl: GROQ_BASE_URL, model: process.env.GROQ_MODEL?.trim() || GROQ_DEFAULT_MODEL, apiKey: process.env.GROQ_API_KEY, maxTokens: 2048 };
}
