import { externalContextAllowed } from "@/lib/privacy";
import { getModelConfiguration } from "@/lib/ai/config";
import { db } from "@/lib/db";
const present = (...names: string[]) => names.filter(name => !process.env[name]);
export function configuration() {
  return {
    ai: { missing: process.env.AI_PROVIDER === "local" ? present("LOCAL_AI_MODEL") : present("AI_MODEL", "AI_API_KEY"), demo: !process.env.AI_PROVIDER || process.env.AI_PROVIDER === "mock" },
    voice: { missing: present("ELEVENLABS_API_KEY", "ELEVENLABS_VOICE_ID") },
    calls: { missing: present("TWILIO_ACCOUNT_SID", "TWILIO_AUTH_TOKEN", "TWILIO_FROM_NUMBER", "TWILIO_VERIFY_SERVICE_SID", "EDITH_PUBLIC_URL", "ELEVENLABS_API_KEY", "ELEVENLABS_VOICE_ID") },
    sms: { missing: present("TWILIO_ACCOUNT_SID", "TWILIO_AUTH_TOKEN", "TWILIO_FROM_NUMBER") },
    calendar: { missing: present("GOOGLE_CLIENT_ID", "GOOGLE_CLIENT_SECRET", "EDITH_PUBLIC_URL") },
    push: { missing: present("VAPID_PUBLIC_KEY", "VAPID_PRIVATE_KEY", "VAPID_SUBJECT") },
    email: { missing: present("SMTP_HOST", "SMTP_USER", "SMTP_PASSWORD", "SMTP_FROM", "NOTIFICATION_EMAIL") },
    ocr: { missing: present("OCR_COMMAND"), note: "A local OCRmyPDF executable is supported; no document is sent to an OCR service." },
  };
}
export async function integrationStatus() {
  const config = configuration();
  const model = await getModelConfiguration();
  config.ai.demo = model.provider === "mock";
  const calendar = await db.calendarConnection.findUnique({ where: { id: "google" }, select: { calendars: true, writable: true, syncedAt: true, error: true } });
  const heartbeat = await db.systemSetting.findUnique({ where: { key: "scheduler.heartbeat" } });
  const connected = !!heartbeat && Date.now() - Number(heartbeat.value) < 60000;
  return { ...config, externalContext: await externalContextAllowed(), calendar: { ...config.calendar, connected: !!calendar, connection: calendar }, scheduler: { connected, lastSeen: heartbeat ? new Date(Number(heartbeat.value)).toISOString() : null }, push: { ...config.push, publicKey: process.env.VAPID_PUBLIC_KEY ?? null, subscriptions: await db.pushSubscription.count() } };
}
