import { createHmac } from "node:crypto";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { resolve } from "node:path";
import { db } from "@/lib/db";
import { hashToken } from "@/lib/auth";
import { equal, privateRoot, sign } from "@/lib/security/keys";
import { HttpError } from "@/lib/http";
import { configuration } from "./status";
import { elevenSpeech } from "./voice";
import { dailyBriefing } from "@/lib/organization";

export async function twilio(path: string, body: URLSearchParams) {
  const sid = process.env.TWILIO_ACCOUNT_SID, token = process.env.TWILIO_AUTH_TOKEN;
  if (!sid || !token || !/^AC[\da-f]{32}$/i.test(sid)) throw new HttpError("Configure the Twilio account and authentication token on the server.", 503);
  const hostname = path.startsWith("v2/Services/") ? "verify.twilio.com" : "api.twilio.com";
  const response = await fetch(`https://${hostname}/` + path, { method: "POST", headers: { Authorization: "Basic " + Buffer.from(`${sid}:${token}`).toString("base64"), "Content-Type": "application/x-www-form-urlencoded" }, body, signal: AbortSignal.timeout(20000) });
  if (!response.ok) throw new HttpError(`Twilio rejected the request (HTTP ${response.status}). Check credentials, balance, and verified recipients.`, 503);
  return response.json();
}
export async function verifyPhone(code?: string) {
  const schedule = await db.callSchedule.upsert({ where: { id: "local" }, create: {}, update: {} });
  if (!schedule.phone || !process.env.TWILIO_VERIFY_SERVICE_SID) throw new HttpError("Save an international phone number and configure TWILIO_VERIFY_SERVICE_SID first.");
  const resource = code ? "VerificationCheck" : "Verifications";
  const result = await twilio(`v2/Services/${process.env.TWILIO_VERIFY_SERVICE_SID}/${resource}`, new URLSearchParams(code ? { To: schedule.phone, Code: code } : { To: schedule.phone, Channel: "sms" }));
  if (code && result.status === "approved") {
    await db.callSchedule.update({ where: { id: "local" }, data: { verifiedAt: new Date() } });
    return { verified: true };
  }
  if (code) throw new HttpError("The verification code was not accepted.");
  return { verified: false, status: result.status };
}
// Verify API uses a dedicated hostname, rather than the voice/SMS REST hostname.
export async function verifyTwilioRequest(request: Request, form: URLSearchParams) {
  if (!process.env.TWILIO_AUTH_TOKEN || !process.env.EDITH_PUBLIC_URL) throw new HttpError("Calling webhooks are not configured.", 503);
  const requested = new URL(request.url);
  const url = process.env.EDITH_PUBLIC_URL.replace(/\/$/, "") + requested.pathname + requested.search;
  let signed = url;
  for (const key of [...new Set(form.keys())].sort()) for (const value of form.getAll(key).sort()) signed += key + value;
  const signature = createHmac("sha1", process.env.TWILIO_AUTH_TOKEN).update(signed).digest("base64");
  if (!equal(signature, request.headers.get("x-twilio-signature") ?? "")) throw new HttpError("Invalid provider signature.", 403);
}
export function audioToken(callId: string, expiresAt: Date) { return sign(`call-audio:${callId}:${expiresAt.getTime()}`); }
export function publicUrl(path: string) {
  const url = process.env.EDITH_PUBLIC_URL;
  if (!url || new URL(url).protocol !== "https:") throw new HttpError("Configure a public HTTPS EDITH_PUBLIC_URL for signed calling callbacks.", 503);
  return url.replace(/\/$/, "") + path;
}
export function audioUrl(id: string, segment: string, expires: Date) { return publicUrl(`/api/call-audio/${id}?segment=${segment}&token=${audioToken(id, expires)}`); }
export async function callAudio(id: string, segment: string, text: string) {
  if (!/^[\w-]+$/.test(id) || !/^[\w-]+$/.test(segment)) throw new HttpError("Invalid audio identifier.");
  const root = resolve(privateRoot(), "calls", id);
  await mkdir(root, { recursive: true, mode: 0o700 });
  await writeFile(resolve(root, `${segment}.mp3`), await elevenSpeech(text), { mode: 0o600 });
}
export async function readCallAudio(id: string, segment: string, token: string) {
  if (!/^[\w-]+$/.test(id) || !/^[\w-]+$/.test(segment)) throw new HttpError("Audio unavailable.", 404);
  const call = await db.callRecord.findUnique({ where: { id } });
  if (!call || call.expiresAt < new Date() || !equal(hashToken(token), call.audioTokenHash)) throw new HttpError("Audio link expired.", 403);
  return readFile(resolve(privateRoot(), "calls", id, `${segment}.mp3`));
}
export async function disableCalls(paused = false) {
  await db.callSchedule.upsert({ where: { id: "local" }, create: { enabled: false, paused }, update: paused ? { paused: true } : { enabled: false, paused: false } });
  await db.scheduledJob.updateMany({ where: { kind: "DAILY_CALL", status: "WAITING" }, data: { status: "CANCELLED" } });
}
export async function startCall(jobId?: string) {
  const missing = configuration().calls.missing;
  if (missing.length) throw new HttpError("Calling needs: " + missing.join(", ") + ".", 503);
  const settings = await db.callSchedule.findUnique({ where: { id: "local" } });
  if (!settings?.enabled || settings.paused || !settings.verifiedAt || !settings.phone) throw new HttpError("Calls require a verified number and explicit opt-in; resume if paused.");
  const previous = jobId ? await db.callRecord.findUnique({ where: { scheduledJobId: jobId } }) : null;
  if (previous) return previous; // Never repeat an ambiguous or unanswered attempt.
  const recent = await db.callRecord.findFirst({ where: { createdAt: { gt: new Date(Date.now() - 60000) } } });
  if (recent) throw new HttpError("A call was attempted recently. Wait one minute before another test.", 429);
  const briefing = await dailyBriefing(JSON.parse(settings.topics), settings.timezone);
  const record = await db.callRecord.create({ data: { phone: settings.phone, scheduledJobId: jobId, briefing: briefing.briefing.slice(0, 1600), expiresAt: new Date(Date.now() + 20 * 60000), audioTokenHash: "preparing" } });
  await db.callRecord.update({ where: { id: record.id }, data: { audioTokenHash: hashToken(audioToken(record.id, record.expiresAt)) } });
  let dialing = false;
  try {
    await Promise.all(Object.entries({ welcome: "Hello, Emiliano. This is E.D.I.T.H., your AI assistant. Is now a good time for your briefing? Say yes or no.", briefing: record.briefing + " You may ask me to add a task, snooze a reminder, or say stop calling me. Otherwise, say goodbye.", goodbye: "Understood, Emiliano. Goodbye.", voicemail: "Hello. This is E.D.I.T.H. with a scheduled check-in. No private briefing will be left in voicemail.", stopped: "Scheduled calls are now disabled. Goodbye, Emiliano.", success: "Your requested change has been saved. You can review it in E.D.I.T.H. Goodbye.", ambiguous: "I need a more specific date, time, or reminder name. Please continue in E.D.I.T.H. Your existing information is unchanged. Goodbye." }).map(([segment, text]) => callAudio(record.id, segment, text)));
    const latest = await db.callSchedule.findUnique({ where: { id: "local" } });
    if (!latest?.enabled || latest.paused || latest.phone !== record.phone || !latest.verifiedAt) throw new HttpError("Calling was paused, disabled, or the number changed before dialing.");
    dialing = true;
    const result = await twilio(`2010-04-01/Accounts/${process.env.TWILIO_ACCOUNT_SID}/Calls.json`, new URLSearchParams({ To: record.phone, From: process.env.TWILIO_FROM_NUMBER!, Url: publicUrl(`/api/hooks/phone?call=${record.id}&stage=welcome`), StatusCallback: publicUrl(`/api/hooks/phone?call=${record.id}&stage=status`), "StatusCallbackEvent": "completed", MachineDetection: "Enable", TimeLimit: String(settings.maxDuration) }));
    if (!result.sid) throw new Error("Unconfirmed call result");
    return db.callRecord.update({ where: { id: record.id }, data: { providerId: result.sid, status: String(result.status).toUpperCase() } });
  } catch (error) {
    const uncertain = dialing && !(error instanceof HttpError);
    const message = error instanceof HttpError ? error.message : uncertain ? "The telephone provider did not confirm the outcome. This attempt will not be redialled automatically; check provider history." : "The call could not be prepared. Check voice and telephone connectivity.";
    await db.callRecord.update({ where: { id: record.id }, data: { status: uncertain ? "UNKNOWN" : "FAILED", error: message } });
    throw error instanceof HttpError ? error : new HttpError(message, 503);
  }
}
