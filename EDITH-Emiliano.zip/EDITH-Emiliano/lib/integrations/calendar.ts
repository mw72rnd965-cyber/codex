import { randomBytes } from "node:crypto";
import { db } from "@/lib/db";
import { decrypt, encrypt, equal, sign } from "@/lib/security/keys";
import { HttpError } from "@/lib/http";
import { publicUrl } from "./phone";
import { cancelReminderJobs, queueReminder } from "@/lib/organization";
type Tokens = { access_token: string; refresh_token?: string; expires_at: number };
export type CalendarChoice = { id: string; summary: string; accessRole: string };
export async function calendarAuthorization(writable: boolean) {
  if (!process.env.GOOGLE_CLIENT_ID || !process.env.GOOGLE_CLIENT_SECRET) throw new HttpError("Configure Google OAuth client credentials before connecting a calendar.", 503);
  const value = `${randomBytes(32).toString("hex")}.${Date.now() + 10 * 60000}.${writable ? "write" : "read"}`;
  const state = value + "." + sign(value);
  await db.systemSetting.upsert({ where: { key: "calendar.oauth" }, create: { key: "calendar.oauth", value: state }, update: { value: state } });
  const scope = writable ? "https://www.googleapis.com/auth/calendar.events https://www.googleapis.com/auth/calendar.calendarlist.readonly" : "https://www.googleapis.com/auth/calendar.readonly";
  const url = new URL("https://accounts.google.com/o/oauth2/v2/auth");
  url.search = new URLSearchParams({ client_id: process.env.GOOGLE_CLIENT_ID, redirect_uri: publicUrl("/api/hooks/calendar"), response_type: "code", scope, state, access_type: "offline", prompt: "consent" }).toString();
  return url.toString();
}
export async function finishCalendarAuthorization(code: string, state: string) {
  const stored = await db.systemSetting.findUnique({ where: { key: "calendar.oauth" } });
  const [nonce, expiry, mode, signature] = state.split(".");
  if (!stored || !equal(state, stored.value) || Number(expiry) < Date.now() || !equal(sign(`${nonce}.${expiry}.${mode}`), signature ?? "")) throw new HttpError("Calendar authorization expired or could not be verified. Connect again.", 403);
  await db.systemSetting.delete({ where: { key: "calendar.oauth" } });
  const response = await fetch("https://oauth2.googleapis.com/token", { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: new URLSearchParams({ code, client_id: process.env.GOOGLE_CLIENT_ID!, client_secret: process.env.GOOGLE_CLIENT_SECRET!, redirect_uri: publicUrl("/api/hooks/calendar"), grant_type: "authorization_code" }), signal: AbortSignal.timeout(20000) });
  if (!response.ok) throw new HttpError("Google did not complete authorization. Check the registered redirect URI and try again.", 503);
  const result = await response.json();
  const tokens: Tokens = { access_token: result.access_token, refresh_token: result.refresh_token, expires_at: Date.now() + Number(result.expires_in) * 1000 };
  await db.calendarConnection.upsert({ where: { id: "google" }, create: { encryptedTokens: encrypt(tokens), writable: mode === "write" }, update: { encryptedTokens: encrypt(tokens), writable: mode === "write", error: null } });
}
async function accessToken() {
  const connection = await db.calendarConnection.findUnique({ where: { id: "google" } });
  if (!connection) throw new HttpError("Connect a Google calendar first.");
  const tokens = decrypt<Tokens>(connection.encryptedTokens);
  if (tokens.expires_at < Date.now() + 60000) {
    if (!tokens.refresh_token) throw new HttpError("Reconnect your calendar to renew authorization.", 503);
    const response = await fetch("https://oauth2.googleapis.com/token", { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: new URLSearchParams({ client_id: process.env.GOOGLE_CLIENT_ID!, client_secret: process.env.GOOGLE_CLIENT_SECRET!, refresh_token: tokens.refresh_token, grant_type: "refresh_token" }), signal: AbortSignal.timeout(20000) });
    if (!response.ok) throw new HttpError("Calendar authorization could not be renewed. Reconnect in Integrations.", 503);
    const result = await response.json();
    tokens.access_token = result.access_token; tokens.expires_at = Date.now() + Number(result.expires_in) * 1000;
    await db.calendarConnection.update({ where: { id: "google" }, data: { encryptedTokens: encrypt(tokens) } });
  }
  return tokens.access_token;
}
export async function google(path: string, init: RequestInit = {}) {
  const response = await fetch("https://www.googleapis.com/calendar/v3/" + path, { ...init, headers: { "Content-Type": "application/json", Authorization: "Bearer " + await accessToken() }, signal: AbortSignal.timeout(20000) });
  if (!response.ok) throw new HttpError(`Calendar request was not accepted (HTTP ${response.status}). Check connection and calendar permissions.`, 503);
  return response.json();
}
export async function calendarChoices(): Promise<CalendarChoice[]> {
  const calendars: CalendarChoice[] = [];
  let page: string | undefined;
  do {
    const data = await google("users/me/calendarList?maxResults=250" + (page ? "&pageToken=" + encodeURIComponent(page) : ""));
    for (const item of data.items ?? []) calendars.push({ id: item.id, summary: item.summary, accessRole: item.accessRole });
    page = data.nextPageToken;
  } while (page);
  return calendars;
}
export async function retainSelectedCalendars(ids: string[]) {
  await db.$transaction(async tx => {
    const events = await tx.calendarEvent.findMany({ where: { source: "google", ...(ids.length ? { calendarId: { notIn: ids } } : {}) }, select: { id: true } });
    const eventIds = events.map(e => e.id);
    await tx.calendarEvent.updateMany({ where: { id: { in: eventIds } }, data: { cancelled: true } });
    const reminders = await tx.reminder.findMany({ where: { eventId: { in: eventIds } } });
    await tx.reminder.updateMany({ where: { id: { in: reminders.map(r => r.id) } }, data: { active: false } });
    await cancelReminderJobs(reminders.map(r => r.id), tx);
  });
}
export async function syncCalendar() {
  const connection = await db.calendarConnection.findUnique({ where: { id: "google" } });
  if (!connection) throw new HttpError("Connect a calendar first.");
  const selected: CalendarChoice[] = JSON.parse(connection.calendars);
  if (!selected.length) throw new HttpError("Select the calendars you authorize E.D.I.T.H. to read.");
  try {
    await retainSelectedCalendars(selected.map(c => c.id));
    const timeMin = new Date(Date.now() - 30 * 86400000).toISOString(), timeMax = new Date(Date.now() + 90 * 86400000).toISOString();
    for (const calendar of selected) {
      let page: string | undefined;
      const seen = new Set<string>();
      do {
        const query = new URLSearchParams({ singleEvents: "true", showDeleted: "true", timeMin, timeMax, maxResults: "2500", ...(page ? { pageToken: page } : {}) });
        const data = await google(`calendars/${encodeURIComponent(calendar.id)}/events?${query}`);
        for (const item of data.items ?? []) {
          const externalId = `${calendar.id}:${item.id}`;
          seen.add(externalId);
          if (item.status === "cancelled") { await db.calendarEvent.updateMany({ where: { externalId }, data: { cancelled: true } }); continue; }
          const start = item.start?.dateTime ?? item.start?.date, end = item.end?.dateTime ?? item.end?.date;
          if (!start || !end) continue;
          const values = { title: String(item.summary ?? "Untitled event").slice(0, 200), description: String(item.description ?? "").slice(0, 20000), startAt: new Date(start), endAt: new Date(end), allDay: !!item.start.date, source: "google", calendarId: calendar.id, cancelled: false };
          await db.$transaction(async tx => {
            const previous = await tx.calendarEvent.findUnique({ where: { externalId } });
            const event = await tx.calendarEvent.upsert({ where: { externalId }, create: { externalId, ...values }, update: values });
            if (previous && previous.startAt.getTime() !== event.startAt.getTime()) {
              const reminders = await tx.reminder.findMany({ where: { eventId: event.id, active: true } });
              await cancelReminderJobs(reminders.map(r => r.id), tx);
              for (const reminder of reminders) {
                const dueAt = new Date(event.startAt.getTime() - (previous.startAt.getTime() - reminder.dueAt.getTime()));
                await tx.reminder.update({ where: { id: reminder.id }, data: { title: event.title, dueAt } });
                await queueReminder(reminder.id, dueAt, JSON.parse(reminder.channels), tx);
              }
            }
          });
        }
        page = data.nextPageToken;
      } while (page);
      const disappeared = await db.calendarEvent.findMany({ where: { source: "google", calendarId: calendar.id, startAt: { gte: new Date(timeMin), lt: new Date(timeMax) } } });
      await db.calendarEvent.updateMany({ where: { id: { in: disappeared.filter(e => e.externalId && !seen.has(e.externalId)).map(e => e.id) } }, data: { cancelled: true } });
    }
    const cancelled = await db.calendarEvent.findMany({ where: { cancelled: true } });
    const reminders = await db.reminder.findMany({ where: { eventId: { in: cancelled.map(e => e.id) } } });
    await db.reminder.updateMany({ where: { id: { in: reminders.map(r => r.id) } }, data: { active: false } });
    await cancelReminderJobs(reminders.map(r => r.id));
    await db.calendarConnection.update({ where: { id: "google" }, data: { syncedAt: new Date(), error: null } });
    return { ok: true };
  } catch (error) {
    await db.calendarConnection.update({ where: { id: "google" }, data: { error: error instanceof HttpError ? error.message : "Calendar sync failed; existing events were preserved." } });
    throw error;
  }
}
