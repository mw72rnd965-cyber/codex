import { HttpError } from "@/lib/http";
import { speechText } from "@/lib/voice/text";
export async function elevenSpeech(text: string) {
  const key = process.env.ELEVENLABS_API_KEY, voice = process.env.ELEVENLABS_VOICE_ID;
  if (!key || !voice) throw new HttpError("Configure ELEVENLABS_API_KEY and ELEVENLABS_VOICE_ID on the server to enable your selected voice.", 503);
  if (!/^[a-zA-Z0-9_-]{1,100}$/.test(voice)) throw new HttpError("The server voice ID is invalid.", 503);
  const response = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${encodeURIComponent(voice)}?output_format=mp3_44100_128`, {
    method: "POST", headers: { "xi-api-key": key, "Content-Type": "application/json" },
    body: JSON.stringify({ text: speechText(text), model_id: process.env.ELEVENLABS_MODEL_ID ?? "eleven_multilingual_v2", voice_settings: { stability: 0.55, similarity_boost: 0.75 } }),
    signal: AbortSignal.timeout(60000),
  });
  if (!response.ok) throw new HttpError(`ElevenLabs did not generate speech (HTTP ${response.status}). Your text is preserved.`, 503);
  return Buffer.from(await response.arrayBuffer());
}
