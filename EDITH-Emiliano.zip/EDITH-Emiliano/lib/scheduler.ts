import webpush from "web-push";
import nodemailer from "nodemailer";
import { db } from "@/lib/db";
import { nextCallTime, nextRecurrence, quietUntil } from "@/lib/time";
import { queueReminder } from "@/lib/organization";
import { startCall, twilio } from "@/lib/integrations/phone";
import { configuration } from "@/lib/integrations/status";
import { HttpError } from "@/lib/http";
import { syncCalendar } from "@/lib/integrations/calendar";

async function deliver(title: string, body: string, channel: string, jobId: string) {
  const row = await db.notification.create({ data: { title, body, channel, jobId, status: "PROCESSING" } });
  try {
    let status = "DELIVERED", providerId: string | undefined;
    if (channel === "push") {
      if (configuration().push.missing.length) throw new HttpError("Web push keys are not configured.");
      webpush.setVapidDetails(process.env.VAPID_SUBJECT!, process.env.VAPID_PUBLIC_KEY!, process.env.VAPID_PRIVATE_KEY!);
      const subscriptions = await db.pushSubscription.findMany();
      if (!subscriptions.length) throw new HttpError("No browser has authorized push notifications.");
      for (const subscription of subscriptions) {
        try { await webpush.sendNotification(JSON.parse(subscription.value), JSON.stringify({ title, body, url: "/" })); }
        catch (error) {
          if ([404, 410].includes((error as { statusCode?: number }).statusCode ?? 0)) await db.pushSubscription.delete({ where: { id: subscription.id } });
          throw new HttpError("A push service did not accept the notification. Check browser registration.");
        }
      }
      status = "ACCEPTED"; // A push service response is not proof the device displayed it.
    } else if (channel === "email") {
      if (configuration().email.missing.length) throw new HttpError("Email delivery is not configured.");
      const port = Number(process.env.SMTP_PORT ?? 465);
      const transport = nodemailer.createTransport({ host: process.env.SMTP_HOST!, port, secure: port === 465, requireTLS: port !== 465, auth: { user: process.env.SMTP_USER!, pass: process.env.SMTP_PASSWORD! } });
      try { const result = await transport.sendMail({ from: process.env.SMTP_FROM!, to: process.env.NOTIFICATION_EMAIL!, subject: title, text: body }); providerId = result.messageId; status = "ACCEPTED"; } finally { transport.close(); }
    } else if (channel === "sms") {
      const schedule = await db.callSchedule.findUnique({ where: { id: "local" } });
      if (!schedule?.verifiedAt || !schedule.phone || configuration().sms.missing.length) throw new HttpError("SMS needs a verified number and configured Twilio account.");
      const result = await twilio(`2010-04-01/Accounts/${process.env.TWILIO_ACCOUNT_SID}/Messages.json`, new URLSearchParams({ To: schedule.phone, From: process.env.TWILIO_FROM_NUMBER!, Body: `${title}: ${body}`.slice(0, 1000) }));
      providerId = result.sid; status = "QUEUED";
    } else if (channel !== "inapp") throw new HttpError("That reminder channel is unsupported.");
    await db.notification.update({ where: { id: row.id }, data: { status, providerId } });
    return status;
  } catch (error) {
    await db.notification.update({ where: { id: row.id }, data: { status: "FAILED", body: body + "\n" + (error instanceof HttpError ? error.message : "Provider request failed; no automatic retry.") } });
    throw error;
  }
}
export async function schedulerTick(now = new Date()) {
  await db.systemSetting.upsert({ where: { key: "scheduler.heartbeat" }, create: { key: "scheduler.heartbeat", value: String(Date.now()) }, update: { value: String(Date.now()) } });
  // A crash after contacting a provider has an uncertain outcome. Never replay it automatically.
  await db.scheduledJob.updateMany({ where: { status: "PROCESSING", claimedAt: { lt: new Date(now.getTime() - 15 * 60000) } }, data: { status: "UNKNOWN", error: "The worker stopped during delivery. Check provider history before attempting again." } });
  const calendar = await db.calendarConnection.findUnique({ where: { id: "google" } });
  const lastSync = await db.systemSetting.findUnique({ where: { key: "scheduler.calendarSync" } });
  if (calendar && JSON.parse(calendar.calendars).length && (!lastSync || now.getTime() - Number(lastSync.value) > 5 * 60000)) {
    await db.systemSetting.upsert({ where: { key: "scheduler.calendarSync" }, create: { key: "scheduler.calendarSync", value: String(now.getTime()) }, update: { value: String(now.getTime()) } });
    try { await syncCalendar(); } catch { /* Status is stored on the connection; existing events remain visible. */ }
  }
  const call = await db.callSchedule.findUnique({ where: { id: "local" } });
  if (call?.enabled && !call.paused && call.verifiedAt) {
    const outstanding = await db.scheduledJob.findFirst({ where: { kind: "DAILY_CALL", status: { in: ["WAITING", "PROCESSING"] } } });
    if (!outstanding) {
      const dueAt = nextCallTime(call.localTime, call.timezone, JSON.parse(call.days), now);
      const key = `call:${dueAt.toISOString()}`;
      await db.scheduledJob.upsert({ where: { dedupeKey: key }, create: { kind: "DAILY_CALL", dedupeKey: key, dueAt, payload: "{}" }, update: {} });
    }
  } else await db.scheduledJob.updateMany({ where: { kind: "DAILY_CALL", status: "WAITING" }, data: { status: "CANCELLED" } });
  const waiting = await db.scheduledJob.findMany({ where: { status: "WAITING", dueAt: { lte: now } }, orderBy: { dueAt: "asc" }, take: 20 });
  for (const job of waiting) {
    const claim = await db.scheduledJob.updateMany({ where: { id: job.id, status: "WAITING" }, data: { status: "PROCESSING", claimedAt: now } });
    if (!claim.count) continue;
    try {
      const prefs = await db.userSettings.findUnique({ where: { id: "local" } });
      const quiet = prefs?.quietHours ? quietUntil(now, prefs.timezone, prefs.quietStart, prefs.quietEnd) : null;
      if (quiet) { await db.scheduledJob.update({ where: { id: job.id }, data: { status: "WAITING", dueAt: quiet, claimedAt: null, result: "Deferred until quiet hours end." } }); continue; }
      let result: string;
      if (job.kind === "REMINDER") {
        const { reminderId, channel, occurrence } = JSON.parse(job.payload) as { reminderId: string; channel: string; occurrence?: string };
        const reminder = await db.reminder.findUnique({ where: { id: reminderId } });
        const task = reminder?.taskId ? await db.task.findUnique({ where: { id: reminder.taskId } }) : null;
        const event = reminder?.eventId ? await db.calendarEvent.findUnique({ where: { id: reminder.eventId } }) : null;
        if (!reminder?.active || reminder.taskId && (!task || ["COMPLETED", "ARCHIVED"].includes(task.status)) || reminder.eventId && (!event || event.cancelled)) {
          await db.scheduledJob.update({ where: { id: job.id }, data: { status: "CANCELLED" } }); continue;
        }
        const occurrenceDate = occurrence ? new Date(occurrence) : reminder.dueAt;
        const next = nextRecurrence(occurrenceDate, reminder.recurrence, reminder.timezone, now);
        if (next) {
          await db.reminder.updateMany({ where: { id: reminder.id, dueAt: occurrenceDate }, data: { dueAt: next } });
          await queueReminder(reminder.id, next, JSON.parse(reminder.channels));
        }
        result = await deliver(reminder.title, "Your scheduled reminder is due.", channel, job.id);
      } else if (job.kind === "DAILY_CALL") {
        const resultCall = await startCall(job.id);
        result = `Call ${resultCall.status.toLowerCase()}; consult call history for its final outcome.`;
      } else throw new HttpError("Unknown scheduler job.");
      await db.scheduledJob.update({ where: { id: job.id }, data: { status: job.kind === "DAILY_CALL" ? "QUEUED" : "COMPLETED", result } });
    } catch (error) {
      await db.scheduledJob.update({ where: { id: job.id }, data: { status: "FAILED", error: error instanceof HttpError ? error.message : "Delivery failed. Check provider configuration and worker logs. No automatic retry was made." } });
    }
  }
}
