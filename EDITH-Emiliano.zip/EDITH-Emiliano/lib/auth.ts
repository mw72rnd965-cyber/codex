import { createHash, randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import { db } from "@/lib/db";
import { sign, validSessionSignature } from "@/lib/security/keys";
import { HttpError } from "@/lib/http";
export const sessionCookie = "edith_session";
export const hashToken = (value: string) => createHash("sha256").update(value).digest("hex");
export function passwordHash(password: string) {
  const salt = randomBytes(16).toString("hex");
  return `${salt}:${scryptSync(password, salt, 64).toString("hex")}`;
}
export function passwordMatches(password: string, stored: string) {
  const [salt, digest] = stored.split(":");
  const wanted = Buffer.from(digest, "hex");
  const actual = scryptSync(password, salt, 64);
  return actual.length === wanted.length && timingSafeEqual(actual, wanted);
}
export function requestToken(request: Request) {
  return request.headers.get("cookie")?.split(";").map(v => v.trim()).find(v => v.startsWith(sessionCookie + "="))?.slice(sessionCookie.length + 1);
}
export async function requireAuth(request: Request) {
  return requireSession(requestToken(request));
}
export async function requireSession(value: string | undefined) {
  if (!validSessionSignature(value)) throw new HttpError("Sign in to continue.", 401);
  const token = value!.split(".")[0];
  const session = await db.authSession.findUnique({ where: { tokenHash: hashToken(token) } });
  if (!session || session.expiresAt <= new Date()) throw new HttpError("Your session expired. Sign in again.", 401);
}
export async function newSession() {
  const id = randomBytes(32).toString("base64url"), expires = Date.now() + 7 * 86400000;
  await db.authSession.deleteMany({ where: { expiresAt: { lt: new Date() } } });
  await db.authSession.create({ data: { tokenHash: hashToken(id), expiresAt: new Date(expires) } });
  return `${id}.${expires}.${sign(`${id}.${expires}`)}`;
}
export const cookieOptions = () => ({ httpOnly: true, sameSite: "lax" as const, secure: process.env.EDITH_PUBLIC_URL?.startsWith("https:") ?? false, path: "/", maxAge: 7 * 86400 });
