export const VOICE_PREVIEW_TEXT =
  "I'm EDITH. Your personal intelligence system is online. Tell me what you need, and I'll take it from here.";
export const LOCAL_VOICES = [
  { id: "af_sarah", name: "EDITH · calm American female" },
  { id: "af_bella", name: "Bella · smooth American female" },
  { id: "af_heart", name: "Heart · warm American female" },
  { id: "bf_emma", name: "Emma · measured British female" },
];
export function speechText(text: string): string {
  return text
    .replace(/```[\s\S]*?```/g, " Code example omitted from speech. ")
    .replace(/!\[[^\]]*\]\([^)]*\)/g, "")
    .replace(/\[([^\]]+)\]\([^)]*\)/g, "$1")
    .replace(/(?:https?:\/\/|www\.)\S+/g, "")
    .replace(/[*_`#>|]+/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 4000);
}

// Emit complete phrases early; bound long unpunctuated spans without splitting words.
export function takeSpeechChunk(buffer: string, flush = false): [string, string] {
  const fence=buffer.indexOf("```");
  if(fence===0) {
    const end=buffer.indexOf("```",3);
    if(end<0) return flush ? ["Code example omitted from speech.",""] : ["",buffer];
    return ["Code example omitted from speech.",buffer.slice(end+3)];
  }
  const plain=fence<0 ? buffer : buffer.slice(0,fence);
  const boundary=plain.match(/[.!?](?=\s|$)|\n/);
  if(boundary?.index!==undefined) {
    const end=boundary.index+1;
    return [plain.slice(0,end),buffer.slice(end)];
  }
  if(plain.length>=100) {
    const end=plain.lastIndexOf(" ",100);
    if(end>20)return [plain.slice(0,end),buffer.slice(end)];
  }
  if(fence>0)return [plain,buffer.slice(fence)];
  return flush ? [buffer,""] : ["",buffer];
}
