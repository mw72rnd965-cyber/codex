import { createCipheriv, createDecipheriv, createHmac, randomBytes, timingSafeEqual } from "node:crypto";
import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { resolve } from "node:path";

export const privateRoot = () => resolve(process.env.EDITH_PRIVATE_ROOT ?? ".edith-runtime");
export function masterKey() {
  const root = privateRoot();
  mkdirSync(root, { recursive: true, mode: 0o700 });
  const path = resolve(root, "master.key");
  try { writeFileSync(path, randomBytes(32), { flag: "wx", mode: 0o600 }); } catch (error) {
    if ((error as NodeJS.ErrnoException).code !== "EEXIST") throw error;
  }
  const key = readFileSync(path);
  if (key.length !== 32) throw new Error("Invalid private encryption key. Restore your protected backup.");
  return key;
}
export function encrypt(value: unknown) {
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", masterKey(), iv);
  const bytes = Buffer.concat([cipher.update(JSON.stringify(value)), cipher.final()]);
  return Buffer.concat([iv, cipher.getAuthTag(), bytes]).toString("base64url");
}
export function decrypt<T>(value: string): T {
  const bytes = Buffer.from(value, "base64url");
  const decipher = createDecipheriv("aes-256-gcm", masterKey(), bytes.subarray(0, 12));
  decipher.setAuthTag(bytes.subarray(12, 28));
  return JSON.parse(Buffer.concat([decipher.update(bytes.subarray(28)), decipher.final()]).toString());
}
export function sign(value: string) { return createHmac("sha256", masterKey()).update(value).digest("base64url"); }
export function equal(a: string, b: string) {
  const left = Buffer.from(a), right = Buffer.from(b);
  return left.length === right.length && timingSafeEqual(left, right);
}
export function validSessionSignature(value: string | undefined) {
  if (!value) return false;
  const [id, expires, signature, extra] = value.split(".");
  return !extra && /^[\w-]{43}$/.test(id ?? "") && Number(expires) > Date.now() && equal(sign(`${id}.${expires}`), signature ?? "");
}
