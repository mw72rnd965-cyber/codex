import { db } from "@/lib/db";
export async function externalContextAllowed() { const setting = await db.systemSetting.findUnique({ where: { key: "privacy.externalContext" } }); return setting ? setting.value === "true" : process.env.ALLOW_EXTERNAL_CONTEXT === "true"; }
