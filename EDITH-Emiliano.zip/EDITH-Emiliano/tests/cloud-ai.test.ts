import test from "node:test";
import assert from "node:assert/strict";
import { groqConfiguration, GROQ_BASE_URL, GROQ_DEFAULT_MODEL } from "../lib/ai/presets";
import { getProvider, OpenAICompatibleProvider, providerConfigured } from "../lib/ai/provider";
import { HttpError } from "../lib/http";

const context = { memories: [], knowledge: [], tasks: [], sources: [] };
const messages = [{ role: "user" as const, content: "Hello" }];

test("Groq cloud connector handles configuration, streaming, and provider failures", async suite => {
 const previous = Object.fromEntries(["AI_PROVIDER", "AI_API_KEY", "GROQ_API_KEY", "GROQ_MODEL"].map(name => [name, process.env[name]]));
 const originalFetch = globalThis.fetch;
 try {
  process.env.AI_PROVIDER = "groq";
  process.env.AI_API_KEY = "other-provider-private-key";
  delete process.env.GROQ_API_KEY;
  delete process.env.GROQ_MODEL;
  await suite.test("missing Groq key cannot fall back to another provider key or claim a live model", async () => {
   const config = groqConfiguration();
   assert.equal(config.baseUrl, GROQ_BASE_URL);
   assert.equal(config.model, GROQ_DEFAULT_MODEL);
   assert.equal(config.apiKey, undefined);
   assert.equal(providerConfigured(config), false);
   assert.equal(providerConfigured(), false);
   assert.throws(() => getProvider(), error => error instanceof HttpError && error.message.includes("GROQ_API_KEY"));
   globalThis.fetch = async () => { throw new Error("A missing key must not send a request"); };
   await assert.rejects(new OpenAICompatibleProvider(config).generate(messages, context), error => error instanceof HttpError && error.status === 503);
  });
  process.env.GROQ_API_KEY = "private-groq-test-key";
  await suite.test("Groq sends the chosen model and key only to its HTTPS completion endpoint", async () => {
   globalThis.fetch = async (url, options) => {
    assert.equal(String(url), GROQ_BASE_URL + "/chat/completions");
    assert.equal(new Headers(options?.headers).get("authorization"), "Bearer private-groq-test-key");
    const payload = JSON.parse(String(options?.body));
    assert.equal(payload.model, GROQ_DEFAULT_MODEL);
    assert.equal(payload.max_completion_tokens, 2048);
    assert.equal(payload.stream, false);
    return Response.json({ choices: [{ message: { content: "Hello, Emiliano." } }] });
   };
   assert.equal(await getProvider().generate(messages, context), "Hello, Emiliano.");
  });
  await suite.test("streaming exposes answer tokens and omits separate reasoning fields", async () => {
   globalThis.fetch = async () => new Response('data: {"choices":[{"delta":{"reasoning":"private internal analysis"}}]}\n\ndata: {"choices":[{"delta":{"content":"Hello, Emiliano."}}]}\n\ndata: [DONE]\n\n');
   let answer = "";
   for await (const token of getProvider().stream(messages, context)) answer += token;
   assert.equal(answer, "Hello, Emiliano.");
  });
  await suite.test("HTTP errors report limits or setup issues without reflecting provider bodies", async () => {
   for (const [status, expectedStatus, message] of [[429, 429, /usage limit/], [401, 503, /API key/], [403, 503, /permissions/], [404, 503, /model or endpoint/], [500, 503, /unavailable/]] as const) {
    globalThis.fetch = async () => new Response("private-groq-test-key raw response", { status });
    await assert.rejects(getProvider().generate(messages, context), error => error instanceof HttpError && error.status === expectedStatus && message.test(error.message) && !error.message.includes("private-groq-test-key"));
   }
  });
  await suite.test("an insecure cloud endpoint is rejected before sending a key", async () => {
   globalThis.fetch = async () => { throw new Error("An insecure URL must not send a request"); };
   const provider = new OpenAICompatibleProvider({ ...groqConfiguration(), baseUrl: "http://model.example/v1" });
   await assert.rejects(provider.generate(messages, context), error => error instanceof HttpError && error.message.includes("HTTPS"));
  });
 } finally {
  globalThis.fetch = originalFetch;
  for (const [name, value] of Object.entries(previous)) { if (value === undefined) delete process.env[name]; else process.env[name] = value; }
 }
});
