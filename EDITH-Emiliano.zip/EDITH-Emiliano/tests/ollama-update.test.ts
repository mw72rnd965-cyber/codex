import test from "node:test";
import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { chmodSync, mkdirSync, mkdtempSync, readFileSync, rmSync, statSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { DatabaseSync } from "node:sqlite";
import dotenv from "dotenv";

test("updating an existing installation selects Ollama and preserves data, keys and password", async () => {
 const folder = mkdtempSync(join(tmpdir(), "edith-update-"));
 const target = join(folder, "Existing EDITH");
 const environment = { ...process.env };
 delete environment.DATABASE_URL;
 try {
  mkdirSync(join(target, "prisma"), { recursive: true });
  mkdirSync(join(target, ".edith-runtime"), { recursive: true });
  writeFileSync(join(target, "package.json"), JSON.stringify({ name: "edith", private: true }));
  const original = 'DATABASE_URL="file:./prisma/edith.db"\nAI_PROVIDER="groq"\nAI_PROVIDER="mock"\nLOCAL_AI_MODEL="qwen2.5:3b"\nELEVENLABS_API_KEY="private-voice-test-key"\nELEVENLABS_VOICE_ID="existing-voice"\nGROQ_API_KEY="private-cloud-test-key"\nALLOW_EXTERNAL_CONTEXT="false"\n';
  writeFileSync(join(target, ".env"), original);
  chmodSync(join(target, ".env"), 0o600);
  writeFileSync(join(target, ".edith-runtime", "master.key"), "existing-private-master-key");
  writeFileSync(join(target, ".edith-runtime", "original.txt"), "Original private document");
  writeFileSync(join(target, "LOCAL-NOTES.md"), "Keep my own notes");
  execFileSync(process.execPath, [resolve("scripts/init-db.mjs")], { cwd: target, env: environment, stdio: "ignore" });
  let database = new DatabaseSync(join(target, "prisma", "edith.db"));
  database.prepare('INSERT INTO "Task" ("id", "title", "updatedAt") VALUES (?, ?, ?)').run("existing-task", "Keep this task", new Date().toISOString());
  for (const [key, value] of [["ai.mode", "groq"], ["auth.password", "existing-private-password-hash"]]) database.prepare('INSERT INTO "SystemSetting" ("key", "value", "updatedAt") VALUES (?, ?, ?)').run(key, value, new Date().toISOString());
  database.close();
  execFileSync(process.execPath, [resolve("scripts/update-existing.mjs"), target], { env: environment, stdio: "ignore" });
  assert.equal(readFileSync(join(target, ".env"), "utf8"), original);
  assert.equal(readFileSync(join(target, "LOCAL-NOTES.md"), "utf8"), "Keep my own notes");
  for (let attempt = 0; attempt < 2; attempt++) {
   const output = execFileSync(process.execPath, [resolve("scripts/use-ollama.mjs")], { cwd: target, env: environment, encoding: "utf8", stdio: ["ignore", "pipe", "ignore"] });
   assert.ok(!output.includes("private-voice-test-key") && !output.includes("private-cloud-test-key"));
  }
  const updated = readFileSync(join(target, ".env"), "utf8"), config = dotenv.parse(updated);
  assert.equal((updated.match(/^AI_PROVIDER=/gm) ?? []).length, 1);
  assert.equal(config.AI_PROVIDER, "local");
  assert.equal(config.LOCAL_AI_BASE_URL, "http://127.0.0.1:11434/v1");
  assert.equal(config.LOCAL_AI_TRANSPORT, "ollama");
  assert.equal(config.ELEVENLABS_API_KEY, "private-voice-test-key");
  assert.equal(config.ELEVENLABS_VOICE_ID, "existing-voice");
  assert.equal(config.GROQ_API_KEY, "private-cloud-test-key");
  assert.equal(statSync(join(target, ".env")).mode & 0o777, 0o600);
  assert.equal(readFileSync(join(target, ".edith-runtime", "master.key"), "utf8"), "existing-private-master-key");
  assert.equal(readFileSync(join(target, ".edith-runtime", "original.txt"), "utf8"), "Original private document");
  database = new DatabaseSync(join(target, "prisma", "edith.db"));
  assert.equal(database.prepare('SELECT "title" FROM "Task" WHERE "id"=?').get("existing-task")?.title, "Keep this task");
  assert.equal(database.prepare('SELECT "value" FROM "SystemSetting" WHERE "key"=?').get("ai.mode")?.value, "local");
  assert.equal(database.prepare('SELECT "value" FROM "SystemSetting" WHERE "key"=?').get("auth.password")?.value, "existing-private-password-hash");
  database.close();
  const previousDatabase = process.env.DATABASE_URL;
  process.env.DATABASE_URL = "file:" + join(target, "prisma", "edith.db");
  const { db } = await import("../lib/db");
  try {
   const mode = await db.systemSetting.findUniqueOrThrow({ where: { key: "ai.mode" } });
   assert.equal(mode.value, "local");
   assert.ok(mode.updatedAt instanceof Date);
  } finally {
   await db.$disconnect();
   if (previousDatabase === undefined) delete process.env.DATABASE_URL; else process.env.DATABASE_URL = previousDatabase;
  }
 } finally {
  rmSync(folder, { recursive: true, force: true });
 }
});
