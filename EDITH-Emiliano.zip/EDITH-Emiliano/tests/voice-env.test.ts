import test from "node:test";
import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { chmodSync, mkdirSync, mkdtempSync, readFileSync, rmSync, statSync, symlinkSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";

const helper = resolve("scripts/ensure-voice-env.mjs");
test("voice field setup preserves private configuration and only adds missing placeholders", async t => {
 const folder = mkdtempSync(join(tmpdir(), "edith-voice-env-"));
 const target = join(folder, "Existing EDITH");
 try {
  mkdirSync(target);
  writeFileSync(join(target, "package.json"), JSON.stringify({ name: "edith" }));
  writeFileSync(join(target, ".env.example"), 'AI_PROVIDER="local"\nELEVENLABS_API_KEY=""\nELEVENLABS_VOICE_ID=""\n');
  await t.test("a code update adds absent fields without changing original settings or selecting another model", () => {
   const original = '# Private configuration\r\nAI_PROVIDER="local"\r\nLOCAL_AI_MODEL="my-existing-model"\r\nGROQ_API_KEY="test-only-private-canary"';
   writeFileSync(join(target, ".env"), original);
   const output = execFileSync(process.execPath, [resolve("scripts/update-existing.mjs"), target], { encoding: "utf8" });
   const updated = readFileSync(join(target, ".env"), "utf8");
   assert.ok(updated.startsWith(original + "\r\n"));
   assert.equal((updated.match(/^ELEVENLABS_API_KEY=""\r?$/gm) ?? []).length, 1);
   assert.equal((updated.match(/^ELEVENLABS_VOICE_ID=""\r?$/gm) ?? []).length, 1);
   assert.equal(statSync(join(target, ".env")).mode & 0o777, 0o600);
   assert.ok(!output.includes("test-only-private-canary"));
   execFileSync(process.execPath, [helper, target]);
   assert.equal(readFileSync(join(target, ".env"), "utf8"), updated);
  });
  await t.test("existing keys and voice IDs including export and colon syntax remain byte-for-byte intact", () => {
   const original = 'export ELEVENLABS_API_KEY = "test-only-private-voice-key"\nELEVENLABS_VOICE_ID: "already-selected-voice"\nAI_PROVIDER="local"\n';
   writeFileSync(join(target, ".env"), original);chmodSync(join(target, ".env"), 0o600);
   const output = execFileSync(process.execPath, [helper, target], { encoding: "utf8" });
   assert.equal(readFileSync(join(target, ".env"), "utf8"), original);
   assert.ok(!output.includes("test-only-private-voice-key") && !output.includes("already-selected-voice"));
   writeFileSync(join(target, ".env"), 'ELEVENLABS_API_KEY="test-only-private-voice-key"\n# ELEVENLABS_VOICE_ID="commented-out"\n');
   execFileSync(process.execPath, [helper, target]);
   const partial = readFileSync(join(target, ".env"), "utf8");
   assert.ok(partial.startsWith('ELEVENLABS_API_KEY="test-only-private-voice-key"\n'));
   assert.equal((partial.match(/^ELEVENLABS_API_KEY=/gm) ?? []).length, 1);
   assert.equal((partial.match(/^ELEVENLABS_VOICE_ID=""$/gm) ?? []).length, 1);
  });
  await t.test("first setup creates private configuration from the template", () => {
   rmSync(join(target, ".env"));
   execFileSync(process.execPath, [helper], { cwd: target });
   assert.equal(readFileSync(join(target, ".env"), "utf8"), readFileSync(join(target, ".env.example"), "utf8"));
   assert.equal(statSync(join(target, ".env")).mode & 0o777, 0o600);
  });
  await t.test("linked or dangling environment paths cannot modify another file", () => {
   rmSync(join(target, ".env"));
   const privateFile = join(folder, "other-private-env");
   writeFileSync(privateFile, "OTHER_PRIVATE_VALUE=keep-this-file\n");
   for (const destination of [privateFile, join(folder, "absent-file")]) {
    symlinkSync(destination, join(target, ".env"));
    assert.throws(() => execFileSync(process.execPath, [helper, target], { stdio: "ignore" }));
    rmSync(join(target, ".env"));
   }
   assert.equal(readFileSync(privateFile, "utf8"), "OTHER_PRIVATE_VALUE=keep-this-file\n");
  });
 } finally {
  rmSync(folder, { recursive: true, force: true });
 }
});
