import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,mkdirSync,writeFileSync,symlinkSync,rmSync} from 'node:fs';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {execFileSync} from 'node:child_process';
import {createRequire} from 'node:module';

test('linked folders refresh changed files, exclude symlinks, and grounded analysis proposes tasks without saving them',async()=>{
 const directory=mkdtempSync(join(tmpdir(),'edith-ability-test-'));
 process.env.DATABASE_URL='file:'+join(directory,'test.db');
 execFileSync(process.execPath,['scripts/init-db.mjs'],{env:process.env,stdio:'ignore'});
 const {db}=await import('../lib/db');
 const {scanFolder}=await import('../lib/abilities/folder');
 const {importFile}=await import('../lib/abilities/documents');
 const {analyzeFiles}=await import('../lib/abilities/analysis');
 const {createTimer,tickTimers}=await import('../lib/abilities/timers');
 const {chatAbility}=await import('../lib/abilities/chat');
 const folder=join(directory,'documents');mkdirSync(folder);
 writeFileSync(join(folder,'budget.txt'),'Budget is 120 euros.');
 writeFileSync(join(directory,'outside.txt'),'Private outside content.');
 symlinkSync(join(directory,'outside.txt'),join(folder,'symlink.txt'));
 writeFileSync(join(folder,'.hidden.txt'),'Hidden content.');
 const originalFetch=globalThis.fetch;
 try{
  await db.systemSetting.create({data:{key:'documents.folder',value:JSON.stringify({path:folder})}});
  await scanFolder();
  const files=await db.knowledgeFile.findMany();
  assert.equal(files.length,1);assert.equal(files[0].content,'Budget is 120 euros.');
  writeFileSync(join(folder,'budget.txt'),'Budget is now 250 euros, revised today.');
  await scanFolder();
  assert.equal(await db.knowledgeFile.count(),1);
  assert.match((await db.knowledgeFile.findUniqueOrThrow({where:{id:files[0].id}})).content,/250 euros/);
  const pdfText='BT /F1 16 Tf 50 750 Td (Quarterly budget review.) Tj ET';
  const objects=[
   '<< /Type /Catalog /Pages 2 0 R >>',
   '<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
   '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>',
   '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>',
   `<< /Length ${pdfText.length} >>\nstream\n${pdfText}\nendstream`,
  ];
  let pdf='%PDF-1.4\n';const offsets=[0];
  for(let i=0;i<objects.length;i++){offsets.push(Buffer.byteLength(pdf));pdf+=`${i+1} 0 obj\n${objects[i]}\nendobj\n`;}
  const xref=Buffer.byteLength(pdf);
  pdf+=`xref\n0 ${objects.length+1}\n0000000000 65535 f \n`+offsets.slice(1).map(n=>`${String(n).padStart(10,'0')} 00000 n \n`).join('')+`trailer\n<< /Size ${objects.length+1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF\n`;
  const parsedPdf=await importFile(new File([new Uint8Array(Buffer.from(pdf))],'review.pdf'));
  assert.match((await db.knowledgeFile.findUniqueOrThrow({where:{id:parsedPdf.id}})).content,/Quarterly budget review/);
  const require=createRequire(import.meta.url);
  const Zip=require('jszip');const zip=new Zip();
  zip.file('[Content_Types].xml','<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>');
  zip.file('_rels/.rels','<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>');
  zip.file('word/document.xml','<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:p><w:r><w:t>Prepare the launch slides.</w:t></w:r></w:p></w:body></w:document>');
  const word=await importFile(new File([new Uint8Array(await zip.generateAsync({type:'nodebuffer'}))],'slides.docx'));
  assert.match((await db.knowledgeFile.findUniqueOrThrow({where:{id:word.id}})).content,/launch slides/);
  const {default:sharp}=await import('sharp');
  const image=await sharp({create:{width:12,height:12,channels:3,background:'red'}}).png().toBuffer();
  const photo=await importFile(new File([new Uint8Array(image)],'red.png'));
  await db.systemSetting.create({data:{key:'ai.mode',value:'local'}});
  process.env.LOCAL_AI_TRANSPORT='ollama';
  globalThis.fetch=async(input,init)=>{
   const body=JSON.parse(String(init?.body));
   if(String(input).endsWith('/api/generate')){
    assert.equal(body.model,'moondream');assert.equal(body.images.length,1);
    return Response.json({response:'A red square.'});
   }
   assert.match(body.messages.at(-1).content,/Budget is now 250/);
   assert.match(body.messages.at(-1).content,/A red square/);
   const content=JSON.stringify({summary:'Review the revised 250 euro budget.',tasks:[{title:'Review budget',description:'Budget reference: 250 euros.'}]});
   return new Response(JSON.stringify({message:{content}})+'\n');
  };
  const analysis=await analyzeFiles({fileIds:[files[0].id,photo.id],instruction:'Review the budget and image; create next steps',createTasks:true});
  assert.equal(analysis.proposals.length,1);assert.equal(await db.task.count(),0);assert.equal(await db.note.count(),1);
  assert.equal(analysis.proposals[0].title,'Review budget');
  assert.equal((await db.knowledgeFile.findUniqueOrThrow({where:{id:photo.id}})).content,'A red square.');
  globalThis.fetch=async()=>new Response('{"message":{"content":"not valid JSON"}}\n');
  await assert.rejects(()=>analyzeFiles({fileIds:[files[0].id],instruction:'Create tasks',createTasks:true}));
  assert.equal(await db.task.count(),0);assert.equal(await db.note.count(),1);
  const timer=await createTimer({label:'Test',seconds:1});
  await db.timer.update({where:{id:timer.id},data:{dueAt:new Date(Date.now()-1000)}});
  await Promise.all([tickTimers(),tickTimers()]);
  assert.equal((await db.timer.findUniqueOrThrow({where:{id:timer.id}})).status,'RINGING');
  await assert.rejects(()=>createTimer({seconds:5,notifyPhone:true}),/Configure/);
  assert.match(await chatAbility('set a timer for 60 seconds called chat test')??'',/Timer set/);
  assert.match(await chatAbility('list my timers')??'',/chat test/);
  assert.equal(await chatAbility('cancel the chat test timer'),'chat test timer cancelled.');
  assert.equal(await chatAbility('my phone number is +15550000002'),'Phone number saved. Calls are disabled until you configure a calling provider and enable notifications.');
  assert.match(await chatAbility('enable phone notifications')??'',/not configured/);
  assert.match(await chatAbility('list my files')??'',/budget.txt/);
  assert.equal(await chatAbility('What is the capital of Finland?'),null);
  assert.equal(await chatAbility('can you add a task to review the budget?'),'Task created: review the budget.');
  globalThis.fetch=async(_input,init)=>{
   const body=JSON.parse(String(init?.body));
   const json=body.messages.at(-1).content.includes('Return only JSON');
   const content=json?JSON.stringify({summary:'Budget reviewed.',tasks:[{title:'Check revised budget',description:'Review 250 euros.'}]}):'The revised budget is 250 euros.';
   return new Response(JSON.stringify({message:{content}})+'\n');
  };
  assert.match(await chatAbility('summarize budget.txt')??'',/250 euros/);
  assert.match(await chatAbility('create tasks from budget.txt')??'',/Proposed 1 tasks/);


  await assert.rejects(()=>createTimer({seconds:5,notifyPhone:true}),/Configure|configur|Calling needs/);

 } finally {globalThis.fetch=originalFetch;await db.$disconnect();rmSync(directory,{recursive:true,force:true});}
});
