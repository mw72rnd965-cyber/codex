import test from "node:test";
import assert from "node:assert/strict";
import { clockReply, currentClock } from "../lib/abilities/clock";
import { duckDuckGoSources, searchWeb, webQuery, webReply } from "../lib/abilities/web";

test("time, date, city time and DST use the actual clock in the selected timezone", () => {
 const now = new Date("2026-10-10T12:34:56Z");
 assert.equal(currentClock("Europe/Helsinki", now).time, "15:34:56");
 for (const prompt of ["What time is it?", "Can you tell me what time it is?", "What's the current time?", "What is the time of the day?", "Is it morning or afternoon right now?"]) {
  const reply = clockReply(prompt, "Europe/Helsinki", now);
  assert.ok(reply?.content.includes("15:34:56"), prompt);
  assert.ok(reply?.content.includes("computer clock"));
 }
 assert.match(clockReply("What day is it today?", "Europe/Helsinki", now)?.content ?? "", /Saturday, 10 October 2026/);
 assert.match(clockReply("What time is it in New York?", "Europe/Helsinki", now)?.content ?? "", /08:34:56.*America\/New_York/);
 assert.match(clockReply("What time is it in UTC?", "Europe/Helsinki", now)?.content ?? "", /12:34:56.*UTC/);
 assert.match(clockReply("What time is it in an unknown place?", "Europe/Helsinki", now)?.content ?? "", /Which timezone/);
 assert.equal(currentClock("Europe/Helsinki", new Date("2026-03-29T00:30:00Z")).time, "02:30:00");
 assert.equal(currentClock("Europe/Helsinki", new Date("2026-03-29T01:30:00Z")).time, "04:30:00");
 assert.equal(clockReply("Remind me to review my task tomorrow at 17:00", "Europe/Helsinki", now), null);
 assert.equal(clockReply("How does time dilation work?", "Europe/Helsinki", now), null);
});
const html = '<a class="result__a" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Fwww.nasa.gov%2Fmissions%2F&amp;rut=abc">NASA &amp; missions</a><a class="result__snippet">Read the <b>actual mission</b> report.</a>';
test("web searches use retrieved excerpts and preserve real links, failure status and key privacy", async suite => {
 const originalFetch = globalThis.fetch;
 const previous = Object.fromEntries(["WEB_SEARCH_ENABLED", "WEB_SEARCH_PROVIDER", "TAVILY_API_KEY"].map(name => [name, process.env[name]]));
 try {
  process.env.WEB_SEARCH_ENABLED = "true"; process.env.WEB_SEARCH_PROVIDER = "duckduckgo";
  await suite.test("explicit and current searches exclude ordinary workspace commands", () => {
   assert.equal(webQuery("Search the web for Helsinki weather"), "Helsinki weather");
   assert.equal(webQuery("What is the latest NASA news?"), "What is the latest NASA news");
   assert.equal(webQuery("Show my tasks today"), null);
   assert.equal(webQuery("Review my documents with the latest notes"), null);
   assert.equal(webQuery("Explain how rainbows form in one sentence"), null);
  });
  await suite.test("search HTML supplies titles, snippets and decoded source URLs", async () => {
   globalThis.fetch = async (url, options) => {
    assert.equal(new URL(String(url)).origin, "https://html.duckduckgo.com");
    assert.equal(new URL(String(url)).searchParams.get("q"), "NASA & missions");
    assert.equal(new Headers(options?.headers).has("authorization"), false);
    return new Response(html);
   };
   const result = await searchWeb("NASA & missions");
   assert.equal(result.status, "ok");
   assert.deepEqual(result.sources, [{ title: "NASA & missions", url: "https://www.nasa.gov/missions/", excerpt: "Read the actual mission report." }]);
   const reply = webReply(result); assert.match(reply, /https:\/\/www.nasa.gov\/missions\//); assert.match(reply, /search excerpts/);
  });
  await suite.test("unsafe links and duplicates never become clickable sources", () => {
   const malicious = '<a class="result__a" href="javascript:alert(1)">Bad</a><a class="result__a" href="http://127.0.0.1/admin">Private</a>';
   assert.deepEqual(duckDuckGoSources(malicious + html + html), duckDuckGoSources(html));
  });
  await suite.test("general queries can fall back to actual Wikipedia extracts", async () => {
   globalThis.fetch = async url => String(url).startsWith("https://html.duckduckgo.com/") ? new Response("captcha", { status: 403 }) : Response.json({ query: { pages: [{ title: "Helsinki", fullurl: "https://en.wikipedia.org/wiki/Helsinki", extract: "Helsinki is the capital of Finland." }] } });
   const result = await searchWeb("Helsinki history");
   assert.equal(result.provider, "Wikipedia"); assert.equal(result.status, "ok"); assert.equal(result.sources[0].excerpt, "Helsinki is the capital of Finland.");
  });
  await suite.test("a failed current search never substitutes an encyclopedia or invented live facts", async () => {
   let requests = 0; globalThis.fetch = async () => { requests++; return new Response("captcha", { status: 403 }); };
   const result = await searchWeb("latest NASA news");
   assert.equal(requests, 1); assert.equal(result.status, "unavailable"); assert.deepEqual(result.sources, []); assert.match(webReply(result), /cannot verify current facts/);
  });
  await suite.test("disabled or invalid search sends no request", async () => {
   globalThis.fetch = async () => { throw new Error("No request expected"); };
   process.env.WEB_SEARCH_ENABLED = "false"; assert.equal((await searchWeb("NASA news")).status, "disabled");
   process.env.WEB_SEARCH_ENABLED = "true"; process.env.WEB_SEARCH_PROVIDER = "invalid";
   assert.match((await searchWeb("NASA news")).message ?? "", /WEB_SEARCH_PROVIDER/);
  });
  await suite.test("default Tavily keyless search uses documented headers without an API key", async () => {
   delete process.env.WEB_SEARCH_PROVIDER; delete process.env.TAVILY_API_KEY;
   globalThis.fetch = async (url, options) => {
    assert.equal(String(url), "https://api.tavily.com/search");
    const headers = new Headers(options?.headers); assert.equal(headers.has("authorization"), false); assert.equal(headers.get("X-Tavily-Access-Mode"), "keyless"); assert.equal(headers.get("X-Client-Source"), "edith-keyless");
    return Response.json({ results: [{ title: "NASA report", url: "https://www.nasa.gov/missions/", content: "Actual retrieved excerpt." }] });
   };
   assert.equal((await searchWeb("NASA news")).status, "ok");
   globalThis.fetch = async () => new Response("private raw error", { status: 429 });
   const result = await searchWeb("NASA news"); assert.equal(result.status, "unavailable"); assert.deepEqual(result.sources, []); assert.match(result.message ?? "", /usage limit/); assert.ok(!JSON.stringify(result).includes("private raw error"));
  });
  await suite.test("optional Tavily uses only its own server key and retrieved URLs", async () => {
   process.env.WEB_SEARCH_PROVIDER = "tavily";
   process.env.TAVILY_API_KEY = "private-tavily-test-key";
   globalThis.fetch = async (url, options) => {
    assert.equal(String(url), "https://api.tavily.com/search"); assert.equal(new Headers(options?.headers).get("authorization"), "Bearer private-tavily-test-key");
    assert.deepEqual(JSON.parse(String(options?.body)), { query: "NASA news", max_results: 3, search_depth: "basic", include_answer: false, include_raw_content: false });
    return Response.json({ results: [{ title: "Mission report", url: "https://www.nasa.gov/missions/", content: "Retrieved source text." }] });
   };
   const result = await searchWeb("NASA news"); assert.equal(result.status, "ok"); assert.ok(!JSON.stringify(result).includes("private-tavily-test-key"));
  });
 } finally {
  globalThis.fetch = originalFetch;
  for (const [name, value] of Object.entries(previous)) { if (value === undefined) delete process.env[name]; else process.env[name] = value; }
 }
});
