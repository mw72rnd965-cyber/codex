import test from "node:test";
import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { mkdtempSync, rmSync, statSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createHmac } from "node:crypto";

test("personal assistant security, organization, integrations, and durable delivery", async suite => {
 const root = mkdtempSync(join(tmpdir(), "edith-personal-"));
 process.env.DATABASE_URL = "file:" + join(root, "test.db"); process.env.EDITH_PRIVATE_ROOT = join(root, "private");
 execFileSync(process.execPath, ["scripts/init-db.mjs"], { env: process.env, stdio: "ignore" });
 const { db } = await import("../lib/db"), { initialize } = await import("../lib/service"); await initialize();
 const auth = await import("../lib/auth"), keys = await import("../lib/security/keys"), time = await import("../lib/time"), organization = await import("../lib/organization");
 const { schedulerTick } = await import("../lib/scheduler"), { POST: action, GET: state } = await import("../app/api/workspace/route"), { POST: hook } = await import("../app/api/hooks/phone/route");
 const session = await auth.newSession();
 const request = (body: unknown) => new Request("http://localhost:3000/api/workspace", { method: "POST", headers: { cookie: "edith_session=" + session, "Content-Type": "application/json" }, body: JSON.stringify(body) });
 const originalFetch = globalThis.fetch;
 const originalEnvironment = new Map<string, string | undefined>();
 const set = (name: string, value: string) => { if (!originalEnvironment.has(name)) originalEnvironment.set(name, process.env[name]); process.env[name] = value; };
 try {
  await suite.test("passwords, sessions, and encrypted calendar tokens do not expose credentials", async () => {
   const hash = auth.passwordHash("a-test-only-password-with-length"); assert.notEqual(hash, "a-test-only-password-with-length"); assert.ok(auth.passwordMatches("a-test-only-password-with-length", hash)); assert.ok(!auth.passwordMatches("incorrect-password", hash));
   assert.ok(keys.validSessionSignature(session)); assert.ok(!keys.validSessionSignature(session.slice(0, -1) + "!"));
   const encrypted = keys.encrypt({ refresh_token: "private-test-refresh-token" }); assert.ok(!encrypted.includes("private-test-refresh-token")); assert.deepEqual(keys.decrypt(encrypted), { refresh_token: "private-test-refresh-token" });
   assert.equal(statSync(join(root, "private", "master.key")).mode & 0o777, 0o600);
   assert.equal((await action(new Request("http://localhost/api/workspace", { method: "POST", body: "{}" }))).status, 401);
   assert.equal((await action(new Request("http://localhost/api/workspace", { method: "POST", headers: { cookie: "edith_session=" + session, origin: "https://untrusted.example", host: "localhost", "Content-Type": "application/json" }, body: JSON.stringify({ action: "task-save", title: "Rejected" }) }))).status, 403);
  });
  await suite.test("Groq selection stores no credential and reports the actual missing key", async () => {
   const previousMode = await db.systemSetting.findUnique({ where: { key: "ai.mode" } });
   set("GROQ_API_KEY", "");
   try {
    assert.equal((await action(request({ action: "ai-mode", mode: "groq" }))).status, 200);
    assert.equal((await db.systemSetting.findUniqueOrThrow({ where: { key: "ai.mode" } })).value, "groq");
    const info = await (await state(new Request("http://localhost:3000/api/workspace", { headers: { cookie: "edith_session=" + session } }))).json();
    assert.equal(info.integrations.ai.demo, false);
    assert.equal(info.integrations.ai.name, "Groq cloud AI");
    assert.deepEqual(info.integrations.ai.missing, ["GROQ_API_KEY"]);
    assert.equal((await action(request({ action: "ai-test" }))).status, 503);
    assert.equal((await action(request({ action: "ai-mode", mode: "unknown" }))).status, 400);
   } finally {
    if (previousMode) await db.systemSetting.update({ where: { key: "ai.mode" }, data: { value: previousMode.value } });
    else await db.systemSetting.deleteMany({ where: { key: "ai.mode" } });
   }
  });
  await suite.test("Ollama selection uses a mocked local response without a cloud key", async () => {
   const previousMode = await db.systemSetting.findUnique({ where: { key: "ai.mode" } });
   set("LOCAL_AI_MODEL", "qwen2.5:3b"); set("LOCAL_AI_TRANSPORT", "ollama"); set("LOCAL_AI_BASE_URL", "http://127.0.0.1:11434/v1");
   try {
    globalThis.fetch = async (url, options) => {
     if (String(url).endsWith("/models")) return Response.json({ data: [{ id: "qwen2.5:3b" }] });
     assert.equal(String(url), "http://127.0.0.1:11434/api/chat");
     assert.equal(new Headers(options?.headers).has("authorization"), false);
     assert.equal(JSON.parse(String(options?.body)).model, "qwen2.5:3b");
     return Response.json({ message: { content: "online" } });
    };
    assert.equal((await action(request({ action: "ai-mode", mode: "local" }))).status, 200);
    assert.equal((await action(request({ action: "ai-test" }))).status, 200);
    const info = await (await state(new Request("http://localhost:3000/api/workspace", { headers: { cookie: "edith_session=" + session } }))).json();
    assert.equal(info.integrations.ai.name, "Ollama on your Mac");
    assert.deepEqual(info.integrations.ai.missing, []);
    globalThis.fetch = async () => { throw new Error("Offline test service"); };
    assert.equal((await action(request({ action: "ai-test" }))).status, 503);
   } finally {
    globalThis.fetch = originalFetch;
    if (previousMode) await db.systemSetting.update({ where: { key: "ai.mode" }, data: { value: previousMode.value } });
    else await db.systemSetting.deleteMany({ where: { key: "ai.mode" } });
   }
  });
  await suite.test("Helsinki wall-clock recurrence survives DST and rejects ambiguous deadlines", () => {
   assert.throws(() => time.localDateTime("2026-03-29T03:30", "Europe/Helsinki")); assert.throws(() => time.localDateTime("2026-10-25T03:30", "Europe/Helsinki"));
   const next = time.nextRecurrence(new Date("2026-03-28T06:30:00Z"), "daily", "Europe/Helsinki", new Date("2026-03-28T07:00:00Z")); assert.equal(next?.toISOString(), "2026-03-29T05:30:00.000Z");
   assert.equal(time.nextCallTime("08:30", "Europe/Helsinki", [7], new Date("2026-03-28T12:00:00Z")).toISOString(), "2026-03-29T05:30:00.000Z");
   assert.equal(time.quietUntil(new Date("2026-03-28T21:00:00Z"), "Europe/Helsinki", "22:00", "08:00")?.toISOString(), "2026-03-29T05:00:00.000Z");
   assert.ok(organization.parseNaturalTask("E.D.I.T.H., remind me to finish my presentation tomorrow at five", "Europe/Helsinki", new Date("2026-10-10T10:00:00Z"))?.question);
   const parsed = organization.parseNaturalTask("remind me to finish my presentation tomorrow at 17:00", "Europe/Helsinki", new Date("2026-10-10T10:00:00Z")); assert.equal(parsed?.task?.dueDate, "2026-10-11T14:00:00.000Z");
   const linked = organization.parseNaturalTask("remind me to finish slides for the Aster project tomorrow at 17:00", "Europe/Helsinki", new Date("2026-10-10T10:00:00Z"), [{ id: "aster", title: "Aster" }]); assert.equal(linked?.task?.projectId, "aster"); assert.equal(linked?.task?.title, "finish slides");
  });
  await suite.test("recurring tasks keep reminders and task completion cancels the old occurrence", async () => {
   const task = await organization.saveTask({ title: "Daily review", dueDate: "2027-01-02T09:00:00Z", recurrence: "daily", reminderMinutes: 15, estimatedMinutes: 20 });
   const oldReminder = await db.reminder.findFirstOrThrow({ where: { taskId: task.id } });
   await organization.saveTask({ ...task, dueDate: task.dueDate?.toISOString(), startDate: null, status: "COMPLETED" }, task.id);
   const next = await db.task.findFirstOrThrow({ where: { title: "Daily review", status: "PENDING" } }); assert.equal(next.dueDate?.toISOString(), "2027-01-03T09:00:00.000Z");
   assert.ok(await db.reminder.findFirst({ where: { taskId: next.id, active: true } }));
   assert.equal((await db.scheduledJob.findFirstOrThrow({ where: { dedupeKey: { startsWith: "reminder:" + oldReminder.id } } })).status, "CANCELLED");
   const child = await organization.saveTask({ title: "Subtask", parentId: next.id }); await assert.rejects(() => organization.saveTask({ ...next, dueDate: next.dueDate?.toISOString(), parentId: child.id }, next.id), /cycle/);
  });
  await suite.test("independent workers deliver a due reminder once and leave uncertain attempts unplayed", async () => {
   const dueAt = new Date(Date.now() - 1000); const reminder = await db.reminder.create({ data: { title: "Background reminder", dueAt } }); await organization.queueReminder(reminder.id, dueAt, ["inapp"]);
   await Promise.all([schedulerTick(), schedulerTick()]); assert.equal(await db.notification.count({ where: { title: reminder.title } }), 1);
   assert.equal((await db.notification.findFirstOrThrow({ where: { title: reminder.title } })).status, "DELIVERED");
   const uncertain = await db.scheduledJob.create({ data: { kind: "REMINDER", dedupeKey: "uncertain-test", dueAt, payload: "{}", status: "PROCESSING", claimedAt: new Date(Date.now() - 16 * 60000) } });
   await schedulerTick(); assert.equal((await db.scheduledJob.findUniqueOrThrow({ where: { id: uncertain.id } })).status, "UNKNOWN");
   const cancelled = await db.reminder.create({ data: { title: "Cancelled reminder", dueAt, active: false } }); await organization.queueReminder(cancelled.id, dueAt, ["inapp"]); await schedulerTick(); assert.equal(await db.notification.count({ where: { title: cancelled.title } }), 0);
  });
  await suite.test("Office imports retain originals and sheet citations; document task proposals await review", async () => {
   const { default: ExcelJS } = await import("exceljs"), { importFile } = await import("../lib/abilities/documents"), { analyzeFiles } = await import("../lib/abilities/analysis");
   const book = new ExcelJS.Workbook(); const sheet = book.addWorksheet("Budget"); sheet.addRow(["Review budget", 250]);
   const bytes = await book.xlsx.writeBuffer(); const file = await importFile(new File([new Uint8Array(bytes)], "budget.xlsx"));
   const stored = await db.knowledgeFile.findUniqueOrThrow({ where: { id: file.id }, include: { chunks: true } }); assert.ok(stored.storageKey); assert.equal(stored.chunks[0].locator, "sheet Budget"); assert.match(stored.content, /250/);
   set("AI_PROVIDER", "openai-compatible"); set("AI_MODEL", "test-model"); set("AI_API_KEY", "private-ai-test-key"); set("AI_BASE_URL", "https://model.example/v1");
   await assert.rejects(() => analyzeFiles({ fileIds: [file.id], instruction: "Review the budget", createTasks: true }), /sharing is disabled/);
   await db.systemSetting.create({ data: { key: "privacy.externalContext", value: "true" } });
   globalThis.fetch = async (_url, init) => { assert.match(String(init?.body), /budget.xlsx: sheet Budget/); return new Response('data: '+JSON.stringify({ choices: [{ delta: { content: JSON.stringify({ summary: "Source facts: The budget is 250 [budget.xlsx: sheet Budget].", tasks: [{ title: "Review budget", description: "Suggested from Budget sheet, row 1." }] }) } }] })+'\n\ndata: [DONE]\n\n'); };
   const before = await db.task.count(); const analysis = await analyzeFiles({ fileIds: [file.id], instruction: "Review the budget and propose tasks", createTasks: true }); assert.equal(await db.task.count(), before); assert.equal(analysis.proposals.length, 1);
   assert.equal((await action(request({ action: "proposals-accept", noteId: analysis.note.id, indexes: [0] }))).status, 200); assert.equal(await db.task.count(), before + 1);
   await action(request({ action: "proposals-accept", noteId: analysis.note.id, indexes: [0] })); assert.equal(await db.task.count(), before + 1); globalThis.fetch = originalFetch;
  });
  await suite.test("calls require verified opt-in; signed provider updates and stop requests are enforced", async () => {
   const phone = await import("../lib/integrations/phone");
   const fields = { action: "phone-save", phone: "+15550000002", enabled: false, paused: false, localTime: "08:30", timezone: "Europe/Helsinki", days: [1, 2, 3, 4, 5], topics: ["appointments", "tasks"], maxDuration: 180, voicemail: "generic" };
   assert.equal((await action(request(fields))).status, 200);
   assert.equal((await action(request({ ...fields, enabled: true, verifiedAt: new Date().toISOString() }))).status, 400);
   await assert.rejects(() => phone.startCall(), /needs/);
   for (const [name, value] of Object.entries({ TWILIO_ACCOUNT_SID: "AC" + "0".repeat(32), TWILIO_AUTH_TOKEN: "private-twilio-test-token", TWILIO_FROM_NUMBER: "+15550000001", TWILIO_VERIFY_SERVICE_SID: "VA" + "0".repeat(32), ELEVENLABS_API_KEY: "private-eleven-test-key", ELEVENLABS_VOICE_ID: "test-voice-id", EDITH_PUBLIC_URL: "https://edith.example" })) set(name, value);
   let calls = 0, speech = 0;
   globalThis.fetch = async (url, init) => {
    if (String(url).startsWith("https://api.elevenlabs.io")) { speech++; assert.equal(new Headers(init?.headers).get("xi-api-key"), "private-eleven-test-key"); return new Response(new Uint8Array([1, 2, 3]), { headers: { "Content-Type": "audio/mpeg" } }); }
    if (String(url).startsWith("https://verify.twilio.com/")) return Response.json({ status: "approved" });
    assert.match(String(url), /api.twilio.com.*Calls.json/); calls++; const body = new URLSearchParams(String(init?.body)); assert.equal(body.get("To"), fields.phone); assert.equal(body.get("MachineDetection"), "Enable"); return Response.json({ sid: "CA" + "1".repeat(32), status: "queued" });
   };
   await phone.verifyPhone("123456"); await assert.rejects(() => phone.startCall(), /opt-in/);
   assert.equal((await action(request({ ...fields, enabled: true }))).status, 200);
   const call = await phone.startCall("test-call-job"); assert.equal(call.status, "QUEUED"); assert.equal(calls, 1); assert.ok(speech > 0);
   await phone.startCall("test-call-job"); assert.equal(calls, 1);
   const signed = (stage: string, parameters: Record<string, string>) => { const url = `https://edith.example/api/hooks/phone?call=${call.id}&stage=${stage}`; const form = new URLSearchParams({ CallSid: call.providerId!, ...parameters }); let value = url; for (const key of [...form.keys()].sort()) value += key + form.get(key); return new Request(url, { method: "POST", headers: { "x-twilio-signature": createHmac("sha1", process.env.TWILIO_AUTH_TOKEN!).update(value).digest("base64"), "Content-Type": "application/x-www-form-urlencoded" }, body: form }); };
   assert.equal((await hook(new Request(`https://edith.example/api/hooks/phone?call=${call.id}&stage=consent`, { method: "POST", body: "SpeechResult=yes" }))).status, 403);
   await hook(signed("consent", { SpeechResult: "yes" })); assert.equal((await db.callRecord.findUniqueOrThrow({ where: { id: call.id } })).consent, true);
   const before = await db.task.count(); await hook(signed("command", { SpeechResult: "add a task to review the call report" })); await hook(signed("command", { SpeechResult: "add a task to review the call report" })); assert.equal(await db.task.count(), before + 1);
   await db.scheduledJob.create({ data: { kind: "DAILY_CALL", dedupeKey: "future-test-call", dueAt: new Date(Date.now() + 3600000), payload: "{}" } });
   await hook(signed("command", { SpeechResult: "Stop calling me" })); assert.equal((await db.callSchedule.findUniqueOrThrow({ where: { id: "local" } })).enabled, false); assert.equal((await db.scheduledJob.findUniqueOrThrow({ where: { dedupeKey: "future-test-call" } })).status, "CANCELLED");
   await db.callSchedule.update({ where: { id: "local" }, data: { enabled: true } });
   await db.scheduledJob.create({ data: { kind: "DAILY_CALL", dedupeKey: "paused-test-call", dueAt: new Date(Date.now() + 3600000), payload: "{}" } });
   await action(request({ action: "calls-pause" })); await schedulerTick();
   await assert.rejects(() => phone.startCall(), /resume if paused/); assert.equal(calls, 1);
   assert.equal((await db.scheduledJob.findUniqueOrThrow({ where: { dedupeKey: "paused-test-call" } })).status, "CANCELLED");
   await db.callSchedule.update({ where: { id: "local" }, data: { paused: false } });
   await db.callRecord.updateMany({ data: { createdAt: new Date(Date.now() - 120000) } });
   globalThis.fetch = async url => { if (String(url).startsWith("https://api.elevenlabs.io")) return new Response(new Uint8Array([1, 2, 3])); calls++; throw new TypeError("Mock interrupted transport"); };
   await assert.rejects(() => phone.startCall("uncertain-call-job"), /did not confirm/);
   assert.equal((await phone.startCall("uncertain-call-job")).status, "UNKNOWN"); assert.equal(calls, 2);
   const response = await state(new Request("http://localhost/api/workspace", { headers: { cookie: "edith_session=" + session } })); const json = await response.text(); assert.ok(!json.includes("private-eleven-test-key")); assert.ok(!json.includes("private-ai-test-key")); assert.ok(!json.includes("private-twilio-test-token"));
   globalThis.fetch = originalFetch;
  });
  await suite.test("calendar authorization is scoped and cancelled events cancel queued reminders", async () => {
   const calendar = await import("../lib/integrations/calendar");
   set("GOOGLE_CLIENT_ID", "test-client"); set("GOOGLE_CLIENT_SECRET", "private-google-test-secret");
   const url = new URL(await calendar.calendarAuthorization(false)); assert.match(url.searchParams.get("scope")!, /calendar.readonly/); assert.ok(!url.searchParams.get("scope")!.includes("calendar.events"));
   await db.calendarConnection.create({ data: { encryptedTokens: keys.encrypt({ access_token: "private-access-token", refresh_token: "private-refresh-token", expires_at: Date.now() + 3600000 }), calendars: JSON.stringify([{ id: "primary", summary: "Personal", accessRole: "owner" }]), writable: false } });
   const event = await db.calendarEvent.create({ data: { title: "Cancelled appointment", externalId: "primary:event-one", calendarId: "primary", source: "google", startAt: new Date(), endAt: new Date(Date.now() + 3600000) } });
   const reminder = await db.reminder.create({ data: { title: event.title, dueAt: new Date(), eventId: event.id } }); await organization.queueReminder(reminder.id, reminder.dueAt, ["inapp"]);
   globalThis.fetch = async (url, init) => { assert.ok(String(url).includes("singleEvents=true")); assert.equal(new Headers(init?.headers).get("Authorization"), "Bearer private-access-token"); return Response.json({ items: [{ id: "event-one", status: "cancelled" }] }); };
   await calendar.syncCalendar(); assert.equal((await db.reminder.findUniqueOrThrow({ where: { id: reminder.id } })).active, false); assert.equal((await db.scheduledJob.findFirstOrThrow({ where: { dedupeKey: { startsWith: "reminder:" + reminder.id } } })).status, "CANCELLED");
   const result = await action(request({ action: "calendar-create", confirmed: true, calendarId: "primary", title: "Unauthorized modification", startAt: new Date().toISOString(), endAt: new Date(Date.now() + 3600000).toISOString() })); assert.equal(result.status, 403);
   const startAt = new Date(Date.now() + 86400000), movedAt = new Date(startAt.getTime() + 3600000);
   const moved = await db.calendarEvent.create({ data: { title: "Moved appointment", externalId: "primary:moved", calendarId: "primary", source: "google", startAt, endAt: new Date(startAt.getTime() + 3600000) } });
   const linked = await db.reminder.create({ data: { title: moved.title, dueAt: new Date(startAt.getTime() - 15 * 60000), eventId: moved.id } }); await organization.queueReminder(linked.id, linked.dueAt, ["inapp"]);
   globalThis.fetch = async () => Response.json({ items: [{ id: "moved", summary: moved.title, start: { dateTime: movedAt.toISOString() }, end: { dateTime: new Date(movedAt.getTime() + 3600000).toISOString() } }] });
   await calendar.syncCalendar(); assert.equal((await db.reminder.findUniqueOrThrow({ where: { id: linked.id } })).dueAt.toISOString(), new Date(movedAt.getTime() - 15 * 60000).toISOString());
   assert.equal(await db.scheduledJob.count({ where: { status: "WAITING", dedupeKey: { startsWith: "reminder:" + linked.id } } }), 1);
   await action(request({ action: "calendar-disconnect" })); assert.equal((await db.reminder.findUniqueOrThrow({ where: { id: linked.id } })).active, false);
   assert.equal(await db.scheduledJob.count({ where: { status: "WAITING", dedupeKey: { startsWith: "reminder:" + linked.id } } }), 0);
   globalThis.fetch = originalFetch;
  });
 } finally {
  globalThis.fetch = originalFetch;
  for (const [name, value] of originalEnvironment) { if (value === undefined) delete process.env[name]; else process.env[name] = value; }
  await db.$disconnect(); rmSync(root, { recursive: true, force: true });
 }
});
