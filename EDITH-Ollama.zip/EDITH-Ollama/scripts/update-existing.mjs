import { cpSync, existsSync, readFileSync, realpathSync } from "node:fs";
import { dirname, relative, resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";

// Copy application files into an existing installation, preserving private data.
const source = realpathSync(resolve(dirname(fileURLToPath(import.meta.url)), ".."));
const argument = process.argv[2];
if (!argument) throw new Error("Provide your existing E.D.I.T.H. folder: node scripts/update-existing.mjs ~/Downloads/EDITH-Emiliano");
if (!existsSync(resolve(argument, "package.json"))) throw new Error("The destination must be your existing E.D.I.T.H. folder.");
const target = realpathSync(resolve(argument));
if (source === target || source.startsWith(target + sep) || target.startsWith(source + sep)) throw new Error("Extract the update beside your existing folder before updating.");
if (JSON.parse(readFileSync(resolve(target, "package.json"), "utf8")).name !== "edith") throw new Error("The destination is not an E.D.I.T.H. installation.");
const excluded = new Set([".git", "node_modules", ".next", ".edith-runtime", "generated", "test-results", "playwright-report", "__pycache__"]);
cpSync(source, target, {
 recursive: true,
 filter(path) {
  const parts = relative(source, path).split(sep);
  return !parts.some(part => excluded.has(part) || (part.startsWith(".env") && part !== ".env.example") || /\.(?:db(?:-.*)?|pyc|tsbuildinfo)$/.test(part));
 },
});
console.log("Application files updated. Your private settings, database and storage were preserved. From your existing folder, run bash scripts/setup-cloud.sh, then npm run ai:ollama. Restart the app and scheduler afterward.");
