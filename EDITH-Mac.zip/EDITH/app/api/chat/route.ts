import { greetingReply, answerTokens } from "@/lib/ai/replies";
import { getModelConfiguration } from "@/lib/ai/config";
import { db } from "@/lib/db";
import { chatInput } from "@/lib/validation";
import { getContext, event, initialize } from "@/lib/service";
import {
  getProvider,
  providerConfigured,
  type AIMessage,
} from "@/lib/ai/provider";
import { apiError, checkOrigin } from "@/lib/http";
export async function POST(request: Request) {
  try {
    checkOrigin(request);
    const input = chatInput.parse(await request.json());
    await initialize();
    const conversation = input.conversationId
      ? await db.conversation.findUniqueOrThrow({
          where: { id: input.conversationId },
        })
      : await db.conversation.create({
          data: { title: input.prompt.slice(0, 70) },
        });
    const history = await db.message.findMany({
      where: { conversationId: conversation.id },
      orderBy: { createdAt: "desc" },
      take: 12,
    });
    await db.message.create({
      data: {
        conversationId: conversation.id,
        role: "user",
        content: input.prompt,
      },
    });
    await event("QUERY RECEIVED");
    const settings = await db.userSettings.findUnique({where:{id:"local"}});
    let actionResponse = greetingReply(input.prompt, settings?.displayName) ?? "";
    const remember = input.prompt.match(/^remember(?: that)?\s+(.+)/i);
    const task = input.prompt.match(/^create a task(?: to)?\s+(.+)/i);
    if (remember) {
      const settings = await db.userSettings.findUnique({
        where: { id: "local" },
      });
      if (settings?.memoryEnabled) {
        await db.memory.create({
          data: {
            title: remember[1].slice(0, 100),
            content: remember[1],
            category: "CUSTOM",
          },
        });
        await event("MEMORY CREATED");
        actionResponse = `I've stored this in long-term memory: ${remember[1]}`;
      } else
        actionResponse =
          "Memory is disabled. Enable it in Settings before storing this.";
    }
    if (task) {
      await db.task.create({ data: { title: task[1].slice(0, 200) } });
      await event("TASK CREATED");
      actionResponse = `Task created: ${task[1]}. Set its due date and priority in Tasks.`;
    }
    const context = await getContext(input.prompt);
    await event("MEMORY SEARCH COMPLETE");
    const modelConfig = await getModelConfiguration();
    const sendContext =
      !providerConfigured(modelConfig) ||
      modelConfig.provider === "local" ||
      process.env.ALLOW_EXTERNAL_CONTEXT === "true"
        ? context
        : { memories: [], knowledge: [], tasks: [], sources: [] };
    const messages: AIMessage[] = [
      ...history.reverse().filter(m => m.role !== "assistant" || !/^(?:Okay,? the user|The user (?:said|is asking)|I need to respond as EDITH)/i.test(m.content)).map((m) => ({
        role: m.role as "user" | "assistant",
        content: m.content,
      })),
      { role: "user", content: input.prompt },
    ];
    const encoder = new TextEncoder();
    const stream = new ReadableStream({
      async start(controller) {
        const send = (data: object) =>
          controller.enqueue(encoder.encode(JSON.stringify(data) + "\n"));
        let content = "";
        try {
          send({
            type: "meta",
            conversationId: conversation.id,
            sources: sendContext.sources,
            memoryCount: sendContext.memories.length,
          });
          await event("CONTEXT ASSEMBLED");
          if (actionResponse) {
            content = actionResponse;
            send({ type: "token", content });
          } else
            for await (const token of answerTokens(getProvider(modelConfig).stream(
              messages,
              sendContext,
            ))) {
              content += token;
              send({ type: "token", content: token });
            }
          await db.message.create({
            data: {
              conversationId: conversation.id,
              role: "assistant",
              content,
            },
          });
          await db.conversation.update({
            where: { id: conversation.id },
            data: { updatedAt: new Date() },
          });
          await event("RESPONSE COMPLETE");
          send({ type: "done" });
        } catch {
          await event("MODEL CONNECTION INTERRUPTED");
          send({
            type: "error",
            error:
              "Model connection interrupted. Check your server configuration and retry.",
          });
        } finally {
          controller.close();
        }
      },
    });
    return new Response(stream, {
      headers: {
        "Content-Type": "application/x-ndjson",
        "Cache-Control": "no-cache",
      },
    });
  } catch (error) {
    return apiError(error);
  }
}
