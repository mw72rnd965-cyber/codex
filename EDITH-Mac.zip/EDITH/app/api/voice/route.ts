import { z } from "zod";
import { db } from "@/lib/db";
import { checkOrigin } from "@/lib/http";
import { speechText, LOCAL_VOICES, VOICE_PREVIEW_TEXT } from "@/lib/voice/text";
const schema = z.object({
  text: z.string().trim().min(1).max(4000).optional(),
  preview: z.boolean().optional(),
  voice: z.enum(["af_sarah", "af_bella", "af_heart", "bf_emma"]).optional(),
  speed: z.number().min(0.75).max(1.25).optional(),
});
export async function POST(request: Request) {
  try {
    checkOrigin(request);
  } catch {
    return Response.json(
      { error: "Cross-origin request rejected." },
      { status: 403 },
    );
  }
  try {
    const input = schema.parse(await request.json());
    const settings = await db.userSettings.findUnique({
      where: { id: "local" },
    });
    const text = speechText(
      input.preview ? VOICE_PREVIEW_TEXT : (input.text ?? ""),
    );
    if (!text)
      return Response.json({ error: "Speech text is empty." }, { status: 400 });
    const voice = input.voice ?? settings?.voiceId ?? "af_sarah";
    if (!LOCAL_VOICES.some((v) => v.id === voice))
      return Response.json(
        { error: "Select a supported local voice." },
        { status: 400 },
      );
    const response = await fetch("http://127.0.0.1:8881/speech", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        text,
        voice,
        speed: input.speed ?? settings?.voiceRate ?? 0.94,
      }),
      signal: AbortSignal.timeout(90000),
    });
    if (!response.ok) throw new Error("Local voice generation failed");
    return new Response(response.body, {
      headers: { "Content-Type": "audio/wav", "Cache-Control": "no-store" },
    });
  } catch (error) {
    if (error instanceof z.ZodError)
      return Response.json(
        { error: "Invalid speech request." },
        { status: 400 },
      );
    return Response.json(
      {
        error:
          "Local voice is unavailable. Start the EDITH voice service or select a browser voice.",
      },
      { status: 503 },
    );
  }
}
