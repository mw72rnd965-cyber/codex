import { AppShell } from "@/components/edith/AppShell";
export default function Home() {
  return <AppShell />;
}
