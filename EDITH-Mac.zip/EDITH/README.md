# EDITH

A local-first personal intelligence workspace with an original dark cyan HUD, interactive neural topology, streaming conversation, explicit long-term memory, document retrieval, tasks, and notes.

## Run

Requires Node.js 24 (Node 22.12+ also supported).

```sh
npm ci --cache /workspace/.npm-cache
cp .env.example .env # only on first setup; preserve an existing .env
npm run db:setup
npm run dev
```

The development server listens on port 3000. For a production instance, use `npm run build` and `npm start`.

## Provider configuration

Demo mode works without credentials and clearly labels its responses. To use an OpenAI-compatible API or a local model, set these server-side environment variables in `.env`, then restart:

```
AI_PROVIDER=openai-compatible
AI_BASE_URL=https://api.openai.com/v1
AI_MODEL=your-model
AI_API_KEY=your-key-if-required
ALLOW_EXTERNAL_CONTEXT=false
```

Prompts and recent conversation go to the configured provider. Retrieved local memory, documents, and tasks are shared only if `ALLOW_EXTERNAL_CONTEXT=true`. API keys are never sent to the browser. The endpoint is administrator-controlled, not accepted from chat. Provider connection testing is available in Settings.

`DATABASE_URL=file:./prisma/edith.db` uses local SQLite. Back up this database to preserve your data. Generated Prisma client files and database contents are ignored by Git. Setup uses a pinned engine-free Prisma generator and versioned SQLite migrations, so it needs no downloaded Rust engine. Re-running `db:setup` preserves existing data; future schema changes require a new migration.

## Features

- Core dashboard with a gently animated, keyboard-interactive neural graph; decorative topology and signal charts are explicitly marked simulated.
- Streaming conversation with saved sessions and visible retrieved document sources.
- Explicit `Remember that …` commands; memory search, creation, editing, deletion, categories, and graph inspection.
- TXT, Markdown, and JSON uploads, up to 1 MB; indexed chunks and keyword retrieval.
- Tasks with statuses, priorities, due dates, and natural-language `Create a task to …` creation.
- Editable, searchable notes with tags and pinning.
- Command palette (`Ctrl/Cmd + K`) and slash navigation commands.
- Browser speech recognition where supported; review transcripts before sending. Optional browser speech synthesis.
- Local settings, one-time session boot animation, first-run setup, system activity, responsive layouts, and reduced-motion support.

## Validation

```sh
npm run lint
npm run typecheck
npm test
npm run build
```

Browser smoke tests use the system Chromium executable; see `tests/browser.spec.ts`. Run a server, then use `npm exec -- playwright test`.

## Current limits

This is a single-operator local application, not a publicly hosted multiuser service. Add authentication before exposing it to untrusted networks. Demo mode retrieves real local data but does not perform open-ended model reasoning. Retrieval is lexical rather than embedding-based. Task due dates are assigned in the Tasks editor; natural-language date parsing and ambiguous task changes are not automated. Notes accept and render Markdown. Initial document support excludes PDF/DOCX. Browser voice support depends on the browser and its permissions; recognition may use the browser vendor's service. No real tracking, surveillance, weapon, or device-control modules exist.

The TikTok design reference was inaccessible in this environment; the design follows the uploaded written brief. A screenshot or uploaded clip is needed to compare it with the video.


## Free local intelligence and EDITH voice

The free model integration uses **Qwen3 8B Q4_K_M**, served locally by llama.cpp. It needs roughly 5 GB of model storage and runs on the CPU without an API key or per-request fees. The four-core cloud machine prioritizes quality over instant responses. The download has not completed: The model file CDN (`us.aws.cdn.hf.co`) is blocked by the current network policy; Hugging Face metadata is accessible. Review and save the prepared domain additions in environment settings before the download can finish.

```sh
npm run runtimes:setup  # verified runtime, Kokoro models, pinned Python dependencies
npm run ai:setup        # downloads Qwen from its official repository and verifies its SHA-256
npm run ai:serve        # start the local model on loopback port 11434
npm run voice:serve     # start local Kokoro speech on loopback port 8881
npm run dev            # app, in a third terminal/session
```

After the model is online, choose **Settings → Use free local model**. The app refuses to select an offline model and preserves demo mode until setup is complete. Local model requests receive retrieved local context without sending it to an external service. Selecting Demo returns to the simulated provider.

Speech uses **Kokoro-82M**, a free, locally generated neural voice. The EDITH preset is a calm American female voice (`af_sarah`) at 0.94× speed; Bella, Heart, and a British female voice are also available. Settings include voice preview, speed, and optional system/browser voices with pitch control. Use the stop button to interrupt speech. Code blocks, Markdown marks, and URLs are cleaned before speaking. This creates an original assistant voice; it is not a recording or clone of the film actor.

Local speech was tested by synthesizing and playing preview audio. Browser/system voice availability depends on the operating system, and those voices may use a browser vendor's service. The Kokoro route stays local. Live AI and speech require the running app and services; the standalone HTML file is a visual preview.

The database now uses schema version 2. Setup applies forward migrations without resetting your existing data. Voice output settings, voice choice, and playback speed persist in SQLite.

Runtime/model licenses and sources: [llama.cpp](https://github.com/ggml-org/llama.cpp) (MIT), [Qwen3](https://huggingface.co/Qwen/Qwen3-8B-GGUF) (Apache 2.0), [Kokoro-82M](https://huggingface.co/hexgrad/Kokoro-82M) (Apache 2.0), and [kokoro-onnx](https://github.com/thewh1teagle/kokoro-onnx) (MIT). Runtime and voice files are checked against their official GitHub release SHA-256 digests.
