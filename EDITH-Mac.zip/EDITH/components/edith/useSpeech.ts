"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import type { Settings } from "./types";
import { chooseBrowserVoice } from "@/lib/voice/browser";
import { speechText } from "@/lib/voice/text";
export type VoicePreferences = Pick<
  Settings,
  "voiceEngine" | "voiceId" | "voiceRate" | "voicePitch"
>;
export function useSpeech(settings?: VoicePreferences) {
  const [status, setStatus] = useState<"idle" | "preparing" | "speaking">(
    "idle",
  );
  const [error, setError] = useState("");
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const active = useRef<{
    audio?: HTMLAudioElement;
    url?: string;
    controller?: AbortController;
  }>({});
  const sequence = useRef(0);
  const stop = useCallback(() => {
    sequence.current++;
    active.current.controller?.abort();
    active.current.audio?.pause();
    if (active.current.url) URL.revokeObjectURL(active.current.url);
    active.current = {};
    if ("speechSynthesis" in window) window.speechSynthesis.cancel();
    setStatus("idle");
  }, []);
  useEffect(() => {
    if (!("speechSynthesis" in window)) return;
    const update = () => setVoices(window.speechSynthesis.getVoices());
    update();
    window.speechSynthesis.addEventListener("voiceschanged", update);
    return () =>
      window.speechSynthesis.removeEventListener("voiceschanged", update);
  }, []);
  useEffect(
    () => () => {
      sequence.current++;
      active.current.controller?.abort();
      active.current.audio?.pause();
      if (active.current.url) URL.revokeObjectURL(active.current.url);
      if ("speechSynthesis" in window) window.speechSynthesis.cancel();
    },
    [],
  );
  const speak = useCallback(
    async (text: string, override?: VoicePreferences) => {
      stop();
      setError("");
      const current = sequence.current;
      const prefs = override ??
        settings ?? {
          voiceEngine: "kokoro",
          voiceId: "af_sarah",
          voiceRate: 0.94,
          voicePitch: 1,
        };
      const clean = speechText(text);
      if (!clean) return;
      try {
        setStatus("preparing");
        if (prefs.voiceEngine === "browser") {
          if (!("speechSynthesis" in window))
            throw new Error("This browser does not support speech output.");
          const available = window.speechSynthesis.getVoices();
          if (!available.length)
            throw new Error(
              "No browser voices are installed. Select EDITH neural voice instead.",
            );
          const utterance = new SpeechSynthesisUtterance(clean);
          const selected = chooseBrowserVoice(available, prefs.voiceId);
          if (selected) {
            utterance.voice = selected;
            utterance.lang = selected.lang;
          }
          utterance.rate = prefs.voiceRate;
          utterance.pitch = prefs.voicePitch;
          utterance.onstart = () => {
            if (sequence.current === current) setStatus("speaking");
          };
          utterance.onend = () => {
            if (sequence.current === current) setStatus("idle");
          };
          utterance.onerror = () => {
            if (sequence.current === current) {
              setStatus("idle");
              setError(
                "Browser speech playback failed. Try EDITH neural voice.",
              );
            }
          };
          window.speechSynthesis.speak(utterance);
          return;
        }
        const controller = new AbortController();
        active.current = { controller };
        const response = await fetch("/api/voice", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            text: clean,
            voice: prefs.voiceId,
            speed: prefs.voiceRate,
          }),
          signal: controller.signal,
        });
        if (!response.ok) {
          const data = await response.json();
          throw new Error(data.error ?? "Voice generation failed");
        }
        const blob = await response.blob();
        if (sequence.current !== current) return;
        const url = URL.createObjectURL(blob);
        const audio = new Audio(url);
        active.current = { audio, url, controller };
        audio.onended = () => {
          if (sequence.current === current) {
            URL.revokeObjectURL(url);
            active.current = {};
            setStatus("idle");
          }
        };
        audio.onerror = () => {
          if (sequence.current === current) {
            stop();
            setError("Audio playback failed. Try previewing the voice again.");
          }
        };
        await audio.play();
        if (sequence.current === current) setStatus("speaking");
      } catch (e) {
        if (sequence.current === current) {
          stop();
          setError(e instanceof Error ? e.message : "Speech failed");
        }
      }
    },
    [settings, stop],
  );
  return { speak, stop, status, error, voices, clearError: () => setError("") };
}
export type SpeechController = ReturnType<typeof useSpeech>;
