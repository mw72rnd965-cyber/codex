"use client";
import ReactMarkdown from "react-markdown";
import { useState } from "react";
import {
  Plus,
  Search,
  Trash2,
  Check,
  Pin,
  Upload,
  FileText,
  ArrowUpRight,
  Pencil,
} from "lucide-react";
import type { State, Mutate, View, Memory, Task, Note } from "./types";
import { HUDPanel } from "./HUDPanel";
export function DataWorkspace({
  view,
  state,
  mutate,
  upload,
}: {
  view: View;
  state: State;
  mutate: Mutate;
  upload: () => void;
}) {
  const [inspected, setInspected] = useState<{
    name: string;
    content: string;
  } | null>(null);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("ALL");
  const [editing, setEditing] = useState<Memory | Task | Note | null>(null);
  const [form, setForm] = useState(false);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [tag, setTag] = useState("CUSTOM");
  const [priority, setPriority] = useState("NORMAL");
  const [due, setDue] = useState("");
  const [saving, setSaving] = useState(false);
  const kind = view === "memory" ? "memory" : view;
  const rows =
    view === "memory"
      ? state.memories
      : view === "tasks"
        ? state.tasks
        : view === "notes"
          ? state.notes
          : [];
  const open = (row: Memory | Task | Note | null) => {
    setEditing(row);
    setTitle(row?.title ?? "");
    setContent(
      row
        ? "description" in row
          ? row.description
          : "content" in row
            ? row.content
            : ""
        : "",
    );
    setTag(
      row && "category" in row
        ? row.category
        : row && "tags" in row
          ? row.tags
          : view === "notes"
            ? ""
            : "CUSTOM",
    );
    setPriority(row && "priority" in row ? row.priority : "NORMAL");
    setDue(
      row && "dueDate" in row && row.dueDate ? row.dueDate.slice(0, 10) : "",
    );
    setForm(true);
  };
  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const data =
        view === "memory"
          ? {
              title,
              content,
              category: tag,
              importance:
                editing && "importance" in editing ? editing.importance : 0.7,
            }
          : view === "tasks"
            ? {
                title,
                description: content,
                priority,
                status:
                  editing && "status" in editing ? editing.status : "PENDING",
                dueDate: due ? new Date(due).toISOString() : null,
              }
            : {
                title,
                content,
                tags: tag,
                pinned: editing && "pinned" in editing ? editing.pinned : false,
              };
      await mutate(
        kind,
        editing ? { ...data, id: editing.id } : data,
        editing ? "PATCH" : "POST",
      );
      setForm(false);
    } catch {
      /* The workspace alert presents the failed save. */
    } finally {
      setSaving(false);
    }
  };
  const remove = (id: string) => {
    if (window.confirm("Delete this item permanently?"))
      void mutate(kind, { id }, "DELETE").catch(() => {});
  };
  const visible = rows.filter(
    (r) =>
      `${r.title} ${"content" in r ? r.content : r.description}`
        .toLowerCase()
        .includes(search.toLowerCase()) &&
      (category === "ALL" ||
        (view === "memory" && "category" in r && r.category === category) ||
        (view === "tasks" && "status" in r && r.status === category)),
  );
  if (view === "knowledge")
    return (
      <div className="data-workspace">
        <div className="workspace-toolbar">
          <div className="search-field">
            <Search size={16} />
            <input
              aria-label="Search knowledge files"
              placeholder="Search indexed files…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <button className="primary-button" onClick={upload}>
            <Upload size={15} /> ADD KNOWLEDGE
          </button>
        </div>
        <div className="privacy-note">
          Files stay in the local database. Ask a matching question to retrieve
          their contents. External context sharing is{" "}
          {state.externalContext ? "enabled" : "disabled"}.
        </div>
        <HUDPanel title="KNOWLEDGE INDEX" subtitle="TXT / MD / JSON · MAX 1 MB">
          <div className="knowledge-list">
            {state.knowledge
              .filter((f) =>
                f.name.toLowerCase().includes(search.toLowerCase()),
              )
              .map((f) => (
                <article key={f.id}>
                  <FileText size={24} />
                  <div>
                    <h3>{f.name}</h3>
                    <span className="micro">
                      {f._count.chunks} CHUNKS ·{" "}
                      {new Date(f.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                  <span className="status-label">INDEXED</span>
                  <button
                    className="outline-button"
                    onClick={async () => {
                      const r = await fetch(`/api/data/knowledge?id=${f.id}`);
                      if (r.ok) setInspected(await r.json());
                    }}
                  >
                    INSPECT
                  </button>
                  <button
                    className="icon-button"
                    aria-label={`Delete ${f.name}`}
                    onClick={() => {
                      if (
                        confirm(
                          "Delete this knowledge file and its indexed chunks?",
                        )
                      )
                        void mutate("knowledge", { id: f.id }, "DELETE").catch(
                          () => {},
                        );
                    }}
                  >
                    <Trash2 size={15} />
                  </button>
                </article>
              ))}
            {!state.knowledge.length && (
              <div className="empty">
                <FileText size={30} />
                <h3>NO KNOWLEDGE INDEXED</h3>
                <p>Add documents to extend EDITH’s knowledge.</p>
                <button className="outline-button" onClick={upload}>
                  ADD YOUR FIRST DOCUMENT <ArrowUpRight size={14} />
                </button>
              </div>
            )}
          </div>
        </HUDPanel>
        {inspected && (
          <div className="modal-backdrop">
            <div
              className="editor-modal"
              role="dialog"
              aria-modal="true"
              aria-label="Knowledge contents"
            >
              <button
                autoFocus
                className="close"
                aria-label="Close document"
                onClick={() => setInspected(null)}
              >
                ×
              </button>
              <h2>{inspected.name}</h2>
              <pre className="document-content">{inspected.content}</pre>
            </div>
          </div>
        )}
      </div>
    );
  return (
    <div className="data-workspace">
      <div className="workspace-toolbar">
        <div className="search-field">
          <Search size={16} />
          <input
            aria-label={`Search ${view}`}
            placeholder={`Search ${view}…`}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <button className="primary-button" onClick={() => open(null)}>
          <Plus size={15} /> NEW{" "}
          {view === "memory" ? "MEMORY" : view === "tasks" ? "TASK" : "NOTE"}
        </button>
      </div>
      {view !== "notes" && (
        <div className="filter-row">
          {(view === "memory"
            ? [
                "ALL",
                "PROFILE",
                "PREFERENCES",
                "PROJECTS",
                "PEOPLE",
                "GOALS",
                "FACTS",
                "CUSTOM",
              ]
            : ["ALL", "PENDING", "ACTIVE", "COMPLETED", "ARCHIVED"]
          ).map((c) => (
            <button
              key={c}
              onClick={() => setCategory(c)}
              className={category === c ? "selected" : ""}
            >
              {c}
            </button>
          ))}
        </div>
      )}
      <div className="record-grid">
        {visible.map((row) => (
          <HUDPanel
            key={row.id}
            title={row.title}
            subtitle={
              "category" in row
                ? row.category
                : "status" in row
                  ? `${row.status} / ${row.priority}`
                  : row.tags || "NOTE"
            }
            actions={
              <div className="record-actions">
                <button
                  className="icon-button"
                  aria-label={`Edit ${row.title}`}
                  onClick={() => open(row)}
                >
                  <Pencil size={14} />
                </button>
                <button
                  className="icon-button"
                  aria-label={`Delete ${row.title}`}
                  onClick={() => remove(row.id)}
                >
                  <Trash2 size={14} />
                </button>
              </div>
            }
          >
            <div className="record-content">
              {view === "notes" && "content" in row ? (
                <ReactMarkdown>{row.content}</ReactMarkdown>
              ) : "content" in row ? (
                row.content
              ) : (
                row.description || "No additional details."
              )}
            </div>
            <footer className="record-footer">
              <span className="micro">
                {new Date(row.createdAt).toLocaleDateString()}
                {"dueDate" in row && row.dueDate
                  ? ` · DUE ${row.dueDate.slice(0, 10)}`
                  : ""}
              </span>
              {"status" in row && (
                <select
                  aria-label={`Status of ${row.title}`}
                  value={row.status}
                  onChange={(e) =>
                    void mutate(
                      "tasks",
                      { ...row, status: e.target.value },
                      "PATCH",
                    ).catch(() => {})
                  }
                >
                  {["PENDING", "ACTIVE", "COMPLETED", "ARCHIVED"].map((s) => (
                    <option key={s}>{s}</option>
                  ))}
                </select>
              )}
              {"pinned" in row && (
                <button
                  className={`icon-button ${row.pinned ? "selected" : ""}`}
                  aria-label={`Toggle pin for ${row.title}`}
                  onClick={() =>
                    void mutate(
                      "notes",
                      { ...row, pinned: !row.pinned },
                      "PATCH",
                    ).catch(() => {})
                  }
                >
                  <Pin size={15} />
                </button>
              )}
              {"importance" in row && (
                <span className="micro">
                  IMPORTANCE {Math.round(row.importance * 100)}%
                </span>
              )}
            </footer>
          </HUDPanel>
        ))}
      </div>
      {!visible.length && (
        <div className="empty">
          <span className="empty-symbol">◇</span>
          <h3>
            {search
              ? "NO MATCHES"
              : `NO ${view === "memory" ? "MEMORIES STORED" : view === "tasks" ? "ACTIVE TASKS" : "NOTES CAPTURED"}`}
          </h3>
          <p>
            {view === "memory"
              ? "Only explicit memories become long-term context."
              : view === "tasks"
                ? "A clear queue. Make room for your next objective."
                : "Capture the thoughts worth keeping."}
          </p>
        </div>
      )}
      {form && (
        <div className="modal-backdrop">
          <form
            className="editor-modal"
            role="dialog"
            aria-modal="true"
            aria-label={`${editing ? "Edit" : "Create"} ${view}`}
            onSubmit={save}
            onKeyDown={(e) => {
              if (e.key === "Escape") setForm(false);
              if (e.key === "Tab") {
                const controls = e.currentTarget.querySelectorAll<HTMLElement>(
                  "input,textarea,select,button",
                );
                const first = controls[0],
                  last = controls[controls.length - 1];
                if (e.shiftKey && document.activeElement === first) {
                  e.preventDefault();
                  last.focus();
                } else if (!e.shiftKey && document.activeElement === last) {
                  e.preventDefault();
                  first.focus();
                }
              }
            }}
          >
            <header>
              <span className="eyebrow">
                {editing ? "UPDATE" : "CREATE"} / {view.toUpperCase()}
              </span>
              <button
                type="button"
                className="close"
                aria-label="Close editor"
                onClick={() => setForm(false)}
              >
                ×
              </button>
            </header>
            <label>
              Title
              <input
                autoFocus
                required
                maxLength={200}
                value={title}
                onChange={(e) => setTitle(e.target.value)}
              />
            </label>
            <label>
              {view === "tasks" ? "Description" : "Content"}
              <textarea
                required={view === "memory"}
                rows={7}
                value={content}
                onChange={(e) => setContent(e.target.value)}
              />
            </label>
            {view === "memory" ? (
              <label>
                Category
                <select value={tag} onChange={(e) => setTag(e.target.value)}>
                  {[
                    "PROFILE",
                    "PREFERENCES",
                    "PROJECTS",
                    "PEOPLE",
                    "GOALS",
                    "FACTS",
                    "CONVERSATION",
                    "CUSTOM",
                  ].map((c) => (
                    <option key={c}>{c}</option>
                  ))}
                </select>
              </label>
            ) : view === "tasks" ? (
              <div className="form-columns">
                <label>
                  Priority
                  <select
                    value={priority}
                    onChange={(e) => setPriority(e.target.value)}
                  >
                    {["LOW", "NORMAL", "HIGH"].map((c) => (
                      <option key={c}>{c}</option>
                    ))}
                  </select>
                </label>
                <label>
                  Due date
                  <input
                    type="date"
                    value={due}
                    onChange={(e) => setDue(e.target.value)}
                  />
                </label>
              </div>
            ) : (
              <label>
                Tags
                <input value={tag} onChange={(e) => setTag(e.target.value)} />
              </label>
            )}
            <button className="primary-button" disabled={saving}>
              <Check size={15} /> {saving ? "SAVING…" : "SAVE"}
            </button>
          </form>
        </div>
      )}
    </div>
  );
}
