"use client";
import { useMemo, useState } from "react";
import type { Memory } from "./types";
export type GraphNode = {
  id: string;
  type: string;
  label: string;
  strength: number;
  createdAt: string;
  updatedAt: string;
  confidence: number;
  connections: string[];
  x: number;
  y: number;
  content: string;
  source: string;
};
export function NeuralGraph({
  memories,
  processing = false,
  expanded = false,
  reduced = false,
}: {
  memories: Memory[];
  processing?: boolean;
  expanded?: boolean;
  reduced?: boolean;
}) {
  const [selected, setSelected] = useState<GraphNode | null>(null);
  const [filter, setFilter] = useState("ALL");
  const nodes = useMemo(
    () =>
      Array.from({ length: 84 }, (_, i): GraphNode => {
        const angle = i * 2.399963;
        const radius = 145 + Math.sqrt(i / 84) * 145;
        const memory = memories[i];
        return {
          id: memory?.id ?? `sim_${i.toString().padStart(3, "0")}`,
          type: memory
            ? "MEMORY"
            : ["SYSTEM", "CONTEXT", "KNOWLEDGE", "TASKS"][i % 4],
          label: memory?.title ?? `Topology ${i + 1}`,
          strength: memory?.importance ?? 0.3 + (i % 7) / 12,
          createdAt: memory?.createdAt ?? "",
          updatedAt: memory?.updatedAt ?? "",
          confidence: memory?.confidence ?? 0.75,
          connections: [
            "EDITH",
            `sim_${((i + 7) % 84).toString().padStart(3, "0")}`,
          ],
          x: 400 + Math.cos(angle) * radius,
          y: 350 + Math.sin(angle) * radius * 0.86,
          content:
            memory?.content ??
            "Generated visual topology node. Simulation only; this does not represent a stored memory.",
          source: memory?.source ?? "Visual simulation",
        };
      }),
    [memories],
  );
  return (
    <div
      className={`neural-wrap ${processing ? "processing" : ""} ${expanded ? "expanded" : ""} ${reduced ? "still" : ""}`}
    >
      {expanded && (
        <div className="graph-filters">
          {["ALL", "MEMORY", "KNOWLEDGE", "TASKS", "CONTEXT", "SYSTEM"].map(
            (f) => (
              <button
                key={f}
                className={filter === f ? "selected" : ""}
                onClick={() => setFilter(f)}
              >
                {f}
              </button>
            ),
          )}
        </div>
      )}
      <svg
        viewBox="0 0 800 700"
        role="img"
        aria-label="Interactive EDITH neural topology. Decorative nodes are simulated; memory nodes use your stored data."
      >
        <defs>
          <radialGradient id="coreglow">
            <stop stopColor="#40d9e9" stopOpacity=".16" />
            <stop offset="1" stopColor="#40d9e9" stopOpacity="0" />
          </radialGradient>
          <filter id="glow">
            <feGaussianBlur stdDeviation="3" />
          </filter>
        </defs>
        <circle cx="400" cy="350" r="310" fill="url(#coreglow)" />
        <g className="orbital">
          <circle cx="400" cy="350" r="294" className="orbit faint" />
          <circle
            cx="400"
            cy="350"
            r="275"
            className="orbit"
            strokeDasharray="2 12"
          />
          <circle
            cx="400"
            cy="350"
            r="254"
            className="orbit faint"
            strokeDasharray="110 80 10 80"
          />
          <path
            d="M 400 44 A 306 306 0 0 1 701 290 M 400 656 A 306 306 0 0 1 99 410"
            className="orbit arc"
          />
        </g>
        <path
          d="M400 12v40M400 648v40M58 350h40M702 350h40"
          className="crosshair"
        />
        <g className="connections">
          {nodes.map((n, i) => (
            <g
              key={n.id}
              opacity={filter === "ALL" || filter === n.type ? 1 : 0.08}
            >
              <line
                x1={n.x}
                y1={n.y}
                x2={nodes[(i + 7) % nodes.length].x}
                y2={nodes[(i + 7) % nodes.length].y}
                stroke="#5ce6ef"
                strokeOpacity={0.07 + n.strength * 0.12}
              />
              {i % 3 === 0 && (
                <line
                  x1={n.x}
                  y1={n.y}
                  x2="400"
                  y2="350"
                  stroke="#5ce6ef"
                  strokeOpacity=".1"
                />
              )}
              {i % 9 === 0 && !reduced && (
                <circle r="1.8" fill="#a2ffff">
                  <animateMotion
                    dur={`${5 + (i % 4)}s`}
                    repeatCount="indefinite"
                    path={`M${n.x},${n.y} L400,350`}
                  />
                </circle>
              )}
            </g>
          ))}
        </g>
        <g className="node-cloud">
          {nodes.map((n, i) => (
            <g
              key={n.id}
              className="graph-node"
              role="button"
              tabIndex={0}
              aria-label={`${n.type}: ${n.label}`}
              onClick={() => setSelected(n)}
              onKeyDown={(e) => {
                if (e.key === "Enter" || e.key === " ") {
                  e.preventDefault();
                  setSelected(n);
                }
              }}
              style={{
                opacity: filter === "ALL" || filter === n.type ? 1 : 0.1,
              }}
            >
              <circle cx={n.x} cy={n.y} r={10} fill="transparent" />
              <circle
                cx={n.x}
                cy={n.y}
                r={n.type === "MEMORY" ? 4 : 1.7 + n.strength * 1.6}
                fill={n.type === "MEMORY" ? "#98fff0" : "#67dbe9"}
                opacity={0.4 + n.confidence * 0.6}
              />
              {i % 11 === 0 && (
                <circle cx={n.x} cy={n.y} r="7" className="orbit" />
              )}
            </g>
          ))}
        </g>
        <circle
          cx="400"
          cy="350"
          r="115"
          className="orbit core-ring"
          strokeDasharray="170 20 4 20"
        />
        <circle cx="400" cy="350" r="105" className="orbit faint" />
        <circle
          cx="400"
          cy="350"
          r="90"
          fill="#04151be6"
          stroke="#66e8f0"
          strokeOpacity=".3"
        />
        <circle
          cx="400"
          cy="350"
          r="78"
          fill="none"
          stroke="#5ce6ef"
          strokeOpacity=".1"
        />
        <text x="400" y="340" textAnchor="middle" className="core-word">
          E D I T H
        </text>
        <text x="400" y="366" textAnchor="middle" className="core-caption">
          {processing ? "PROCESSING" : "NEURAL CORE"}
        </text>
        <circle cx="370" cy="386" r="2" fill="#64f2c5" />
        <text x="382" y="390" className="core-caption small">
          ONLINE
        </text>
        {[
          { label: "REASONING", x: 400, y: 96 },
          { label: "CONTEXT", x: 636, y: 355 },
          { label: "MEMORY", x: 400, y: 602 },
          { label: "KNOWLEDGE", x: 164, y: 355 },
        ].map(({ label, x, y }) => (
          <g key={label}>
            <rect
              x={x - 53}
              y={y - 13}
              width="106"
              height="25"
              fill="#05151c"
              stroke="#1c4048"
            />
            <text x={x} y={y + 4} textAnchor="middle" className="module-label">
              {label}
            </text>
          </g>
        ))}
        <text x="53" y="80" className="coordinate">
          N 40.7128 / E 074.0060 · SIM
        </text>
        <text x="53" y="634" className="coordinate">
          TOPOLOGY VISUALIZATION / {memories.length} STORED MEMORIES
        </text>
      </svg>
      {selected && (
        <div className="node-detail">
          <button
            className="close"
            onClick={() => setSelected(null)}
            aria-label="Close node details"
          >
            ×
          </button>
          <span className="eyebrow">{selected.type} / NODE INSPECTOR</span>
          <h3>{selected.label}</h3>
          <p>{selected.content}</p>
          <dl>
            <dt>NODE ID</dt>
            <dd>{selected.id}</dd>
            <dt>IMPORTANCE</dt>
            <dd>{Math.round(selected.strength * 100)}%</dd>
            <dt>CREATED</dt>
            <dd>
              {selected.createdAt
                ? new Date(selected.createdAt).toLocaleString()
                : "Generated topology"}
            </dd>
            <dt>CONFIDENCE</dt>
            <dd>{Math.round(selected.confidence * 100)}%</dd>
            <dt>UPDATED</dt>
            <dd>
              {selected.updatedAt
                ? new Date(selected.updatedAt).toLocaleString()
                : "Generated topology"}
            </dd>
            <dt>CONNECTIONS</dt>
            <dd>{selected.connections.join(", ")}</dd>
            <dt>SOURCE</dt>
            <dd>{selected.source}</dd>
          </dl>
        </div>
      )}
      <div className="graph-legend">
        <span>
          <i className="dot" /> Neural topology
        </span>
        <span className="muted">
          SIMULATED NETWORK · SELECT A NODE TO INSPECT
        </span>
      </div>
    </div>
  );
}
