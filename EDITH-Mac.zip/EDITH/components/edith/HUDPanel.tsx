import type { ReactNode } from "react";
export function HUDPanel({
  title,
  subtitle,
  children,
  actions,
  className = "",
}: {
  title: string;
  subtitle?: string;
  children: ReactNode;
  actions?: ReactNode;
  className?: string;
}) {
  return (
    <section className={`hud-panel ${className}`}>
      <header className="panel-head">
        <div>
          <h2>{title}</h2>
          {subtitle && <span className="micro">{subtitle}</span>}
        </div>
        {actions}
      </header>
      {children}
    </section>
  );
}
