"use client";
import { useEffect, useRef, useState } from "react";
import { Search, ArrowUpRight } from "lucide-react";
import type { View } from "./types";
const commands: { label: string; view: View; hint: string }[] = [
  {
    label: "New conversation",
    view: "conversation",
    hint: "Start a fresh session",
  },
  { label: "Search memory", view: "memory", hint: "Explore stored context" },
  {
    label: "Open neural map",
    view: "neural",
    hint: "Inspect the intelligence network",
  },
  { label: "Create task", view: "tasks", hint: "Organize your next action" },
  { label: "Create note", view: "notes", hint: "Capture a thought" },
  { label: "Add knowledge", view: "knowledge", hint: "Index a local document" },
  { label: "System status", view: "system", hint: "Inspect the architecture" },
  { label: "Settings", view: "settings", hint: "Configure your workspace" },
];
export function CommandPalette({
  close,
  navigate,
}: {
  close: () => void;
  navigate: (view: View, fresh?: boolean) => void;
}) {
  const [query, setQuery] = useState("");
  const [active, setActive] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  const list = commands.filter((c) => {
    let pos = 0;
    for (const char of query.toLowerCase()) {
      pos = c.label.toLowerCase().indexOf(char, pos);
      if (pos < 0) return false;
      pos++;
    }
    return true;
  });
  useEffect(() => {
    const prior = document.activeElement as HTMLElement;
    ref.current?.querySelector("input")?.focus();
    return () => prior?.focus();
  }, []);
  return (
    <div className="modal-backdrop" onClick={close}>
      <div
        ref={ref}
        className="command-modal"
        role="dialog"
        aria-modal="true"
        aria-label="Command palette"
        onClick={(e) => e.stopPropagation()}
        onKeyDown={(e) => {
          if (e.key === "Escape") close();
          if (e.key === "ArrowDown") {
            e.preventDefault();
            setActive((a) => Math.min(a + 1, list.length - 1));
          }
          if (e.key === "ArrowUp") {
            e.preventDefault();
            setActive((a) => Math.max(0, a - 1));
          }
          if (e.key === "Enter" && list[active]) {
            navigate(
              list[active].view,
              list[active].label === "New conversation",
            );
            close();
          }
          if (e.key === "Tab") {
            const focusables =
              ref.current?.querySelectorAll<HTMLElement>("input,button");
            if (!focusables?.length) return;
            const first = focusables[0],
              last = focusables[focusables.length - 1];
            if (e.shiftKey && document.activeElement === first) {
              e.preventDefault();
              last.focus();
            } else if (!e.shiftKey && document.activeElement === last) {
              e.preventDefault();
              first.focus();
            }
          }
        }}
      >
        <div className="palette-search">
          <Search size={20} />
          <input
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setActive(0);
            }}
            placeholder="Where shall we go?"
            aria-label="Search commands"
          />
          <button onClick={close}>ESC</button>
        </div>
        <span className="eyebrow palette-label">EDITH COMMAND INTERFACE</span>
        {list.map((c, i) => (
          <button
            key={c.label}
            className={`palette-item ${i === active ? "selected" : ""}`}
            onClick={() => {
              navigate(c.view, c.label === "New conversation");
              close();
            }}
          >
            <span>
              {c.label}
              <small>{c.hint}</small>
            </span>
            <ArrowUpRight size={17} />
          </button>
        ))}
        {!list.length && <p className="empty">NO MATCHING COMMANDS</p>}
      </div>
    </div>
  );
}
