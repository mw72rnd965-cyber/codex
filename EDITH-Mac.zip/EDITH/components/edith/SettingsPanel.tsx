import { LOCAL_VOICES, VOICE_PREVIEW_TEXT } from "@/lib/voice/text";
import type { SpeechController } from "./useSpeech";
import { useState } from "react";
import { HUDPanel } from "./HUDPanel";
import type { State, Mutate, Settings } from "./types";
export function SettingsPanel({
  state,
  mutate,
  speech,
}: {
  state: State;
  mutate: Mutate;
  speech: SpeechController;
}) {
  const [settings, setSettings] = useState<Settings>(state.settings);
  const [status, setStatus] = useState("");
  const save = async () => {
    await mutate("settings", settings);
    setStatus("SETTINGS SAVED");
  };
  const toggle = (
    key: "voiceOutput" | "boot" | "reducedMotion" | "memoryEnabled",
    label: string,
    detail: string,
  ) => (
    <label className="setting-row">
      <span>
        {label}
        <small>{detail}</small>
      </span>
      <input
        type="checkbox"
        checked={settings[key]}
        onChange={(e) => setSettings({ ...settings, [key]: e.target.checked })}
      />
    </label>
  );
  return (
    <div className="settings-grid">
      <HUDPanel title="GENERAL" subtitle="YOUR PERSONAL WORKSPACE">
        <label className="setting-field">
          Operator name
          <input
            value={settings.displayName}
            maxLength={50}
            onChange={(e) =>
              setSettings({ ...settings, displayName: e.target.value })
            }
          />
        </label>
        {toggle("boot", "Boot sequence", "Once per browser session")}
        {toggle(
          "reducedMotion",
          "Reduce motion",
          "Pause ambient movement and particles",
        )}
      </HUDPanel>
      <HUDPanel
        title="AI PROVIDER"
        subtitle={
          state.provider === "mock"
            ? "DEMO MODE"
            : state.provider === "local"
              ? "FREE / LOCAL"
              : "SERVER CONFIGURED"
        }
      >
        <div className="provider-details">
          <span>ACTIVE MODEL</span>
          <strong>{state.model}</strong>
          <div className="model-choice">
            <strong>Qwen3 8B</strong>
            <span className="status-label">FREE · NO API KEY · LOCAL</span>
            <p>
              A capable open-weight model for conversation, reasoning, and your
              personal context. Runs on this machine.
            </p>
            <span className="micro">
              {state.localModel.available
                ? "LOCAL MODEL ONLINE"
                : state.localModel.installed ? "LOCAL MODEL SERVICE OFFLINE" : "MODEL DOWNLOAD REQUIRED"}
            </span>
            <div className="model-actions">
              <button
                className="primary-button"
                disabled={!state.localModel.available}
                onClick={async () => {
                  try {
                    await mutate("model", { mode: "local" });
                    setStatus("FREE LOCAL MODEL SELECTED");
                  } catch {
                    setStatus("LOCAL MODEL NOT READY");
                  }
                }}
              >
                USE FREE LOCAL MODEL
              </button>
              <button
                className="outline-button"
                onClick={async () => {
                  await mutate("model", { mode: "mock" });
                  setStatus("DEMO MODE SELECTED");
                }}
              >
                USE DEMO
              </button>
            </div>
          </div>
          <p>
            {state.localModel.available
              ? "Local context stays on this machine. CPU responses may take longer than a hosted model."
              : state.localModel.installed ? "Your model is installed. Start the local model service to connect it." : "The local model must be downloaded before it can answer questions. The download currently requires the saved environment network settings."}
          </p>
          <p>
            Other providers can still be configured in the server environment.
            API keys stay on the server.
          </p>
          <button
            className="outline-button"
            onClick={async () => {
              try {
                await mutate("provider-test", {});
                setStatus("PROVIDER CONNECTION VERIFIED");
              } catch {
                setStatus("PROVIDER CONNECTION FAILED");
              }
            }}
          >
            TEST CONNECTION
          </button>
        </div>
      </HUDPanel>
      <HUDPanel
        title="VOICE & MEMORY"
        subtitle="EDITH VOICE / LOCAL PERSISTENCE"
      >
        {toggle(
          "voiceOutput",
          "EDITH voice",
          "Speak responses aloud after you send a message",
        )}
        <label className="setting-field">
          Voice engine
          <select
            value={settings.voiceEngine}
            onChange={(e) => {
              speech.stop();
              setSettings({
                ...settings,
                voiceEngine: e.target.value as "kokoro" | "browser",
                voiceId: e.target.value === "kokoro" ? "af_sarah" : "auto",
              });
            }}
          >
            <option value="kokoro">EDITH neural voice · free and local</option>
            <option value="browser">
              Browser voice · available system voices
            </option>
          </select>
        </label>
        <label className="setting-field">
          Voice
          <select
            value={settings.voiceId}
            onChange={(e) =>
              setSettings({ ...settings, voiceId: e.target.value })
            }
          >
            {settings.voiceEngine === "kokoro" ? (
              LOCAL_VOICES.map((v) => (
                <option key={v.id} value={v.id}>
                  {v.name}
                </option>
              ))
            ) : (
              <>
                <option value="auto">
                  Automatic · prefer clear English female voice
                </option>
                {speech.voices.map((v) => (
                  <option key={v.voiceURI} value={v.voiceURI}>
                    {v.name} ({v.lang})
                  </option>
                ))}
              </>
            )}
          </select>
        </label>
        <label className="setting-field">
          Speaking speed · {settings.voiceRate.toFixed(2)}×
          <input
            aria-label="Speaking speed"
            type="range"
            min="0.75"
            max="1.25"
            step="0.01"
            value={settings.voiceRate}
            onChange={(e) =>
              setSettings({ ...settings, voiceRate: Number(e.target.value) })
            }
          />
        </label>
        {settings.voiceEngine === "browser" && (
          <label className="setting-field">
            Pitch · {settings.voicePitch.toFixed(2)}
            <input
              aria-label="Voice pitch"
              type="range"
              min="0.8"
              max="1.2"
              step="0.01"
              value={settings.voicePitch}
              onChange={(e) =>
                setSettings({ ...settings, voicePitch: Number(e.target.value) })
              }
            />
          </label>
        )}
        <div className="voice-preview-controls">
          <button
            className="outline-button"
            disabled={speech.status === "preparing"}
            onClick={() => void speech.speak(VOICE_PREVIEW_TEXT, settings)}
          >
            {speech.status === "preparing"
              ? "PREPARING VOICE…"
              : "PREVIEW EDITH VOICE"}
          </button>
          {speech.status !== "idle" && (
            <button className="outline-button" onClick={speech.stop}>
              STOP VOICE
            </button>
          )}
          <span className="micro">
            {settings.voiceEngine === "kokoro"
              ? state.voice.available
                ? "LOCAL VOICE ONLINE"
                : "LOCAL VOICE OFFLINE"
              : "VOICE AVAILABILITY DEPENDS ON YOUR BROWSER"}
          </span>
        </div>
        {toggle(
          "memoryEnabled",
          "Long-term memory",
          "Only explicit entries are stored permanently",
        )}
        <label className="setting-field">
          Maximum retrieval count
          <input
            type="number"
            min={1}
            max={10}
            value={settings.retrievalCount}
            onChange={(e) =>
              setSettings({
                ...settings,
                retrievalCount: Number(e.target.value),
              })
            }
          />
        </label>
      </HUDPanel>
      <HUDPanel title="PRIVACY" subtitle="LOCAL FIRST / NO ANALYTICS">
        <div className="provider-details">
          <p>
            Memory, notes, documents, and conversations are stored in local
            SQLite. There is no analytics collection. The EDITH neural voice is
            generated locally with no text sent to a voice API.
          </p>
          <p>
            When an external provider is configured, your prompts and recent
            conversation are sent to that endpoint. Retrieved memory and
            documents are shared only when ALLOW_EXTERNAL_CONTEXT=true.
          </p>
          <span className="status-label">
            EXTERNAL CONTEXT {state.externalContext ? "ENABLED" : "DISABLED"}
          </span>
          <p>
            Delete individual items in their workspace. This initial build is
            intended for a trusted local operator; it has no multiuser
            authentication.
          </p>
        </div>
      </HUDPanel>
      <div className="settings-save">
        <button className="primary-button" onClick={() => void save()}>
          SAVE CONFIGURATION
        </button>
        <span className="micro" role="status">
          {status}
        </span>
      </div>
    </div>
  );
}
