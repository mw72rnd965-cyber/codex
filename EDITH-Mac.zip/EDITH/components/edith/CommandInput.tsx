"use client";
import { useEffect, useRef, useState } from "react";
import { ArrowUp, Mic, Plus, Command, Square } from "lucide-react";
type RecognitionEvent = {
  results: { [index: number]: { [index: number]: { transcript: string } } };
};
type Recognition = {
  lang: string;
  interimResults: boolean;
  onresult: ((e: RecognitionEvent) => void) | null;
  onend: (() => void) | null;
  onerror: (() => void) | null;
  start: () => void;
  stop: () => void;
};
type VoiceWindow = Window & {
  SpeechRecognition?: new () => Recognition;
  webkitSpeechRecognition?: new () => Recognition;
};
export function CommandInput({
  send,
  busy,
  palette,
  upload,
  speechStatus,
  stopSpeech,
}: {
  send: (prompt: string) => Promise<void>;
  busy: boolean;
  palette: () => void;
  upload: () => void;
  speechStatus: "idle" | "preparing" | "speaking";
  stopSpeech: () => void;
}) {
  const [value, setValue] = useState("");
  const [voice, setVoice] = useState("IDLE");
  const [available, setAvailable] = useState(false);
  const recognition = useRef<Recognition | null>(null);
  useEffect(() => {
    const w = window as VoiceWindow;
    setAvailable(Boolean(w.SpeechRecognition || w.webkitSpeechRecognition));
    return () => recognition.current?.stop();
  }, []);
  const submit = () => {
    if (!value.trim() || busy) return;
    void send(value);
    setValue("");
  };
  const listen = () => {
    if (voice === "LISTENING") {
      recognition.current?.stop();
      return;
    }
    stopSpeech();
    const w = window as VoiceWindow;
    const Constructor = w.SpeechRecognition || w.webkitSpeechRecognition;
    if (!Constructor) return;
    const r = new Constructor();
    r.lang = "en-US";
    r.interimResults = false;
    r.onresult = (e) => {
      setValue(e.results[0][0].transcript);
      setVoice("TRANSCRIBED");
    };
    r.onend = () => setVoice((v) => (v === "LISTENING" ? "IDLE" : v));
    r.onerror = () => setVoice("ERROR");
    recognition.current = r;
    try {
      r.start();
      setVoice("LISTENING");
    } catch {
      setVoice("ERROR");
    }
  };
  return (
    <footer className="command-area">
      <div className="command-field">
        <button
          className="icon-button"
          aria-label="Add knowledge file"
          onClick={upload}
        >
          <Plus size={21} />
        </button>
        <div className="input-slot">
          {voice === "LISTENING" ? (
            <div className="voice-wave" role="status">
              {Array.from({ length: 22 }, (_, i) => (
                <i key={i} style={{ animationDelay: `${i * 0.06}s` }} />
              ))}
              <span>LISTENING…</span>
            </div>
          ) : (
            <input
              value={value}
              onChange={(e) => setValue(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") submit();
              }}
              disabled={busy}
              placeholder={
                busy
                  ? "EDITH IS PROCESSING…"
                  : "Ask EDITH anything, or type a command…"
              }
              aria-label="Ask EDITH"
            />
          )}
        </div>
        <button
          className={`icon-button ${voice === "LISTENING" ? "selected" : ""}`}
          aria-label={
            available
              ? "Toggle voice input"
              : "Voice input unsupported in this browser"
          }
          title={available ? "Voice input" : "Speech recognition unavailable"}
          disabled={!available || busy}
          onClick={listen}
        >
          {voice === "LISTENING" ? <Square size={17} /> : <Mic size={19} />}
        </button>
        {speechStatus !== "idle" && (
          <button
            className="icon-button selected"
            aria-label="Stop speech"
            onClick={stopSpeech}
          >
            <Square size={16} />
          </button>
        )}
        <span className="input-divider" />
        <button
          className="send-button"
          aria-label="Send message"
          disabled={!value.trim() || busy}
          onClick={submit}
        >
          <ArrowUp size={21} />
        </button>
      </div>
      <div className="command-meta">
        <span>
          <i className="dot" />{" "}
          {speechStatus === "speaking"
            ? "EDITH IS SPEAKING…"
            : speechStatus === "preparing"
              ? "PREPARING EDITH VOICE…"
              : voice === "ERROR"
                ? "VOICE UNAVAILABLE · CHECK MICROPHONE PERMISSION"
                : voice === "TRANSCRIBED"
                  ? "VOICE TRANSCRIBED · REVIEW AND SEND"
                  : "LOCAL INTELLIGENCE WORKSPACE"}
        </span>
        <button onClick={palette}>
          <Command size={12} /> K <span>COMMAND PALETTE</span>
        </button>
        <span>EDITH v0.1</span>
      </div>
    </footer>
  );
}
