import type { Conversation, Message } from "./types";
import { Plus, Trash2 } from "lucide-react";
export function ConversationFeed({
  messages,
  conversations,
  activeId,
  select,
  fresh,
  remove,
  busy,
  sources,
}: {
  messages: Message[];
  conversations: Conversation[];
  activeId?: string;
  select: (c: Conversation) => void;
  fresh: () => void;
  remove: (id: string) => void;
  busy: boolean;
  sources: string[];
}) {
  return (
    <div className="conversation-layout">
      <aside className="session-list">
        <button className="outline-button" disabled={busy} onClick={fresh}>
          <Plus size={14} /> NEW CONVERSATION
        </button>
        <span className="eyebrow">SAVED SESSIONS</span>
        {conversations.map((c) => (
          <div
            key={c.id}
            className={`session-row ${activeId === c.id ? "selected" : ""}`}
          >
            <button disabled={busy} onClick={() => select(c)}>
              {c.title}
              <small>{new Date(c.createdAt).toLocaleDateString()}</small>
            </button>
            <button
              className="icon-button"
              disabled={busy}
              aria-label={`Delete conversation ${c.title}`}
              onClick={() => {
                if (confirm("Delete this conversation and all its messages?"))
                  remove(c.id);
              }}
            >
              <Trash2 size={12} />
            </button>
          </div>
        ))}
      </aside>
      <div className="conversation-feed" aria-live="polite">
        {!messages.length && (
          <div className="conversation-empty">
            <span className="eyebrow">DIRECT LINK / ESTABLISHED</span>
            <h2>At your service.</h2>
            <p>
              Ask a question, retrieve context, or give your next thought a
              place to live.
            </p>
            <span className="micro">
              TRY “REMEMBER THAT I PREFER TYPESCRIPT”
            </span>
          </div>
        )}
        {messages.map((m) => (
          <article className={`feed-message ${m.role}`} key={m.id}>
            <div className="message-heading">
              <span className="dot" />
              <strong>{m.role === "user" ? "OPERATOR" : "EDITH"}</strong>
              <span>
                {"// "}
                {m.role === "user" ? "INPUT" : "RESPONSE"}
              </span>
              <time>{new Date(m.createdAt).toLocaleTimeString()}</time>
            </div>
            <p>{m.content}</p>
          </article>
        ))}
        {busy && (
          <div className="processing-label">
            ASSEMBLING RESPONSE <span className="blinking">▌</span>
          </div>
        )}
        {sources.length > 0 && (
          <div className="source-strip">
            <span className="eyebrow">SOURCES CONSULTED</span>
            {sources.map((s) => (
              <span key={s}>{s}</span>
            ))}
          </div>
        )}
        <div id="conversation-end" />
      </div>
    </div>
  );
}
