#!/bin/bash
set -euo pipefail
export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"
cd "$(dirname "$0")/.."
trap 'echo; echo "EDITH stopped. Close this window when finished."; read -r -p "Press Return..."' EXIT
fail() { echo "$1"; exit 1; }
command -v node >/dev/null || fail "Install Node.js 24 LTS from https://nodejs.org then open this launcher again."
node -e 'if(Number(process.versions.node.split(".")[0]) < 24) process.exit(1)' || fail "Install Node.js 24 or newer from https://nodejs.org."
command -v ollama >/dev/null || fail "Install and open Ollama from https://ollama.com/download/mac then open this launcher again."
export EDITH_PYTHON=""
for candidate in python3.13 python3.12 python3; do
  if command -v "$candidate" >/dev/null && "$candidate" -c 'import sys; assert (3,12) <= sys.version_info[:2] < (3,14)' 2>/dev/null; then
    EDITH_PYTHON="$(command -v "$candidate")"
    break
  fi
done
[ -n "$EDITH_PYTHON" ] || fail "Install Python 3.13 from python.org. Kokoro requires Python 3.12 or 3.13, not 3.14+."
export EDITH_RUNTIME_ROOT="$PWD/.edith-runtime"
if [ -f "$EDITH_RUNTIME_ROOT/tools/edith-voice/bin/python" ]; then
  if ! "$EDITH_RUNTIME_ROOT/tools/edith-voice/bin/python" -c 'import sys; assert (3,12) <= sys.version_info[:2] < (3,14)' 2>/dev/null; then
    mv "$EDITH_RUNTIME_ROOT/tools/edith-voice" "$EDITH_RUNTIME_ROOT/tools/edith-voice-backup-$(date +%s)"
  fi
fi
export EDITH_VOICE_MODEL_DIR="$EDITH_RUNTIME_ROOT/models/kokoro"
export AI_PROVIDER=local
export LOCAL_AI_MODEL=qwen3:8b
export LOCAL_AI_BASE_URL=http://127.0.0.1:11434/v1
mkdir -p "$EDITH_RUNTIME_ROOT/logs"
if curl -fsS http://127.0.0.1:3000/api/state >/dev/null 2>&1; then
  fail "An app already uses port 3000. Close its Terminal launcher before starting this copy."
fi
if ! curl -fsS http://127.0.0.1:11434/api/tags >/dev/null 2>&1; then
  open -a Ollama
  for i in {1..60}; do
    curl -fsS http://127.0.0.1:11434/api/tags >/dev/null 2>&1 && break
    sleep 1
  done
fi
curl -fsS http://127.0.0.1:11434/api/tags >/dev/null || fail "Ollama did not start. Open Ollama and try again."
echo "Preparing EDITH. First launch downloads dependencies, a ~5 GB model and the local voice."
ollama pull qwen3:8b
npm ci --cache "$EDITH_RUNTIME_ROOT/npm-cache" --no-audit --no-fund
[ -f .env ] || cp .env.example .env
npm run db:setup
npm run runtimes:setup
npm run build
VOICE_PID=""
APP_PID=""
cleanup() {
  [ -z "$APP_PID" ] || kill "$APP_PID" 2>/dev/null || true
  [ -z "$VOICE_PID" ] || kill "$VOICE_PID" 2>/dev/null || true
}
trap 'cleanup; echo "EDITH closed."' EXIT
trap 'exit 0' INT TERM
if curl -fsS http://127.0.0.1:8881/health >/dev/null 2>&1; then
  fail "Port 8881 is already in use. Close the other voice launcher first."
fi
"$EDITH_RUNTIME_ROOT/tools/edith-voice/bin/python" -m uvicorn services.voice.server:app --host 127.0.0.1 --port 8881 --no-access-log > "$EDITH_RUNTIME_ROOT/logs/voice.log" 2>&1 &
VOICE_PID=$!
node node_modules/next/dist/bin/next start --hostname 127.0.0.1 > "$EDITH_RUNTIME_ROOT/logs/app.log" 2>&1 &
APP_PID=$!
READY=0
for i in {1..60}; do
  if curl -fsS http://127.0.0.1:3000/api/state >/dev/null 2>&1 && curl -fsS http://127.0.0.1:8881/health >/dev/null 2>&1; then READY=1; break; fi
  kill -0 "$APP_PID" 2>/dev/null || break
  kill -0 "$VOICE_PID" 2>/dev/null || break
  sleep 1
done
[ "$READY" = 1 ] || fail "Startup failed. See .edith-runtime/logs/app.log and voice.log."
node --input-type=module <<'JS'
const base='http://127.0.0.1:3000';
const state=await (await fetch(base+'/api/state')).json();
for (const [kind,data] of [['model',{mode:'local'}],['settings',{...state.settings,voiceOutput:true,voiceEngine:'kokoro',voiceId:'af_sarah',voiceRate:0.94}]]) {
  const r=await fetch(base+'/api/data/'+kind,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(data)});
  if(!r.ok)throw new Error('Could not configure '+kind);
}
JS
open http://127.0.0.1:3000
echo "EDITH is ready. Keep this window open. Press Control-C to stop EDITH."
wait "$APP_PID"
