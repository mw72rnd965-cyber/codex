import { createHash } from "node:crypto";
import {
  createReadStream,
  existsSync,
  mkdirSync,
  readFileSync,
  writeFileSync,
  renameSync,
  statSync,
} from "node:fs";
import { execFileSync } from "node:child_process";
const dir = "/workspace/models/qwen3-8b";
mkdirSync(dir, { recursive: true });
const target = dir + "/model.gguf";
const manifestFile = dir + "/manifest.json";
let metadata;
if (existsSync(target) && existsSync(manifestFile))
  metadata = JSON.parse(readFileSync(manifestFile, "utf8"));
else {
  const repo = "Qwen/Qwen3-8B-GGUF";
  const infoFile = dir + "/model-info.json";
  try {
    execFileSync(
      "curl",
      [
        "--fail",
        "--location",
        "--silent",
        "--show-error",
        "--max-time",
        "30",
        `https://huggingface.co/api/models/${repo}?blobs=true`,
        "--output",
        infoFile,
      ],
      { stdio: "inherit" },
    );
  } catch {
    throw new Error(
      "Qwen download is blocked or unavailable. Review/save the Hugging Face network additions in environment settings, then rerun npm run ai:setup.",
    );
  }
  const info = JSON.parse(readFileSync(infoFile, "utf8"));
  const entry = info.siblings?.find(
    (f) => f.rfilename.toLowerCase() === "qwen3-8b-q4_k_m.gguf",
  );
  if (!entry?.lfs?.sha256 || !/^[a-f0-9]{40}$/.test(info.sha))
    throw new Error(
      "Authoritative model SHA/revision missing; refusing an unverified download.",
    );
  metadata = {
    repo,
    revision: info.sha,
    filename: entry.rfilename,
    sha256: entry.lfs.sha256,
    size: entry.lfs.size,
  };
  const partial = target + ".part";
  try{execFileSync(
    "curl",
    [
      "--fail",
      "--location",
      "--silent",
      "--show-error",
      "--retry",
      "2",
      "--max-time",
      "1800",
      "--continue-at",
      "-",
      `https://huggingface.co/${repo}/resolve/${metadata.revision}/${metadata.filename}?download=true`,
      "--output",
      partial,
    ],
    { stdio: "inherit" },
  );}catch{throw new Error("Model transfer blocked or interrupted. Allow huggingface.co and us.aws.cdn.hf.co in the running environment, then rerun npm run ai:setup. No model was installed.");}
  const hash = createHash("sha256");
  for await (const chunk of createReadStream(partial)) hash.update(chunk);
  if (hash.digest("hex") !== metadata.sha256)
    throw new Error("Model checksum mismatch; the model will not be used.");
  renameSync(partial, target);
  writeFileSync(manifestFile, JSON.stringify(metadata, null, 2));
}
const hash = createHash("sha256");
for await (const chunk of createReadStream(target)) hash.update(chunk);
if (
  hash.digest("hex") !== metadata.sha256 ||
  statSync(target).size !== metadata.size
)
  throw new Error("Stored model failed integrity validation.");
console.log(
  "Qwen3 8B Q4_K_M verified. Start npm run ai:serve, then select USE FREE LOCAL MODEL in Settings.",
);
