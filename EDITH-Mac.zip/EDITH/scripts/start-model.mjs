import { existsSync, createReadStream } from "node:fs";
import { createHash } from "node:crypto";
import { spawn } from "node:child_process";
const model = "/workspace/models/qwen3-8b/model.gguf";
if (!existsSync(model)) {
  console.error("Qwen3 8B is not downloaded. Run npm run ai:setup first.");
  process.exit(1);
}
const hash = createHash("sha256");
for await (const chunk of createReadStream(model)) hash.update(chunk);
if (hash.digest("hex") !== "d98cdcbd03e17ce47681435b5150e34c1417f50b5c0019dd560e4882c5745785") {
  console.error("Model checksum mismatch. Refusing to start unverified weights.");
  process.exit(1);
}
const child = spawn(
  "/workspace/tools/llama-b11429/llama-server",
  [
    "--model",
    model,
    "--alias",
    "qwen3-8b",
    "--host",
    "127.0.0.1",
    "--port",
    "11434",
    "--threads",
    "4",
    "--threads-batch",
    "4",
    "--parallel",
    "1",
    "--ctx-size",
    "8192",
    "--no-webui",
    "--no-webui-mcp-proxy",
    "--chat-template-kwargs",
    '{"enable_thinking":false}',
    "--reasoning-format",
    "none",
  ],
  { stdio: "inherit" },
);
for (const signal of ["SIGINT", "SIGTERM"])
  process.on(signal, () => child.kill(signal));
child.on("error", (error) => {
  console.error(error.message);
  process.exitCode = 1;
});
child.on("exit", (code) => {
  process.exitCode = code ?? 1;
});
