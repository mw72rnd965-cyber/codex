import "dotenv/config";
import { DatabaseSync } from "node:sqlite";
import { mkdirSync, readFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
const url = process.env.DATABASE_URL ?? "file:./prisma/edith.db";
if (!url.startsWith("file:"))
  throw new Error("This setup script initializes local SQLite only.");
const path = resolve(url.slice(5));
mkdirSync(dirname(path), { recursive: true });
const database = new DatabaseSync(path);
database.exec("PRAGMA foreign_keys = ON;");
const initialVersion = database
  .prepare("PRAGMA user_version")
  .get().user_version;
const migrations = ["0001_initial", "0002_voice", "0003_auto_voice", "0004_abilities", "0005_folder"];
if (initialVersion > migrations.length)
  throw new Error(
    "Database is newer than this application; do not downgrade it.",
  );
for (let version = initialVersion; version < migrations.length; version++) {
  database.exec("BEGIN;");
  try {
    database.exec(
      readFileSync(
        new URL(
          `../prisma/migrations/${migrations[version]}/migration.sql`,
          import.meta.url,
        ),
        "utf8",
      ),
    );
    database.exec(`PRAGMA user_version = ${version + 1}; COMMIT;`);
  } catch (error) {
    database.exec("ROLLBACK;");
    throw error;
  }
}
database.close();
console.log(`SQLite ready (schema v${migrations.length}): ${path}`);
