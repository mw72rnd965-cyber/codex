import "dotenv/config";
import { createRequire } from "node:module";
const require = createRequire(import.meta.url);
import internals from "@prisma/internals";
// The public CLI eagerly downloads a Rust schema engine even for JS-only clients.
// Use the pinned Prisma generator API; WASM schema parsing and libSQL require no Rust binary.
const generators = await internals.getGenerators({
  schemaPath: "prisma/schema.prisma",
  skipDownload: true,
  registry: {
    "prisma-client-js": {
      type: "rpc",
      generatorPath: require.resolve("@prisma/client/generator-build/index.js"),
      isNode: true,
    },
  },
});
try {
  for (const generator of generators) await generator.generate();
} finally {
  for (const generator of generators) generator.stop();
}
console.log("Engine-free Prisma client generated.");
