import test from "node:test";
import assert from "node:assert/strict";
import { retrieve, score, chunkText } from "../lib/retrieval";
import {
  chatInput,
  memoryInput,
  taskInput,
  safeFilename,
} from "../lib/validation";
import { MockProvider } from "../lib/ai/provider";
test("retrieval filters irrelevant records and ranks matching importance", () => {
  const rows = [
    { title: "Unrelated", content: "A recipe for soup", importance: 1 },
    { title: "Typescript", content: "TypeScript project", importance: 0.2 },
    { title: "Preference", content: "TypeScript project", importance: 1 },
  ];
  assert.equal(score("rust", "TypeScript"), 0);
  assert.deepEqual(
    retrieve("TypeScript project", rows, 1).map((x) => x.title),
    ["Preference"],
  );
  assert.equal(retrieve("unmatched", rows).length, 0);
});
test("chunking covers all document content and rejects unsafe sizes", () => {
  const text = "a".repeat(2501);
  const chunks = chunkText(text);
  assert.equal(chunks.length, 3);
  assert.equal(chunks.join(""), text);
  assert.deepEqual(chunkText("   "), []);
  assert.throws(() => chunkText(text, 0));
});
test("validation rejects empty input, oversized messages, invalid status, and unsafe importance", () => {
  assert.equal(chatInput.safeParse({ prompt: "   " }).success, false);
  assert.equal(
    chatInput.safeParse({ prompt: "a".repeat(8001) }).success,
    false,
  );
  assert.equal(
    taskInput.safeParse({ title: "Task", status: "UNSAFE" }).success,
    false,
  );
  assert.equal(
    memoryInput.safeParse({ title: "Preference", content: "TS", importance: 2 })
      .success,
    false,
  );
  assert.equal(taskInput.parse({ title: "Task" }).status, "PENDING");
  assert.equal(safeFilename("../../notes.md"), ".._.._notes.md");
});
test("demo stream reconstructs generated response and cites retrieved source", async () => {
  const provider = new MockProvider();
  const context = {
    memories: [],
    knowledge: ["The project uses TypeScript."],
    tasks: [],
    sources: ["project.md"],
  };
  const messages = [{ role: "user" as const, content: "What language?" }];
  const expected = await provider.generate(messages, context);
  let actual = "";
  for await (const token of provider.stream(messages, context)) actual += token;
  assert.equal(actual, expected);
  assert.match(actual, /project.md/);
  assert.match(actual, /TypeScript/);
});
test("compatible provider handles streamed tokens split across transport chunks", async () => {
  const { createServer } = await import("node:http");
  const { OpenAICompatibleProvider } = await import("../lib/ai/provider");
  let received: unknown;
  const server = createServer((req, res) => {
    let body = "";
    req.on("data", (chunk) => (body += chunk));
    req.on("end", () => {
      received = JSON.parse(body);
      res.writeHead(200, { "Content-Type": "text/event-stream" });
      res.write('data: {"choices":[{"delta":{"con');
      setTimeout(() => {
        res.end('tent":"Online"}}]}\n\ndata: [DONE]\n\n');
      }, 10);
    });
  });
  await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
  const address = server.address();
  assert.ok(address && typeof address !== "string");
  const previous = process.env.AI_BASE_URL;
  process.env.AI_BASE_URL = `http://127.0.0.1:${address.port}`;
  try {
    let text = "";
    for await (const token of new OpenAICompatibleProvider().stream(
      [{ role: "user", content: "Hello" }],
      { memories: [], knowledge: [], tasks: [], sources: [] },
    ))
      text += token;
    assert.equal(text, "Online");
    assert.equal((received as { stream: boolean }).stream, true);
  } finally {
    if (previous === undefined) delete process.env.AI_BASE_URL;
    else process.env.AI_BASE_URL = previous;
    await new Promise<void>((resolve) => server.close(() => resolve()));
  }
});

test("voice text removes markup and code without reading URLs aloud", async () => {
  const { speechText } = await import("../lib/voice/text");
  assert.equal(
    speechText("## Hello **operator**. [Read this](https://example.com)."),
    "Hello operator. Read this.",
  );
  assert.match(
    speechText("Example: ```js\nconsole.log(1)\n```"),
    /Code example omitted/,
  );
  assert.equal(speechText("a".repeat(5000)).length, 4000);
});
test("automatic browser voice prefers an English female voice and respects explicit selection", async () => {
  const { chooseBrowserVoice } = await import("../lib/voice/browser");
  const voices = [
    { name: "Daniel", lang: "en-GB", voiceURI: "daniel", localService: true },
    {
      name: "Samantha",
      lang: "en-US",
      voiceURI: "samantha",
      localService: true,
    },
    { name: "French", lang: "fr-FR", voiceURI: "french", localService: true },
  ];
  assert.equal(chooseBrowserVoice(voices)?.voiceURI, "samantha");
  assert.equal(chooseBrowserVoice(voices, "daniel")?.voiceURI, "daniel");
  assert.equal(chooseBrowserVoice([]), undefined);
});
test("local provider rejects an external endpoint and never sends an API key", async () => {
  const { OpenAICompatibleProvider } = await import("../lib/ai/provider");
  const provider = new OpenAICompatibleProvider({
    provider: "local",
    model: "qwen3-8b",
    baseUrl: "https://external.example/v1",
    apiKey: "should-not-leave-server",
  });
  await assert.rejects(
    provider.generate([{ role: "user", content: "Hello" }], {
      memories: [],
      knowledge: [],
      tasks: [],
      sources: [],
    }),
    /loopback/,
  );
});

test("speech chunking starts with the first sentence and preserves later text", async()=>{
 const {takeSpeechChunk}=await import('../lib/voice/text');
 assert.deepEqual(takeSpeechChunk('I am ready. More text follows'),['I am ready.',' More text follows']);
 assert.deepEqual(takeSpeechChunk('A partial phrase'),['','A partial phrase']);
 assert.deepEqual(takeSpeechChunk('A partial phrase',true),['A partial phrase','']);
 assert.deepEqual(takeSpeechChunk('```const x=1;'),['','```const x=1;']);
 assert.deepEqual(takeSpeechChunk('```const x=1;``` Done.'),['Code example omitted from speech.',' Done.']);
});

test("Ollama transport disables thinking, keeps the model warm, and streams content", async()=>{
 const {OpenAICompatibleProvider}=await import('../lib/ai/provider');
 const previous=process.env.LOCAL_AI_TRANSPORT;
 const original=globalThis.fetch;
 process.env.LOCAL_AI_TRANSPORT='ollama';
 try {
  globalThis.fetch=async(input,init)=>{
   assert.equal(String(input),'http://127.0.0.1:11434/api/chat');
   const body=JSON.parse(String(init?.body));
   assert.equal(body.think,false);assert.equal(body.keep_alive,'30m');
   assert.match(body.messages[0].content,/Speak directly to the person/);
   assert.match(body.messages[0].content,/Keep internal analysis private/);
   assert.equal(body.options.num_ctx,4096);
   return new Response('{"message":{"content":"Fast "}}\n{"message":{"content":"reply."},"done":true}\n');
  };
  const provider=new OpenAICompatibleProvider({provider:'local',model:'qwen3:4b',baseUrl:'http://127.0.0.1:11434/v1'});
  let text='';for await(const part of provider.stream([{role:'user',content:'Hi'}],{memories:[],knowledge:[],tasks:[],sources:[]}))text+=part;
  assert.equal(text,'Fast reply.');
 } finally {
  globalThis.fetch=original;
  if(previous===undefined)delete process.env.LOCAL_AI_TRANSPORT;else process.env.LOCAL_AI_TRANSPORT=previous;
 }
});
