import { db } from "../db";
import { retrieve } from "../retrieval";
import { memoryInput } from "../validation";
export const MemoryService = {
  createMemory(input: unknown) {
    return db.memory.create({ data: memoryInput.parse(input) });
  },
  updateMemory(id: string, input: unknown) {
    return db.memory.update({ where: { id }, data: memoryInput.parse(input) });
  },
  deleteMemory(id: string) {
    return db.memory.delete({ where: { id } });
  },
  async searchMemory(query: string, limit = 5) {
    return retrieve(query, await db.memory.findMany(), limit);
  },
  async getRelevantMemories(query: string, limit = 5) {
    const matches = await this.searchMemory(query, limit);
    if (matches.length)
      await db.memory.updateMany({
        where: { id: { in: matches.map((m) => m.id) } },
        data: { lastAccessedAt: new Date() },
      });
    return matches;
  },
  getRecentMemories(limit = 10) {
    return db.memory.findMany({ orderBy: { createdAt: "desc" }, take: limit });
  },
  async getMemoryGraph() {
    return (await db.memory.findMany()).map((m) => ({
      id: m.id,
      type: "MEMORY",
      label: m.title,
      strength: m.importance,
      createdAt: m.createdAt,
      connections: ["EDITH"],
    }));
  },
};
