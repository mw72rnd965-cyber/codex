import { PrismaClient } from "@/generated/prisma";
import { PrismaLibSQL } from "@prisma/adapter-libsql";
const globalDb = globalThis as unknown as { prisma?: PrismaClient };
const adapter = new PrismaLibSQL({
  url: process.env.DATABASE_URL ?? "file:./prisma/edith.db",
});
export const db = globalDb.prisma ?? new PrismaClient({ adapter });
if (process.env.NODE_ENV !== "production") globalDb.prisma = db;
