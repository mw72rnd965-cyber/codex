export function checkOrigin(request: Request) {
  const value = request.headers.get("origin");
  if (!value) return;
  const origin = new URL(value);
  const host = request.headers.get("host") ?? new URL(request.url).host;
  if (!["http:", "https:"].includes(origin.protocol) || origin.host !== host)
    throw new Error("Cross-origin mutation rejected");
}
export function apiError(error: unknown) {
  console.error(error instanceof Error ? error.message : "Request failed");
  return Response.json(
    { error: "Request rejected. Check input and try again." },
    { status: 400 },
  );
}
