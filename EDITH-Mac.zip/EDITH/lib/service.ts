import { db } from "./db";
import { chunkText, retrieve } from "./retrieval";
import { MemoryService } from "./memory/service";
import { safeFilename } from "./validation";
export async function event(label: string) {
  await db.activityEvent.create({ data: { label } });
}
export async function initialize() {
  await db.userSettings.upsert({
    where: { id: "local" },
    update: {},
    create: { id: "local" },
  });
}
export async function addKnowledge(name: string, content: string) {
  const safeName = safeFilename(name);
  if (!/\.(txt|md|json)$/i.test(safeName))
    throw new Error("Use .txt, .md, or .json files");
  if (!content.trim()) throw new Error("File is empty");
  if (Buffer.byteLength(content, "utf8") > 1_000_000)
    throw new Error("File exceeds 1 MB");
  if (safeName.endsWith(".json")) JSON.parse(content);
  return db.knowledgeFile.create({
    data: {
      name: safeName,
      content,
      chunks: {
        create: chunkText(content).map((content, position) => ({
          content,
          position,
        })),
      },
    },
  });
}
export async function getContext(prompt: string) {
  const settings = await db.userSettings.findUnique({ where: { id: "local" } });
  const memories = settings?.memoryEnabled
    ? await MemoryService.getRelevantMemories(prompt, settings.retrievalCount)
    : [];
  const chunks = retrieve(
    prompt,
    await db.knowledgeChunk.findMany({
      include: { file: { select: { name: true } } },
    }),
    settings?.retrievalCount ?? 5,
  );
  const tasks = /task|unfinished|working|due/i.test(prompt)
    ? await db.task.findMany({
        where: { status: { in: ["PENDING", "ACTIVE"] } },
        take: 10,
      })
    : [];
  return {
    memories: memories.map((m) => `${m.title}: ${m.content}`),
    knowledge: chunks.map((c) => c.content),
    tasks: tasks.map(
      (t) =>
        `${t.title} — ${t.status}${t.dueDate ? ` (due ${t.dueDate.toISOString().slice(0, 10)})` : ""}`,
    ),
    sources: [...new Set(chunks.map((c) => c.file.name))],
  };
}
