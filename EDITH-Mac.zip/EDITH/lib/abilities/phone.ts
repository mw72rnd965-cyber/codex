import {db} from '@/lib/db';
export function phoneConfigured(){return !!(process.env.TWILIO_ACCOUNT_SID&&process.env.TWILIO_AUTH_TOKEN&&process.env.TWILIO_FROM_NUMBER);}
export async function phoneSettings(){const row=await db.systemSetting.findUnique({where:{key:'phone.notifications'}});return row?JSON.parse(row.value) as {number:string;enabled:boolean}:{number:'',enabled:false};}
export async function makeNotificationCall(message:string){
 const settings=await phoneSettings();
 if(!settings.enabled || !settings.number)throw new Error('Phone notifications are disabled.');
 if(!phoneConfigured())throw new Error('Add Twilio credentials to .env and restart EDITH.');
 const escape=(s:string)=>s.replace(/[<>&"']/g,c=>({'<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;',"'":'&apos;'}[c]!));
 const sid=process.env.TWILIO_ACCOUNT_SID!;
 if(!/^AC[a-f0-9]{32}$/i.test(sid))throw new Error('Invalid Twilio account SID.');
 const body=new URLSearchParams({To:settings.number,From:process.env.TWILIO_FROM_NUMBER!,Twiml:`<Response><Say>${escape(message.slice(0,500))}</Say></Response>`});
 const response=await fetch(`https://api.twilio.com/2010-04-01/Accounts/${sid}/Calls.json`,{method:'POST',headers:{Authorization:'Basic '+Buffer.from(sid+':'+process.env.TWILIO_AUTH_TOKEN).toString('base64'),'Content-Type':'application/x-www-form-urlencoded'},body,signal:AbortSignal.timeout(20000)});
 if(!response.ok)throw new Error('Calling provider rejected the call. Check your Twilio account and verified number.');
 const result=await response.json();return {sid:result.sid,status:result.status};
}
