import {commandText} from './chat-intent';
import {db} from '@/lib/db';
import {createTimer} from './timers';
import {parseTimer,phoneInput} from './inputs';
import {chooseFolder,scanFolder,folderStatus} from './folder';
import {phoneConfigured,phoneSettings,makeNotificationCall} from './phone';
import {analyzeFiles} from './analysis';
export async function chatAbility(prompt:string):Promise<string|null>{
 const p=commandText(prompt);
 try{
  const task=p.match(/^(?:create|add|make)\s+(?:a\s+)?task(?:\s+to)?\s+(.+)$/i);
  if(task){
   const title=task[1].trim();if(title.length>200)return 'Use a task title under 200 characters.';
   await db.task.create({data:{title}});return `Task created: ${title}.`;
  }
  const timerCommand=p.replace(/\s+(?:and\s+)?call me (?:when (?:it|the timer) (?:finishes|ends)|afterwards)[.!]?$/i,'');
  const timer=parseTimer(timerCommand);
  if(timer){timer.notifyPhone=timerCommand!==p;await createTimer(timer);return `Timer set for ${timer.seconds} seconds${timer.label!=='Timer'?`: ${timer.label}`:''}.${timer.notifyPhone?' I will call your saved number when it finishes.':''}`;}
  if(/^(?:show|list|what are)\s+(?:my\s+)?timers[?!.]*$/i.test(p)){
   const timers=await db.timer.findMany({where:{status:{in:['WAITING','RINGING']}},orderBy:{dueAt:'asc'}});
   return timers.length?timers.map(t=>`${t.label}: ${t.status==='RINGING'?'finished':`${Math.max(0,Math.ceil((t.dueAt.getTime()-Date.now())/1000))} seconds remaining`}.`).join('\n'):'You have no active timers.';
  }
  const cancel=p.match(/^(?:cancel|stop|dismiss)\s+(?:the\s+)?(?:timer\s+(?:called|named)\s+(.+)|(.+?)\s+timer|timer)[.!]?$/i);
  if(cancel){
   const name=(cancel[1]??cancel[2])?.replace(/[.!]$/,'');
   const timers=await db.timer.findMany({where:{status:{in:['WAITING','RINGING']}},orderBy:{dueAt:'desc'}});
   const matches=name?timers.filter(t=>t.label.toLowerCase()===name.toLowerCase()):timers;
   if(!matches.length)return 'I could not find that timer.';
   if(matches.length>1)return 'There is more than one matching timer. Use its name, for example “cancel the pasta timer”.';
   await db.timer.update({where:{id:matches[0].id},data:{status:'DISMISSED'}});return `${matches[0].label} timer cancelled.`;
  }
  if(/^(?:choose|select|link|connect)\s+(?:a|my|the)?\s*(?:documents?\s+)?folder[.!]*$/i.test(p)){
   const folder=await chooseFolder();return folder?`Linked ${folder.path}. I will refresh its documents while EDITH is running.`:'No folder was selected.';
  }
  if(/^(?:refresh|rescan|sync)\s+(?:my|the)?\s*(?:folder|documents|files)[.!]*$/i.test(p)){
   if(!await folderStatus())return 'No folder is linked yet. Say “choose a folder”.';
   await scanFolder();const f=await folderStatus();return f?.error??`Folder refreshed. ${f?.imported??0} files updated.`;
  }
  if(/^(?:disconnect|unlink)\s+(?:my|the)?\s*(?:documents?\s+)?folder[.!]*$/i.test(p)){
   await db.systemSetting.deleteMany({where:{key:{in:['documents.folder','documents.folder.manifest']}}});return 'Folder disconnected. Previously imported documents remain in Knowledge.';
  }
  const number=p.match(/^(?:my phone number is|(?:save|add|set)\s+(?:my\s+)?phone number(?:\s+to|\s+as|\s+is)?)\s+(\+?[\d ()-]+)[.!]?$/i);
  if(number){
   const saved=phoneInput.parse({number:number[1].replace(/[ ()-]/g,''),enabled:false});
   await db.systemSetting.upsert({where:{key:'phone.notifications'},create:{key:'phone.notifications',value:JSON.stringify(saved)},update:{value:JSON.stringify(saved)}});
   return 'Phone number saved. Calls are disabled until you configure a calling provider and enable notifications.';
  }
  if(/^(?:enable|disable)\s+(?:phone|call) notifications[.!]*$/i.test(p)){
   const enabled=/^enable/i.test(p);const settings=await phoneSettings();
   if(enabled&&!phoneConfigured())return 'A calling provider is not configured yet. Your number can be saved, but I cannot place calls.';
   const saved=phoneInput.parse({...settings,enabled});
   await db.systemSetting.upsert({where:{key:'phone.notifications'},create:{key:'phone.notifications',value:JSON.stringify(saved)},update:{value:JSON.stringify(saved)}});
   return `Phone notifications ${enabled?'enabled':'disabled'}.`;
  }
  if(/^call me (?:now|for a test|to test notifications)[.!]*$/i.test(p)){
   await makeNotificationCall('Hello. This is EDITH. This is your requested notification call.');return 'Your notification call has been queued.';
  }
  const files=await db.knowledgeFile.findMany({select:{id:true,name:true},orderBy:{createdAt:'desc'}});
  const named=files.filter(f=>p.toLowerCase().includes(f.name.toLowerCase()));
  const references=!!named.length||/\b(files?|documents?|images?|photos?|pictures?|pdfs?|uploads?)\b/i.test(p);
  const analysis=/^(?:analy[sz]e|summari[sz]e|review|compare|describe|extract|create tasks|make tasks|add tasks)/i.test(p);
  if(analysis&&references){
   const selected=named.length?named:files;
   if(!selected.length)return 'No files are imported yet. Say “upload files”, then tell me what to analyze.';
   if(selected.length>8)return 'I can analyze up to eight files at a time. Include their filenames in your message to choose which ones.';
   const createTasks=/\b(?:create|make|add|extract)\s+(?:the\s+)?tasks\b/i.test(p);
   const result=await analyzeFiles({fileIds:selected.map(f=>f.id),instruction:p,createTasks});
   return result.answer+`\n\nSaved in Notes.${createTasks?` Created ${result.tasks.length} tasks.`:''}`;
  }
  if(/^(?:list|show)\s+(?:my\s+)?(?:files|documents|images)[.!?]*$/i.test(p))return files.length?files.map(f=>f.name).join('\n'):'No files are imported yet. Say “upload files”.';
  return null;
 }catch(error){return error instanceof Error?error.message:'That action could not be completed.';}
}
