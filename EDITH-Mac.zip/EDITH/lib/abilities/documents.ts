import sharp from "sharp";
import mammoth from "mammoth";
import { db } from "@/lib/db";
import { chunkText } from "@/lib/retrieval";
import { safeFilename } from "@/lib/validation";
export async function importFile(file:File, sourcePath?:string) {
 if(file.size>10_000_000 || !file.size) throw new Error("Use nonempty files under 10 MB.");
 const name=safeFilename(file.name);
 const bytes=Buffer.from(await file.arrayBuffer());
 let content="",mimeType="text/plain",imageData:string|null=null;
 if(/\.(png|jpe?g|webp)$/i.test(name)) {
  const image=sharp(bytes,{limitInputPixels:25_000_000});
  const metadata=await image.metadata();
  if(!['png','jpeg','webp'].includes(metadata.format ?? ''))throw new Error("Unsupported image.");
  imageData=(await image.rotate().resize(1024,1024,{fit:'inside',withoutEnlargement:true}).png().toBuffer()).toString('base64');
  mimeType="image/png";content=`Image: ${name}. Uploaded for visual analysis; not yet analyzed.`;
 } else if(/\.pdf$/i.test(name)) {
  const {PDFParse}=await import('pdf-parse');
  const parser=new PDFParse({data:new Uint8Array(bytes)});
  try {content=(await parser.getText({first:100})).text;}finally{await parser.destroy();}
  mimeType="application/pdf";
 } else if(/\.docx$/i.test(name)) {
  content=(await mammoth.extractRawText({buffer:bytes})).value;
  mimeType="application/vnd.openxmlformats-officedocument.wordprocessingml.document";
 } else if(/\.(txt|md|json|csv)$/i.test(name)) {
  content=bytes.toString('utf8');
  if(/\.json$/i.test(name))JSON.parse(content);
 } else throw new Error("Choose TXT, MD, JSON, CSV, PDF, DOCX, PNG, JPG or WebP.");
 if(!content.trim())throw new Error("No readable text found. Scanned PDFs need OCR; upload pages as images.");
 if(Buffer.byteLength(content,'utf8')>1_000_000)throw new Error("Extracted text exceeds 1 MB.");
 if(sourcePath){
  const existing=await db.knowledgeFile.findUnique({where:{sourcePath}});
  if(existing)return db.$transaction(async tx=>{
   await tx.knowledgeChunk.deleteMany({where:{fileId:existing.id}});
   return tx.knowledgeFile.update({where:{id:existing.id},data:{name,content,mimeType,imageData,chunks:{create:chunkText(content).map((content,position)=>({content,position}))}},select:{id:true,name:true,mimeType:true}});
  });
 }
 return db.knowledgeFile.create({data:{sourcePath,name,content,mimeType,imageData,chunks:{create:chunkText(content).map((content,position)=>({content,position}))}},select:{id:true,name:true,mimeType:true}});
}
