import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {readdir,readFile,realpath,stat} from 'node:fs/promises';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
import {db} from '@/lib/db';
import {importFile} from './documents';
const exec=promisify(execFile);
let scanning=false;
export async function folderStatus(){const row=await db.systemSetting.findUnique({where:{key:'documents.folder'}});return row?JSON.parse(row.value) as {path:string;lastScan?:string;imported?:number;skipped?:number;error?:string}:null;}
export async function chooseFolder(){
 if(process.platform!=='darwin')throw new Error('The native folder chooser is available in the Mac app. Use multi-file import here.');
 const result=await exec('/usr/bin/osascript',['-e','POSIX path of (choose folder with prompt "Choose the folder EDITH may keep reading")'],{timeout:120000,maxBuffer:4096});
 const path=await realpath(result.stdout.trim());
 if(!(await stat(path)).isDirectory())throw new Error('Choose a folder.');
 await db.systemSetting.upsert({where:{key:'documents.folder'},create:{key:'documents.folder',value:JSON.stringify({path})},update:{value:JSON.stringify({path})}});
 await scanFolder();
 return folderStatus();
}
export async function scanFolder(){
 if(scanning)return;
 scanning=true;
 try {
  const folder=await folderStatus();if(!folder)return;
  const manifestRow=await db.systemSetting.findUnique({where:{key:'documents.folder.manifest'}});
  const manifest:Record<string,string>=manifestRow?JSON.parse(manifestRow.value):{};
  let imported=0,skipped=0,visited=0,total=0;
  const walk=async(path:string):Promise<void>=>{
   for(const entry of await readdir(path,{withFileTypes:true})){
    if(++visited>5000||imported>=200)return;
    if(entry.name.startsWith('.')||['node_modules','Library','Applications'].includes(entry.name))continue;
    const filePath=join(path,entry.name);
    if(entry.isDirectory()){await walk(filePath);continue;}
    if(!entry.isFile()||! /\.(txt|md|json|csv|pdf|docx|png|jpe?g|webp)$/i.test(entry.name))continue;
    const info=await stat(filePath);
    if(!info.size||info.size>10_000_000||total+info.size>200_000_000){skipped++;continue;}
    total+=info.size;
    const fingerprint=`${info.size}:${info.mtimeMs}`;
    const key=createHash('sha256').update(filePath).digest('hex');
    const exists=await db.knowledgeFile.findUnique({where:{sourcePath:filePath},select:{id:true}});
    if(exists && manifest[key]===fingerprint)continue;
    try{const bytes=await readFile(filePath);await importFile(new File([new Uint8Array(bytes)],entry.name),filePath);manifest[key]=fingerprint;imported++;}
    catch{skipped++;}
   }
  };
  try{await walk(folder.path);folder.error=undefined;}
  catch{folder.error='Folder unavailable. Check macOS folder permission or reconnect the folder.';}
  await db.systemSetting.upsert({where:{key:'documents.folder.manifest'},create:{key:'documents.folder.manifest',value:JSON.stringify(manifest)},update:{value:JSON.stringify(manifest)}});
  await db.systemSetting.update({where:{key:'documents.folder'},data:{value:JSON.stringify({...folder,lastScan:new Date().toISOString(),imported,skipped})}});
 }finally{scanning=false;}
}
const worker=globalThis as unknown as {edithFolderWorker?:ReturnType<typeof setInterval>};
export function ensureFolderWorker(){if(worker.edithFolderWorker)return;worker.edithFolderWorker=setInterval(()=>{void scanFolder().catch(()=>{});},30000);worker.edithFolderWorker.unref();}
