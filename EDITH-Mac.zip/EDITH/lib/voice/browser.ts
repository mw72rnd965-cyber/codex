export type VoiceMetadata = {
  name: string;
  lang: string;
  voiceURI: string;
  localService: boolean;
};
export function chooseBrowserVoice<T extends VoiceMetadata>(
  voices: T[],
  voiceId = "auto",
): T | undefined {
  const selected = voices.find((v) => v.voiceURI === voiceId);
  if (selected) return selected;
  const candidates = voices.filter((v) => /^en(?:-|_)/i.test(v.lang));
  const score = (v: T) => {
    const female =
      /samantha|ava|aria|jenny|zira|joanna|sonia|susan|victoria|female/i.test(
        v.name,
      );
    return (
      (/^en-US$/i.test(v.lang) ? 40 : 15) +
      (female ? 35 : 0) +
      (/natural|enhanced|premium/i.test(v.name) ? 20 : 0) +
      (v.localService ? 5 : 0)
    );
  };
  return [...candidates].sort((a, b) => score(b) - score(a))[0] ?? voices[0];
}
