export const VOICE_PREVIEW_TEXT =
  "I'm EDITH. Your personal intelligence system is online. Tell me what you need, and I'll take it from here.";
export const LOCAL_VOICES = [
  { id: "af_sarah", name: "EDITH · calm American female" },
  { id: "af_bella", name: "Bella · smooth American female" },
  { id: "af_heart", name: "Heart · warm American female" },
  { id: "bf_emma", name: "Emma · measured British female" },
];
export function speechText(text: string): string {
  return text
    .replace(/```[\s\S]*?```/g, " Code example omitted from speech. ")
    .replace(/!\[[^\]]*\]\([^)]*\)/g, "")
    .replace(/\[([^\]]+)\]\([^)]*\)/g, "$1")
    .replace(/(?:https?:\/\/|www\.)\S+/g, "")
    .replace(/[*_`#>|]+/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 4000);
}
