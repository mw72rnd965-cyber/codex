export function greetingReply(prompt: string, name = "Emiliano"): string | null {
  if (!/^(?:hello|hi|hey)(?:\s+edith)?[!.\s]*$/i.test(prompt.trim())) return null;
  const displayName = name.trim() && name !== "Operator" ? name.trim() : "Emiliano";
  return `Hello ${displayName}.`;
}

// Some compatible servers put reasoning tags inside content instead of a separate field.
// Keep partial tags buffered so neither displayed text nor speech sees them.
export async function* answerTokens(tokens: AsyncIterable<string>): AsyncGenerator<string> {
  let pending = "";
  let thinking = false;
  const open = "<think>";
  const close = "</think>";
  for await (const token of tokens) {
    pending += token;
    while (pending) {
      const marker = thinking ? close : open;
      const index = pending.indexOf(marker);
      if (index >= 0) {
        if (!thinking && index) yield pending.slice(0, index);
        pending = pending.slice(index + marker.length);
        thinking = !thinking;
        continue;
      }
      let hold = 0;
      for (let n = 1; n < marker.length; n++)
        if (pending.endsWith(marker.slice(0, n))) hold = n;
      const ready = pending.slice(0, pending.length - hold);
      if (!thinking && ready) yield ready;
      pending = pending.slice(pending.length - hold);
      break;
    }
  }
  if (!thinking && pending && !open.startsWith(pending)) yield pending;
}
