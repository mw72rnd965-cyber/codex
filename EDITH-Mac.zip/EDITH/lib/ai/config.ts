import {existsSync} from "node:fs";
import { db } from "@/lib/db";
import { providerConfigured, type ProviderConfig } from "./provider";
export const LOCAL_MODEL = process.env.LOCAL_AI_MODEL ?? "qwen3-8b";
export const LOCAL_MODEL_NAME = `${LOCAL_MODEL === "qwen2.5:3b" ? "Qwen2.5 3B" : LOCAL_MODEL === "qwen3:4b" ? "Qwen3 4B" : "Qwen3 8B"} · free local model`;
export function localBaseUrl() {
  const value = process.env.LOCAL_AI_BASE_URL ?? "http://127.0.0.1:11434/v1";
  const url = new URL(value);
  if (
    !["127.0.0.1", "localhost", "[::1]"].includes(url.hostname) ||
    !["http:", "https:"].includes(url.protocol)
  )
    throw new Error("Local models must use a loopback endpoint");
  return value;
}
export async function getModelConfiguration(): Promise<ProviderConfig> {
  const saved = await db.systemSetting.findUnique({
    where: { key: "ai.mode" },
  });
  const mode = saved?.value ?? process.env.AI_PROVIDER ?? "mock";
  if (mode === "local")
    return { provider: "local", baseUrl: localBaseUrl(), model: LOCAL_MODEL };
  if (mode === "mock") return { provider: "mock", model: "EDITH Demo" };
  return {
    provider: "openai-compatible",
    baseUrl: process.env.AI_BASE_URL,
    model: process.env.AI_MODEL,
    apiKey: process.env.AI_API_KEY,
  };
}
export async function localModelStatus() {
  const installed=existsSync("/workspace/models/qwen3-8b/model.gguf")&&existsSync("/workspace/models/qwen3-8b/manifest.json");
  try {
    const response = await fetch(
      localBaseUrl().replace(/\/$/, "") + "/models",
      { signal: AbortSignal.timeout(1200), cache: "no-store" },
    );
    return { available: response.ok, name: LOCAL_MODEL_NAME, local: true, installed };
  } catch {
    return { available: false, name: LOCAL_MODEL_NAME, local: true, installed };
  }
}
export async function setModelMode(mode: "local" | "mock") {
  if (mode === "local" && !(await localModelStatus()).available)
    throw new Error(
      "Local model is offline. Finish the model download and start the model service first.",
    );
  await db.systemSetting.upsert({
    where: { key: "ai.mode" },
    create: { key: "ai.mode", value: mode },
    update: { value: mode },
  });
}
export function configurationName(config: ProviderConfig) {
  return providerConfigured(config) ? config.model : "EDITH Demo";
}
export async function voiceStatus() {
  try {
    const res = await fetch("http://127.0.0.1:8881/health", {
      cache: "no-store",
      signal: AbortSignal.timeout(1200),
    });
    return { available: res.ok, engine: "kokoro", local: true };
  } catch {
    return { available: false, engine: "kokoro", local: true };
  }
}
