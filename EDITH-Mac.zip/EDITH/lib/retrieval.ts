export function tokens(text: string): string[] {
  return [...new Set(text.toLowerCase().match(/[a-z0-9]{3,}/g) ?? [])];
}
export function score(
  query: string,
  content: string,
  importance = 0.5,
): number {
  const terms = tokens(query);
  if (!terms.length) return 0;
  const haystack = content.toLowerCase();
  const matches = terms.filter((term) => haystack.includes(term)).length;
  return matches ? (matches / terms.length) * 0.8 + importance * 0.2 : 0;
}
export function retrieve<
  T extends { title?: string; content: string; importance?: number },
>(query: string, items: T[], limit = 5): T[] {
  return items
    .map((item) => ({
      item,
      score: score(
        query,
        `${item.title ?? ""} ${item.content}`,
        item.importance,
      ),
    }))
    .filter((item) => item.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map(({ item }) => item);
}
export function chunkText(text: string, size = 1000): string[] {
  if (size < 100) throw new Error("Chunk size too small");
  const result: string[] = [];
  for (let pos = 0; pos < text.length; pos += size) {
    const chunk = text.slice(pos, pos + size).trim();
    if (chunk) result.push(chunk);
  }
  return result;
}
