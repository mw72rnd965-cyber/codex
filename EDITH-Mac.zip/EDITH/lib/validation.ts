import { z } from "zod";
export const chatInput = z.object({
  prompt: z.string().trim().min(1).max(8000),
  conversationId: z.string().optional(),
});
export const memoryInput = z.object({
  title: z.string().trim().min(1).max(200),
  content: z.string().trim().min(1).max(20000),
  category: z
    .enum([
      "PROFILE",
      "PREFERENCES",
      "PROJECTS",
      "PEOPLE",
      "GOALS",
      "FACTS",
      "CONVERSATION",
      "CUSTOM",
    ])
    .default("CUSTOM"),
  importance: z.number().min(0).max(1).default(0.7),
});
export const taskInput = z.object({
  title: z.string().trim().min(1).max(200),
  description: z.string().max(20000).default(""),
  priority: z.enum(["LOW", "NORMAL", "HIGH"]).default("NORMAL"),
  status: z
    .enum(["PENDING", "ACTIVE", "COMPLETED", "ARCHIVED"])
    .default("PENDING"),
  dueDate: z.string().datetime().nullable().optional(),
});
export const noteInput = z.object({
  title: z.string().trim().min(1).max(200),
  content: z.string().max(50000),
  tags: z.string().max(300).default(""),
  pinned: z.boolean().default(false),
});
export const settingsInput = z.object({
  displayName: z.string().trim().min(1).max(50),
  voiceOutput: z.boolean(),
  voiceEngine: z.enum(["kokoro", "browser"]).default("kokoro"),
  voiceId: z.string().max(200).default("af_sarah"),
  voiceRate: z.number().min(0.75).max(1.25).default(0.94),
  voicePitch: z.number().min(0.8).max(1.2).default(1),
  boot: z.boolean(),
  reducedMotion: z.boolean(),
  memoryEnabled: z.boolean(),
  retrievalCount: z.number().int().min(1).max(10),
});
export function safeFilename(name: string) {
  return name.replace(/[^a-zA-Z0-9._-]/g, "_").slice(-120);
}
