"""Local Kokoro voice service. No cloud requests or analytics."""
import io
import os
import threading
from pathlib import Path
import onnxruntime as ort
ort.disable_telemetry_events()
from kokoro_onnx import Kokoro
import soundfile as sf
from fastapi import FastAPI, HTTPException, Response
from pydantic import BaseModel, Field

MODEL_DIR = Path(os.environ.get("EDITH_VOICE_MODEL_DIR", "/workspace/models/kokoro"))
options = ort.SessionOptions()
options.intra_op_num_threads = 2
options.inter_op_num_threads = 1
session = ort.InferenceSession(str(MODEL_DIR / "kokoro-v1.0.onnx"), sess_options=options, providers=["CPUExecutionProvider"])
engine = Kokoro.from_session(session, str(MODEL_DIR / "voices-v1.0.bin"))
lock = threading.Lock()
VOICES = {"af_sarah": "EDITH · calm American female", "af_bella": "Bella · smooth American female", "af_heart": "Heart · warm American female", "bf_emma": "Emma · measured British female"}
app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)

class SpeechRequest(BaseModel):
    text: str = Field(min_length=1, max_length=4000)
    voice: str = "af_sarah"
    speed: float = Field(default=0.94, ge=0.75, le=1.25)

@app.get("/health")
def health():
    return {"status": "ok", "engine": "kokoro", "local": True, "voices": VOICES}

@app.post("/speech")
def speech(request: SpeechRequest):
    if request.voice not in VOICES:
        raise HTTPException(400, "Unknown voice")
    with lock:
        samples, rate = engine.create(request.text, voice=request.voice, speed=request.speed, lang="en-gb" if request.voice.startswith("bf_") else "en-us")
    buffer = io.BytesIO()
    sf.write(buffer, samples, rate, format="WAV", subtype="PCM_16")
    return Response(buffer.getvalue(), media_type="audio/wav", headers={"Cache-Control": "no-store"})
