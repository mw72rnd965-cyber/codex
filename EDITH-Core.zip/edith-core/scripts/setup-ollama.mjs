import { readFileSync, writeFileSync } from "node:fs";

let base;
try {
  base = new URL(process.env.OLLAMA_BASE_URL || "http://127.0.0.1:11434");
  if (!["http:", "https:"].includes(base.protocol) || !["127.0.0.1", "localhost", "[::1]"].includes(base.hostname) || base.username || base.password || base.pathname !== "/" || base.search || base.hash) throw new Error();
} catch { console.error("Ollama must use a local loopback address."); process.exit(1); }
const output = process.argv[2];
const savedModel = process.argv[3];
if (!output) throw new Error("A model output file is required.");
const fallback = "qwen2.5:3b";
const preferred = [fallback, "llama3.2:3b", "qwen3:4b", "gemma3:4b", "llama3.2:latest"];
let cached = "";
if (savedModel) { try { cached = readFileSync(savedModel, "utf8").trim(); } catch {} }
const requested = process.env.EDITH_MODEL?.trim();
if (requested && !/^[A-Za-z0-9][A-Za-z0-9_.:/-]{0,199}$/.test(requested)) throw new Error("Choose a valid Ollama model name.");

async function request(path, body, timeout = 15000) {
  try {
    return await fetch(base.origin + path, {
      method: body ? "POST" : "GET", headers: { "Content-Type": "application/json" },
      ...(body ? { body: JSON.stringify(body) } : {}), signal: AbortSignal.timeout(timeout),
    });
  } catch { throw new Error("Ollama did not respond. Open the Ollama app, then run the EDITH command again."); }
}
async function canChat(name) {
  if (/^moondream(?::|$)/i.test(name)) return false; // Image-only use needs images, which this chat does not send.
  const response = await request("/api/show", { model: name });
  if (!response.ok) return false;
  const info = await response.json();
  // Current Ollama reports explicit capabilities. Older versions lack this field.
  return Array.isArray(info.capabilities) ? info.capabilities.includes("completion") : !/embed|nomic|mxbai|bge-/i.test(name);
}
async function pull(name) {
  console.log(`Downloading ${name} in Ollama. This happens once; the default model is about 2 GB.`);
  const response = await request("/api/pull", { model: name, stream: true }, 1800000);
  if (!response.ok || !response.body) throw new Error("Ollama could not download the model. Check your Internet connection and try again.");
  const reader = response.body.getReader(); const decoder = new TextDecoder(); let buffer = ""; let success = false; let progress = -1;
  function status(line) {
    if (!line.trim()) return;
    const event = JSON.parse(line);
    if (event.error) throw new Error("Ollama reported a model download error. Check your Internet connection and rerun the EDITH command.");
    if (event.status === "success") success = true;
    if (event.total && event.completed) {
      const step = Math.floor(event.completed / event.total * 5) * 20;
      if (step > progress) { progress = step; console.log(`Model download: ${Math.min(100, step)}%`); }
    }
  }
  try {
    while (true) {
      const { value, done } = await reader.read(); if (done) break;
      buffer += decoder.decode(value, { stream: true });
      let index;
      while ((index = buffer.indexOf("\n")) >= 0) { status(buffer.slice(0, index)); buffer = buffer.slice(index + 1); }
    }
    buffer += decoder.decode(); if (buffer.trim()) status(buffer);
    if (!success) throw new Error("The model download stopped before Ollama verified it. Run the EDITH command again.");
  } finally { await reader.cancel().catch(() => {}); reader.releaseLock(); }
}
async function warm(name) {
  console.log(`Loading ${name} for EDITH…`);
  const response = await request("/api/generate", { model: name, prompt: "", stream: false, think: false, keep_alive: "10m", options: { num_ctx: 8192 } }, 180000);
  if (!response.ok || !(await response.json()).done) throw new Error("Ollama could not load the model. Close unused apps or choose a smaller model.");
}

try {
  const response = await request("/api/tags");
  if (!response.ok) throw new Error("Ollama is not ready. Open Ollama and try again.");
  const data = await response.json();
  if (!Array.isArray(data.models)) throw new Error("Update Ollama, then run the EDITH command again.");
  const models = data.models.map(m => ({ name: m.name || m.model, size: m.size || 0 })).filter(m => typeof m.name === "string");
  models.sort((a,b) => {
    const rank = name => name === cached ? -1 : preferred.includes(name) ? preferred.indexOf(name) : 100;
    return rank(a.name) - rank(b.name) || a.size - b.size;
  });
  let selected = requested || "";
  if (!selected) { for (const model of models) { if (await canChat(model.name)) { selected = model.name; break; } } }
  if (!selected) selected = fallback;
  const installed = models.some(m => m.name === selected || m.name === selected + ":latest");
  if (!installed) await pull(selected);
  if (!await canChat(selected)) throw new Error("The selected model cannot chat. Choose a chat model rather than an embedding model.");
  try { await warm(selected); }
  catch (error) {
    if (requested || selected === fallback) throw error;
    console.log("That model could not load. Trying the smaller Qwen2.5 3B model.");
    selected = fallback;
    if (!models.some(m => m.name === selected)) await pull(selected);
    await warm(selected);
  }
  writeFileSync(output, selected + "\n", { mode: 0o600 });
  if (savedModel) writeFileSync(savedModel, selected + "\n", { mode: 0o600 });
  console.log(`EDITH will use local Ollama: ${selected}. No API key needed.`);
} catch (error) {
  console.error(error instanceof Error ? error.message : "Ollama setup failed. Open Ollama and try again.");
  process.exitCode = 1;
}
