export const actionKinds = ["calendar_read", "calendar_create", "reminder_read", "reminder_create", "mail_read", "mail_draft", "mail_send"] as const;
export type ActionKind = typeof actionKinds[number];
export type ActionFields = {title:string;start:string;end:string;due:string;notes:string;location:string;to:string;subject:string;body:string};
export const emptyFields: ActionFields = {title:"",start:"",end:"",due:"",notes:"",location:"",to:"",subject:"",body:""};
export type ActionProposal = {id:string;kind:ActionKind;fields:ActionFields;expiresAt:number};
export type ActionStatus = {proposal:ActionProposal;status:"proposed"|"running"|"completed"|"failed"|"cancelled";text?:string};
export const actionLabels: Record<ActionKind,string> = {
  calendar_read:"Read Calendar",calendar_create:"Create calendar event",reminder_read:"Read Reminders",reminder_create:"Add reminder",mail_read:"Read recent email",mail_draft:"Open email draft",mail_send:"Send email",
};
export const actionFields: Record<ActionKind,(keyof ActionFields)[]> = {
  calendar_read:["start","end"],calendar_create:["title","start","end","location","notes"],reminder_read:[],reminder_create:["title","due","notes"],mail_read:[],mail_draft:["to","subject","body"],mail_send:["to","subject","body"],
};
// Only an explicit request from the user can prepare an action. Model output,
// retrieved pages, and native email contents never enter this classifier.
export function actionIntent(message:string):ActionKind|null {
  const text=message.trim().replace(/^(?:(?:hey\s+)?edith[,!]?\s+)?(?:(?:please|(?:can|could|would|will) you(?: please)?)\s+)?/i,"");
  if(/^(?:send|email)\b.*(?:email|mail|\S+@\S+)/i.test(text))return "mail_send";
  if(/^(?:draft|compose|prepare|write)\b.*(?:email|mail)\b/i.test(text))return "mail_draft";
  if(/^(?:(?:read|show|list|check)\b.*(?:my emails?|my mail|my inbox)|what(?:'s| is) in my inbox|any new emails?)/i.test(text))return "mail_read";
  if(/^(?:remind me\b|(?:add|create|set|make)\b.*\breminder\b)/i.test(text))return "reminder_create";
  if(/^(?:read|show|list|check)\b.*\b(?:my reminders|reminders)\b/i.test(text))return "reminder_read";
  if(/^(?:add|create|book|schedule|arrange|set up)\b.*\b(?:calendar|event|meeting|appointment)\b/i.test(text))return "calendar_create";
  if(/^(?:(?:read|show|list|check)\b.*\b(?:my calendar|my events|my schedule|my meetings|my agenda)|what(?:'s| is) on my (?:calendar|schedule)|what meetings do i have)/i.test(text))return "calendar_read";
  return null;
}
