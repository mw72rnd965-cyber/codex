import http from "node:http";
import https from "node:https";
import { lookup } from "node:dns/promises";
import { BlockList, isIP,type LookupFunction } from "node:net";

export class WebAccessError extends Error {}
// Separate lists prevent Node's mapped-address matching from treating the
// IPv6 ::ffff/96 rule as a block on every IPv4 address.
const blocked4 = new BlockList();
const blocked6 = new BlockList();
for (const [ip, bits] of [["0.0.0.0",8],["10.0.0.0",8],["100.64.0.0",10],["127.0.0.0",8],["169.254.0.0",16],["172.16.0.0",12],["192.0.0.0",24],["192.0.2.0",24],["192.168.0.0",16],["198.18.0.0",15],["198.51.100.0",24],["203.0.113.0",24],["224.0.0.0",4],["240.0.0.0",4]] as const) blocked4.addSubnet(ip,bits,"ipv4");
for (const [ip,bits] of [["::",128],["::1",128],["::ffff:0:0",96],["fc00::",7],["fe80::",10],["ff00::",8],["2001:db8::",32],["2002::",16]] as const) blocked6.addSubnet(ip,bits,"ipv6");
export function isPublicAddress(address: string) {
  const family=isIP(address);if(!family)return false;
  if(family===6 && address.toLowerCase().startsWith("::ffff:")) return false;
  return family===4?!blocked4.check(address,"ipv4"):!blocked6.check(address,"ipv6");
}
export function publicUrl(value: string) {
  const url=new URL(value);
  const hostname=url.hostname.replace(/^\[|\]$/g,"");
  if(url.protocol!=="https:"||url.username||url.password||(url.port&&url.port!=="443")||hostname==="localhost"||hostname.endsWith(".localhost")||hostname.endsWith(".local")||(!isIP(hostname)&&!hostname.includes("."))||(isIP(hostname)&&!isPublicAddress(hostname))) throw new WebAccessError("Only public HTTPS sources can be read.");
  url.hash="";return url;
}
export type WebDocument = { url: string; text: string; contentType: string };
export type WebReader = (url: string, signal: AbortSignal) => Promise<WebDocument>;
let proxyInitialized=false;
function initializeProxy() {
  if(proxyInitialized)return;
  const configure=(http as unknown as { setGlobalProxyFromEnv?:()=>void }).setGlobalProxyFromEnv;
  // Preserve the session's existing proxy and CA trust. Node 24 supports this
  // for both requests and fetch; no TLS verification settings are changed.
  if(configure)configure();proxyInitialized=true;
}
const fixedProviders=new Set(["www.bing.com","html.duckduckgo.com","en.wikipedia.org","api.search.brave.com"]);
export async function readPublicWeb(value: string, parent: AbortSignal, redirects=0): Promise<WebDocument> {
  const url=publicUrl(value);if(redirects>3)throw new WebAccessError("Source redirected too many times.");
  const hostname=url.hostname.replace(/^\[|\]$/g,"");
  let address: {address:string;family:number}|undefined;
  const throughProxy=Boolean(process.env.HTTPS_PROXY||process.env.https_proxy);
  // Fixed public search/API hosts may rely on the managed proxy's DNS. Other
  // sources are checked locally, and direct requests use that pinned address.
  if(!(throughProxy&&fixedProviders.has(hostname))) {
    const addresses=await lookup(hostname,{all:true});
    if(!addresses.length||addresses.some(entry=>!isPublicAddress(entry.address)))throw new WebAccessError("Private network sources cannot be read.");
    address=addresses[0];
  }
  const signal=AbortSignal.any([parent,AbortSignal.timeout(10000)]);
  let result: {status:number;location?:string;text:string;contentType:string};
  try {
    initializeProxy();
    result=await new Promise((resolve,reject)=>{
      const request=https.get(url,{
        signal,headers:{"User-Agent":"EDITH/1.0 (+https://github.com/mw72rnd965-cyber/codex)","Accept":"text/html,application/json,application/rss+xml,text/plain;q=0.8","Accept-Encoding":"identity"},
        ...(address?{lookup:((name,options,callback)=>{
          if(name===hostname){if(typeof options==="object"&&options.all)callback(null,[{address:address!.address,family:address!.family}]);else callback(null,address!.address,address!.family);}
          else void lookup(name,{all:true}).then(entries=>{if(options.all)callback(null,entries);else if(entries[0])callback(null,entries[0].address,entries[0].family);else callback(new Error("Address not found"),"");}).catch(error=>callback(error,""));
        }) as LookupFunction}:{}),
      },response=>{
        const status=response.statusCode||0;
        if(status>=300&&status<400){response.resume();resolve({status,location:response.headers.location,text:"",contentType:""});return;}
        let bytes=0;const chunks:Buffer[]=[];
        response.on("data",chunk=>{bytes+=chunk.length;if(bytes>1500000){request.destroy(new WebAccessError("Source is too large."));return;}chunks.push(chunk);});
        response.on("error",reject);
        response.on("end",()=>resolve({status,text:Buffer.concat(chunks).toString("utf8"),contentType:response.headers["content-type"]||""}));
      });request.on("error",reject);
    });
  } catch {if(parent.aborted)throw parent.reason;throw new WebAccessError("The source could not be reached.");}
  if(result.status>=300&&result.status<400&&result.location)return readPublicWeb(new URL(result.location,url).href,parent,redirects+1);
  if(result.status<200||result.status>=300)throw new WebAccessError("The source is unavailable or blocked.");
  return {url:url.href,text:result.text,contentType:result.contentType};
}
