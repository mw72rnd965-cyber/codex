import type { Message } from "../protocol";

export class OllamaError extends Error {}
export function ollamaBaseUrl() {
  const url = new URL(process.env.OLLAMA_BASE_URL || "http://127.0.0.1:11434");
  if (!["http:", "https:"].includes(url.protocol) || !["127.0.0.1", "localhost", "[::1]"].includes(url.hostname) || url.username || url.password || url.search || url.hash || url.pathname !== "/") {
    throw new OllamaError("Ollama must use a local loopback address.");
  }
  return url.origin;
}
export async function ollamaAvailable() {
  if (!process.env.AI_MODEL) return false;
  try {
    const response = await fetch(ollamaBaseUrl() + "/api/tags", { signal: AbortSignal.timeout(2000), cache: "no-store" });
    if (!response.ok) return false;
    const data = await response.json() as { models?: { name?: string; model?: string; remote_host?: string; remote_model?: string }[] };
    return Boolean(data.models?.some(model => !model.remote_host && !model.remote_model && [process.env.AI_MODEL, process.env.AI_MODEL + ":latest"].includes(model.name || model.model)));
  } catch { return false; }
}
type OllamaFrame = { message?: { content?: string }; done?: boolean; error?: string };
export async function* ollamaTokens(messages: Message[], systemPrompt: string, signal: AbortSignal) {
  if (!process.env.AI_MODEL) throw new OllamaError("No Ollama model is selected. Restart EDITH with its launcher to choose one.");
  let response: Response;
  try {
    const details = await fetch(ollamaBaseUrl() + "/api/show", {
      method: "POST", headers: { "Content-Type": "application/json" }, signal,
      body: JSON.stringify({ model: process.env.AI_MODEL }), cache: "no-store",
    });
    if (!details.ok) { await details.body?.cancel(); throw new OllamaError("This model isn’t installed in Ollama. Restart EDITH with its launcher to set it up."); }
    const info = await details.json() as { remote_host?: string; remote_model?: string };
    if (info.remote_host || info.remote_model) throw new OllamaError("Choose a local Ollama model for EDITH. The launcher can select one for you.");
    response = await fetch(ollamaBaseUrl() + "/api/chat", {
      method: "POST", headers: { "Content-Type": "application/json" }, signal,
      body: JSON.stringify({
        model: process.env.AI_MODEL,
        messages: [{ role: "system", content: systemPrompt }, ...messages],
        stream: true, think: false, keep_alive: "10m",
        options: { num_predict: 1200, num_ctx: 8192 },
      }),
    });
  } catch (error) {
    if (signal.aborted) throw error;
    if (error instanceof OllamaError) throw error;
    throw new OllamaError("Ollama isn’t running. Open Ollama and retry.");
  }
  if (!response.ok || !response.body) {
    await response.body?.cancel().catch(() => {});
    throw new OllamaError(response.status === 404
      ? "This model isn’t installed in Ollama. Restart EDITH with its launcher to set it up."
      : "Ollama couldn’t load the model. Try a smaller model or restart Ollama.");
  }
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = ""; let completed = false;
  function frame(line: string) {
    if (!line.trim()) return null;
    let data: OllamaFrame;
    try { data = JSON.parse(line); } catch { throw new OllamaError("Ollama sent an invalid response. Update Ollama and retry."); }
    if (data.error) throw new OllamaError("Ollama couldn’t finish the response. Restart Ollama or try a smaller model.");
    if (data.done) completed = true;
    // Thinking and timing fields are deliberately excluded from visible output.
    return typeof data.message?.content === "string" ? data.message.content : null;
  }
  try {
    while (!completed) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      if (buffer.length > 262144) throw new OllamaError("Ollama sent an oversized response. Please retry.");
      let boundary: number;
      while ((boundary = buffer.indexOf("\n")) >= 0) {
        const content = frame(buffer.slice(0, boundary)); buffer = buffer.slice(boundary + 1);
        if (content) yield content;
        if (completed) break;
      }
    }
    buffer += decoder.decode();
    if (!completed && buffer.trim()) { const content = frame(buffer); if (content) yield content; }
    if (!completed) throw new OllamaError("The Ollama connection ended early. Please retry.");
  } finally { await reader.cancel().catch(() => {}); reader.releaseLock(); }
}
