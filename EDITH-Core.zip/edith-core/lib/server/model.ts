import OpenAI from "openai";
import type { Configuration, Message } from "../protocol";
export const defaultPrompt = "You are EDITH, a calm, intelligent conversational assistant. Be direct, composed, and concise unless detail is requested. Be honest about uncertainty. You have no access to live information, accounts, cameras, devices, or external systems. Never claim you performed actions outside this conversation. Avoid unnecessary roleplay.";
export function configuration(): Configuration {
  const live = process.env.AI_PROVIDER !== "demo" && Boolean(process.env.AI_API_KEY && process.env.AI_MODEL);
  return { mode: live ? "live" : "demo", transcription: live && Boolean(process.env.EDITH_TRANSCRIPTION_MODEL), speech: live && Boolean(process.env.EDITH_TTS_MODEL) };
}
export function client() {
  const baseURL = process.env.AI_BASE_URL || "https://api.openai.com/v1";
  const url = new URL(baseURL);
  if (url.protocol !== "https:" && !(url.protocol === "http:" && ["localhost", "127.0.0.1", "[::1]"].includes(url.hostname))) throw new Error("Invalid provider configuration");
  return new OpenAI({ apiKey: process.env.AI_API_KEY, baseURL, timeout: 45000, maxRetries: 0 });
}
export function safeError(error: unknown) {
  if (error instanceof OpenAI.APIError) {
    if (error.status === 401 || error.status === 403) return "The AI provider could not authenticate. Check the server credentials.";
    if (error.status === 429) return "The AI provider is busy or out of quota. Wait a moment and retry.";
  }
  return "EDITH couldn’t connect to the AI provider. Please try again.";
}
export function demoReply(messages: Message[]) {
  const current = messages.at(-1)!.content;
  const previous = messages.filter(m => m.role === "user").slice(0, -1);
  if (/what (did|was)|remember|earlier|previous|follow.?up/i.test(current) && previous.length) {
    return `In this session, you said: “${previous.at(-1)!.content.slice(0, 180)}”. I can keep track of our conversation while this tab is open. This is a simulated demo reply; a connected model will offer a thoughtful answer.`;
  }
  if (/^(hi|hello|hey)[.!\s]*$/i.test(current)) return "Hello. I’m here. What’s on your mind? This is demo mode—connect a model to start a real conversation.";
  if (/what can|help|capabilities/i.test(current)) return "We can think through an idea, untangle a question, or shape something you’re working on. I can follow the conversation in this tab. Right now my replies are simulated; connect an AI provider for real reasoning.";
  if (/plan|organize|focus|priorit/i.test(current)) return "Let’s make a little room to think. Start with the one outcome that matters most, then choose a small next step. Leave everything else for a moment. This is a simulated example; a connected model can work through the specifics with you.";
  return `I’m with you. You asked about “${current.slice(0, 140)}”. In demo mode, I can show you the streaming, conversation, and voice experience, but I’m not generating a real answer. Connect a model to explore this properly.`;
}
export async function* tokens(messages: Message[], signal: AbortSignal) {
  if (configuration().mode === "demo") {
    for (const token of demoReply(messages).match(/\S+\s*/g) || []) {
      await new Promise<void>((resolve, reject) => {
        const abort = () => { clearTimeout(timer); reject(new DOMException("Cancelled", "AbortError")); };
        const timer = setTimeout(() => { signal.removeEventListener("abort", abort); resolve(); }, 34);
        if (signal.aborted) abort(); else signal.addEventListener("abort", abort, { once: true });
      });
      yield token;
    }
    return;
  }
  const stream = await client().chat.completions.create({
    model: process.env.AI_MODEL!,
    messages: [{ role: "system", content: process.env.EDITH_SYSTEM_PROMPT || defaultPrompt }, ...messages],
    stream: true,
    max_completion_tokens: 1200,
  }, { signal });
  for await (const chunk of stream) {
    const text = chunk.choices[0]?.delta?.content;
    if (text) yield text;
  }
}
