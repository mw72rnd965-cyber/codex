import { platform } from "node:os";
import { actionsAvailable } from "./action-planner";
import { actionStore,type ActionApp } from "./action-store";

// App-access questions describe installed capabilities, not facts to search for
// or authorization to read private data. Keep the answer independent of a model.
export function capabilityReply(message:string):string|null {
  const text=message.trim().toLowerCase().replace(/[’‘]/g,"'").replace(/\bu\b/g,"you")
    .replace(/\b(?:acess|acces|accsss)\b/g,"access").replace(/^(?:hey\s+)?edith[,!]?\s+/,"");
  const question=/^(?:do you (?:already )?have (?:access|permission)|have you (?:got |been granted )?(?:access|permission)|can you (?:access|connect to|use)|are you (?:connected to|able to (?:access|use)|allowed to (?:access|use))|(?:have|did) i (?:already )?(?:give|given|grant|granted|allow|allowed) you|why (?:can't|cannot|can not) you (?:access|use))/;
  if(!question.test(text))return null;
  const apps:ActionApp[]=[];
  if(/\b(?:calendar|calendars|schedule|agenda)\b/.test(text))apps.push("calendar");
  if(/\breminders?\b/.test(text))apps.push("reminder");
  if(/\b(?:email|emails|mail|inbox)\b/.test(text))apps.push("mail");
  if(!apps.length)return null;
  if(platform()!=="darwin")return "Calendar, Reminders and Mail are supported in EDITH's Mac download with local Ollama. This copy isn't running on macOS, so it can't access your Mac apps. Run the one-command Mac launcher to use them.";
  if(process.env.MAC_ACTIONS==="off")return "Mac app actions are turned off in this copy of EDITH. Enable MAC_ACTIONS in EDITH's local settings and restart to use Calendar, Reminders and Mail. This question doesn't check macOS permissions.";
  if(!actionsAvailable())return "Calendar, Reminders and Mail need local Ollama in EDITH's Mac app. Start EDITH with the one-command Mac launcher to connect it. This question doesn't check macOS permissions.";
  const descriptions:Record<ActionApp,{name:string;ability:string;example:string}>={
    calendar:{name:"Calendar",ability:"read your calendar and create an event",example:"Show my calendar today"},
    reminder:{name:"Reminders",ability:"read your reminders and add a reminder",example:"Read my reminders"},
    mail:{name:"Mail",ability:"read recent email previews, open a draft, or send an email",example:"Read my emails"},
  };
  return apps.map(app=>{
    const {name,ability,example}=descriptions[app];const outcome=actionStore.lastOutcome(app);
    const permission=outcome?.status==="completed"?`Your last ${name} action succeeded in this session; current macOS permission will be checked again when you confirm an action.`
      :outcome?.status==="failed"?`Your last ${name} action failed, so I can't confirm current access. The next confirmed action will report whether permission or account setup needs attention.`
      :"I haven't checked macOS permission yet; macOS will ask if needed when you confirm your first action.";
    return `I can ${ability} through your Mac's ${name} app after you review and confirm the request. ${permission} Say “${example}” to get started. Asking about access doesn't read or change anything.`;
  }).join("\n\n");
}
