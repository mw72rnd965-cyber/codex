export function sameOrigin(request: Request) {
  const origin = request.headers.get("origin");
  if (!origin) return true;
  try {
    const url=new URL(origin);
    // Next may normalize request.url to localhost. The browser's Host retains
    // the actual address and port; scripts cannot override that browser header.
    return ["http:","https:"].includes(url.protocol) && url.host === (request.headers.get("host") || new URL(request.url).host);
  } catch { return false; }
}
export function jsonError(message: string, status: number) {
  return Response.json({ error: message }, { status, headers: { "Cache-Control": "no-store" } });
}
export function localActionRequest(request:Request) {
  try{
    const host=new URL("http://"+(request.headers.get("host")||new URL(request.url).host));
    return ["127.0.0.1","localhost","[::1]"].includes(host.hostname)&&request.headers.get("x-edith-action")==="1"&&sameOrigin(request)&&Boolean(request.headers.get("origin")||request.headers.get("sec-fetch-site")==="same-origin");
  }catch{return false;}
}
