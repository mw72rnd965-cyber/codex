import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { homedir,platform,tmpdir } from "node:os";
import { join } from "node:path";
import { createHash } from "node:crypto";
import { readFile,writeFile,mkdir,mkdtemp,rm,rename,access } from "node:fs/promises";
import type { ActionFields,ActionKind,ActionPhase } from "../actions";
import { ActionError } from "./action-store";
import { waitForMacResult } from "./mac-result";
const command=promisify(execFile);
let preparation:Promise<string>|undefined;
async function buildHelper() {
  if(platform()!=="darwin")throw new ActionError("Native actions need EDITH running on your Mac.");
  const root=process.env.EDITH_INSTALL_ROOT||join(homedir(),"Library","Application Support","EDITH Core");
  const tools=join(root,"tools");await mkdir(tools,{recursive:true,mode:0o700});
  const source=join(process.cwd(),"native","mac-actions.js");
  const hash=createHash("sha256").update(await readFile(source)).update("helper-bundle-v1").digest("hex");
  const helper=join(tools,"EDITH Actions.app");
  try{if((await readFile(join(tools,"mac-actions.sha256"),"utf8")).trim()===hash){await access(join(helper,"Contents","MacOS","applet"));return helper;}}catch{}
  const dir=await mkdtemp(join(tools,".actions-build-"));const bundle=join(dir,"EDITH Actions.app");
  try {
    await command("/usr/bin/osacompile",["-l","JavaScript","-o",bundle,source],{timeout:30000,maxBuffer:262144});
    const plist=join(bundle,"Contents","Info.plist");
    const converted=await command("/usr/bin/plutil",["-convert","json","-o","-",plist],{timeout:10000,maxBuffer:262144});
    const properties=JSON.parse(converted.stdout);
    Object.assign(properties,{
      CFBundleIdentifier:"app.edith.local-actions",CFBundleName:"EDITH Actions",LSUIElement:true,
      NSCalendarsUsageDescription:"EDITH reads and creates calendar events only after you review an action.",
      NSCalendarsFullAccessUsageDescription:"EDITH reads and creates calendar events only after you review an action.",
      NSRemindersUsageDescription:"EDITH reads and adds reminders only after you review an action.",
      NSRemindersFullAccessUsageDescription:"EDITH reads and adds reminders only after you review an action.",
      NSAppleEventsUsageDescription:"EDITH uses Mail to read recent messages, create drafts or submit emails after your confirmation.",
    });
    await writeFile(plist,JSON.stringify(properties),{mode:0o600});
    await command("/usr/bin/plutil",["-convert","xml1",plist],{timeout:10000});
    await command("/usr/bin/codesign",["--force","--deep","--sign","-",bundle],{timeout:30000,maxBuffer:262144});
    // Stable bundle identity lets macOS retain the user's privacy permissions.
    // The helper is only replaced when its source changes; no Xcode is needed.
    await rm(helper,{recursive:true,force:true});await rename(bundle,helper);
    await writeFile(join(tools,"mac-actions.sha256"),hash,{mode:0o600});return helper;
  }catch{throw new ActionError("EDITH could not prepare its Mac helper. Restart with the Mac launcher and try again.");}
  finally{await rm(dir,{recursive:true,force:true});}
}
export async function prepareMacHelper(){
  if(!preparation)preparation=buildHelper().catch(error=>{preparation=undefined;throw error;});
  return preparation;
}
export async function runMacAction(kind:ActionKind,fields:ActionFields,onProgress?:(phase:ActionPhase)=>void) {
  const helper=await prepareMacHelper();const dir=await mkdtemp(join(tmpdir(),"edith-action-"));
  try {
    // Personal text is sent through a private JSON file, never command strings
    // or process arguments. The fixed helper never evaluates that text.
    await writeFile(join(dir,"input.json"),JSON.stringify({kind,fields,deadline:Date.now()+120000}),{mode:0o600});
    try{await command("/usr/bin/open",["-n",helper,"--args",dir],{timeout:15000,maxBuffer:262144});}catch{/* A launched helper may still return a receipt if open reports an error. */}
    const result=await waitForMacResult(dir,onProgress);
    if(!result.ok){
      const app=kind.startsWith("calendar_")?"Calendar":kind.startsWith("reminder_")?"Reminders":"Mail";
      const messages={permission:`macOS has not allowed ${app} access. Open System Settings → Privacy & Security and allow EDITH Actions (${app==="Calendar"?"Calendars → Full Access":app==="Reminders"?"Reminders":"Automation → Mail"}), then ask again.`,permission_timeout:`Waiting for macOS ${app} permission. Click Allow in the EDITH Actions prompt, or allow it in System Settings → Privacy & Security. No ${app} read or write was started.`,account:"Set up a writable Calendar or Reminders list, or an account in the Mail app, then ask again.",timeout:"The Mac app did not finish its read. Check the app before trying again.",native:"Could not confirm completion. Check the relevant Mac app before trying again."};
      throw new ActionError(messages[result.code||"native"]);
    }
    if(!result.text)throw new ActionError("The Mac helper returned no confirmation. Check the app before retrying.");
    return result.text;
  }finally{await rm(dir,{recursive:true,force:true});}
}
