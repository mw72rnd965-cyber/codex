import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { homedir,platform,tmpdir } from "node:os";
import { join } from "node:path";
import { createHash } from "node:crypto";
import { readFile,writeFile,mkdir,mkdtemp,rm,rename,access } from "node:fs/promises";
import { z } from "zod";
import type { ActionFields,ActionKind } from "../actions";
import { ActionError } from "./action-store";
const command=promisify(execFile);
let preparation:Promise<string>|undefined;
async function buildHelper() {
  if(platform()!=="darwin")throw new ActionError("Native actions need EDITH running on your Mac.");
  const root=process.env.EDITH_INSTALL_ROOT||join(homedir(),"Library","Application Support","EDITH Core");
  const tools=join(root,"tools");await mkdir(tools,{recursive:true,mode:0o700});
  const source=join(process.cwd(),"native","mac-actions.js");
  const hash=createHash("sha256").update(await readFile(source)).update("helper-bundle-v1").digest("hex");
  const helper=join(tools,"EDITH Actions.app");
  try{if((await readFile(join(tools,"mac-actions.sha256"),"utf8")).trim()===hash){await access(join(helper,"Contents","MacOS","applet"));return helper;}}catch{}
  const dir=await mkdtemp(join(tools,".actions-build-"));const bundle=join(dir,"EDITH Actions.app");
  try {
    await command("/usr/bin/osacompile",["-l","JavaScript","-o",bundle,source],{timeout:30000,maxBuffer:262144});
    const plist=join(bundle,"Contents","Info.plist");
    const converted=await command("/usr/bin/plutil",["-convert","json","-o","-",plist],{timeout:10000,maxBuffer:262144});
    const properties=JSON.parse(converted.stdout);
    Object.assign(properties,{
      CFBundleIdentifier:"app.edith.local-actions",CFBundleName:"EDITH Actions",LSUIElement:true,
      NSCalendarsUsageDescription:"EDITH reads and creates calendar events only after you review an action.",
      NSCalendarsFullAccessUsageDescription:"EDITH reads and creates calendar events only after you review an action.",
      NSRemindersUsageDescription:"EDITH reads and adds reminders only after you review an action.",
      NSRemindersFullAccessUsageDescription:"EDITH reads and adds reminders only after you review an action.",
      NSAppleEventsUsageDescription:"EDITH uses Mail to read recent messages, create drafts or submit emails after your confirmation.",
    });
    await writeFile(plist,JSON.stringify(properties),{mode:0o600});
    await command("/usr/bin/plutil",["-convert","xml1",plist],{timeout:10000});
    await command("/usr/bin/codesign",["--force","--deep","--sign","-",bundle],{timeout:30000,maxBuffer:262144});
    // Stable bundle identity lets macOS retain the user's privacy permissions.
    // The helper is only replaced when its source changes; no Xcode is needed.
    await rm(helper,{recursive:true,force:true});await rename(bundle,helper);
    await writeFile(join(tools,"mac-actions.sha256"),hash,{mode:0o600});return helper;
  }catch{throw new ActionError("EDITH could not prepare its Mac helper. Restart with the Mac launcher and try again.");}
  finally{await rm(dir,{recursive:true,force:true});}
}
export async function prepareMacHelper(){
  if(!preparation)preparation=buildHelper().catch(error=>{preparation=undefined;throw error;});
  return preparation;
}
const replySchema=z.object({ok:z.boolean(),text:z.string().max(12000).optional(),code:z.enum(["permission","account","timeout","native"]).optional()}).strict();
export async function runMacAction(kind:ActionKind,fields:ActionFields) {
  const helper=await prepareMacHelper();const dir=await mkdtemp(join(tmpdir(),"edith-action-"));
  try {
    // Personal text is sent through a private JSON file, never command strings
    // or process arguments. The fixed helper never evaluates that text.
    await writeFile(join(dir,"input.json"),JSON.stringify({kind,fields,deadline:Date.now()+120000}),{mode:0o600});
    try{await command("/usr/bin/open",["-n","-W",helper,"--args",dir],{timeout:150000,maxBuffer:262144});}catch{/* Read a result if the helper completed while open reported an error. */}
    let parsed:unknown;try{const bytes=await readFile(join(dir,"result.json"));if(bytes.length>50000)throw Error();parsed=JSON.parse(bytes.toString("utf8"));}catch{throw new ActionError("Could not confirm completion. Check Calendar, Reminders or Mail before trying again.");}
    const result=replySchema.safeParse(parsed);if(!result.success)throw new ActionError("The Mac helper did not return a valid result. Check the app before retrying.");
    if(!result.data.ok){
      const messages={permission:"Mac access was not granted. Allow EDITH Actions in System Settings → Privacy & Security, then ask again.",account:"Set up a writable Calendar or Reminders list, or an account in the Mail app, then ask again.",timeout:"Permission or the Mac app took too long. Check the app before trying again.",native:"Could not confirm completion. Check the relevant Mac app before trying again."};
      throw new ActionError(messages[result.data.code||"native"]);
    }
    if(!result.data.text)throw new ActionError("The Mac helper returned no confirmation. Check the app before retrying.");
    return result.data.text;
  }finally{await rm(dir,{recursive:true,force:true});}
}
