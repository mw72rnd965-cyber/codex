import { randomBytes } from "node:crypto";
import { z } from "zod";
import { actionKinds, emptyFields, type ActionFields, type ActionKind, type ActionProposal, type ActionStatus } from "../actions";
export class ActionError extends Error {}
export const fieldsSchema=z.object({
  title:z.string().max(200),start:z.string().max(50),end:z.string().max(50),due:z.string().max(50),notes:z.string().max(2000),location:z.string().max(300),to:z.string().max(320),subject:z.string().max(200),body:z.string().max(6000),
}).strict();
const iso=z.string().datetime({offset:true});
export function validateAction(kind:ActionKind,input:unknown):ActionFields {
  const parsed=fieldsSchema.safeParse(input);if(!parsed.success)throw new ActionError("Some action details are too long or invalid.");
  const fields=parsed.data;
  if(kind==="calendar_create"||kind==="reminder_create")if(!fields.title.trim())throw new ActionError("Add a title first.");
  if(kind.startsWith("calendar_")) {
    if(!iso.safeParse(fields.start).success||!iso.safeParse(fields.end).success)throw new ActionError("Choose valid start and end dates.");
    const duration=Date.parse(fields.end)-Date.parse(fields.start);
    if(duration<=0||duration>31*86400000)throw new ActionError("The end must follow the start, within 31 days.");
  }
  if(kind==="reminder_create"&&fields.due&&!iso.safeParse(fields.due).success)throw new ActionError("Choose a valid reminder date, or leave it empty.");
  if(kind==="mail_draft"||kind==="mail_send"){
    if(!z.string().email().safeParse(fields.to.trim()).success)throw new ActionError("Enter the recipient’s email address. EDITH will not guess it.");
    if(!fields.subject.trim()||!fields.body.trim())throw new ActionError("Add an email subject and message.");
  }
  return {...fields,to:fields.to.trim()};
}
export type NativeRunner=(kind:ActionKind,fields:ActionFields)=>Promise<string>;
export type ActionApp="calendar"|"reminder"|"mail";
export type ActionOutcome={status:"completed"|"failed";at:number};
export class ActionStore {
  private records=new Map<string,ActionStatus>();
  private outcomes=new Map<ActionApp,ActionOutcome>();
  private active=false;
  constructor(private now:()=>number=Date.now){}
  lastOutcome(app:ActionApp):ActionOutcome|undefined {
    const outcome=this.outcomes.get(app);return outcome?{...outcome}:undefined;
  }
  propose(kind:ActionKind,fields:Partial<ActionFields>):ActionProposal {
    if(!actionKinds.includes(kind))throw new ActionError("That action is not supported.");
    for(const [id,item] of this.records)if(item.status!=="running"&&item.proposal.expiresAt<this.now())this.records.delete(id);
    if(this.records.size>=30)throw new ActionError("There are too many pending actions. Wait a few minutes.");
    const complete=fieldsSchema.safeParse({...emptyFields,...fields});
    if(!complete.success)throw new ActionError("The proposed details are invalid.");
    const proposal={id:randomBytes(24).toString("hex"),kind,fields:complete.data,expiresAt:this.now()+10*60000};
    this.records.set(proposal.id,{proposal,status:"proposed"});return proposal;
  }
  get(id:string):ActionStatus {
    const item=this.records.get(id);if(!item)throw new ActionError("This action is unavailable. Ask EDITH again.");
    return structuredClone(item);
  }
  cancel(id:string) {
    const item=this.records.get(id);if(!item||item.status!=="proposed")throw new ActionError("Only a pending proposal can be cancelled.");
    item.status="cancelled";return this.get(id);
  }
  confirm(id:string,input:unknown,run:NativeRunner):ActionStatus {
    const item=this.records.get(id);if(!item)throw new ActionError("This action is unavailable. Ask EDITH again.");
    // A retry after a lost HTTP response observes the existing run; it cannot
    // send another email or create a second calendar item.
    if(item.status==="running"||item.status==="completed"||item.status==="failed")return this.get(id);
    if(item.status!=="proposed"||item.proposal.expiresAt<this.now())throw new ActionError("This proposal was cancelled or expired. Ask EDITH again.");
    if(this.active)throw new ActionError("Another action is running. Wait for its result.");
    item.proposal.fields=validateAction(item.proposal.kind,input);item.status="running";this.active=true;
    const app=item.proposal.kind.split("_")[0] as ActionApp;
    void Promise.resolve().then(()=>run(item.proposal.kind,item.proposal.fields)).then(text=>{item.text=text.slice(0,12000);item.status="completed";this.outcomes.set(app,{status:"completed",at:this.now()});}).catch(error=>{
      item.text=error instanceof ActionError?error.message:"Could not confirm completion. Check the relevant Mac app before trying again.";item.status="failed";
      this.outcomes.set(app,{status:"failed",at:this.now()});
    }).finally(()=>{this.active=false;});
    return this.get(id);
  }
}
const shared=globalThis as unknown as {edithActionStore?:ActionStore};
export const actionStore=shared.edithActionStore??(shared.edithActionStore=new ActionStore());
