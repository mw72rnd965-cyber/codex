// Calendar reads do not need inference. Use the Mac's local date arithmetic,
// including 23/25-hour DST days; unfamiliar ranges stay editable rather than guessed.
export function calendarReadRange(message:string,now=new Date()):{start:string;end:string}|null {
  const request=message.trim().toLowerCase().replace(/[’‘]/g,"'").replace(/[?.!]+$/,"");
  const match=/\b(?:calendar|events|schedule|meetings|agenda)\b(.*)$/.exec(request);
  if(!match)return null;
  const range=match[1].trim().replace(/^do i have\s*/,"").replace(/^(?:for|on|over|in|during)\s+/,"").replace(/\s+please$/,"");
  const start=new Date(now),end=new Date(now);
  if(!range||range==="next 7 days"||range==="the next 7 days")end.setDate(end.getDate()+7);
  else if(["today","tomorrow","yesterday"].includes(range)){
    start.setHours(0,0,0,0);start.setDate(start.getDate()+(range==="tomorrow"?1:range==="yesterday"?-1:0));
    end.setTime(start.getTime());end.setDate(end.getDate()+1);
  }else if(range==="this week"||range==="next week"){
    start.setHours(0,0,0,0);start.setDate(start.getDate()-(start.getDay()+6)%7+(range==="next week"?7:0));
    end.setTime(start.getTime());end.setDate(end.getDate()+7);
  }else return null;
  return {start:start.toISOString(),end:end.toISOString()};
}
