import { readFile,stat } from "node:fs/promises";
import { join } from "node:path";
import { z } from "zod";
import type { ActionPhase } from "../actions";
import { ActionError } from "./action-store";

const progressSchema=z.object({phase:z.enum(["starting","permission","reading","saving"])}).strict();
export const macReplySchema=z.object({ok:z.boolean(),text:z.string().max(12000).optional(),code:z.enum(["permission","permission_timeout","account","timeout","native"]).optional()}).strict();
async function readJson(path:string,limit:number){
  try {
    if((await stat(path)).size>limit)throw new ActionError("The Mac helper returned an invalid response. Check the Mac app before retrying.");
    const bytes=await readFile(path);if(bytes.length>limit)throw new ActionError("The Mac helper returned an invalid response. Check the Mac app before retrying.");
    return JSON.parse(bytes.toString("utf8")) as unknown;
  }catch(error){if((error as NodeJS.ErrnoException).code==="ENOENT")return undefined;throw error;}
}
// A result receipt is the completion signal. Launch Services' app-exit signal
// can arrive much later and must not hold a completed Calendar read open.
export async function waitForMacResult(dir:string,onProgress:(phase:ActionPhase)=>void=()=>{},options:{timeoutMs?:number;startupMs?:number;pollMs?:number}={}) {
  const began=Date.now();let phase:ActionPhase|undefined;
  while(Date.now()-began<(options.timeoutMs??135000)){
    const raw=await readJson(join(dir,"result.json"),50000);
    if(raw!==undefined){const parsed=macReplySchema.safeParse(raw);if(!parsed.success)throw new ActionError("The Mac helper did not return a valid result. Check the app before retrying.");return parsed.data;}
    const progress=progressSchema.safeParse(await readJson(join(dir,"progress.json"),1000));
    if(progress.success&&phase!==progress.data.phase){phase=progress.data.phase;onProgress(phase);}
    if((!phase||phase==="starting")&&Date.now()-began>(options.startupMs??20000))throw new ActionError("EDITH Actions did not finish starting. Reopen EDITH with the Mac launcher. Check the Mac app before retrying an action that changes anything.");
    await new Promise(resolve=>setTimeout(resolve,options.pollMs??200));
  }
  if(phase==="permission")return {ok:false,code:"permission_timeout" as const};
  throw new ActionError("The Mac app did not return a result. Check Calendar, Reminders or Mail before trying again.");
}
