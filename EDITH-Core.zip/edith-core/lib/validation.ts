import { z } from "zod";
export const chatSchema = z.object({
  messages: z.array(z.object({ role: z.enum(["user", "assistant"]), content: z.string().trim().min(1).max(8000) }).strict()).min(1).max(20)
}).strict().superRefine(({ messages }, ctx) => {
  if (messages[0]?.role !== "user" || messages.at(-1)?.role !== "user" || messages.some((m, i) => i > 0 && m.role === messages[i - 1].role))
    ctx.addIssue({ code: "custom", message: "Conversation must alternate, starting and ending with a user message." });
  if (messages.reduce((n, m) => n + m.content.length, 0) > 24000)
    ctx.addIssue({ code: "custom", message: "Conversation is too long." });
});
