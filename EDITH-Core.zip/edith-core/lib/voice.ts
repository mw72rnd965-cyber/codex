export type RecognitionResult = { isFinal: boolean; 0: { transcript: string } };
export type Recognition = {
  lang: string; interimResults: boolean; continuous: boolean;
  onresult: ((event: { results: ArrayLike<RecognitionResult> }) => void) | null;
  onerror: ((event: { error: string }) => void) | null;
  onend: (() => void) | null; start(): void; stop(): void; abort(): void;
};
export function recognitionConstructor() {
  const w = window as unknown as { SpeechRecognition?: new () => Recognition; webkitSpeechRecognition?: new () => Recognition };
  return w.SpeechRecognition || w.webkitSpeechRecognition;
}
export function cleanSpeech(text: string) {
  return text.replace(/```[\s\S]*?```/g, " Code omitted. ").replace(/https?:\/\/\S+/g, "").replace(/\[\d+\]/g, "").replace(/[*_#`]/g, "").slice(0, 6000);
}
export class Voice {
  context: AudioContext | null = null;
  source: AudioBufferSourceNode | null = null;
  analyser: AnalyserNode | null = null;
  utterance: SpeechSynthesisUtterance | null = null;
  animation = 0;
  cancelPending: (() => void) | null = null;
  onLevel: (level: number) => void;
  constructor(onLevel: (level: number) => void) { this.onLevel = onLevel; }
  unlock() {
    if (!this.context && typeof AudioContext !== "undefined") this.context = new AudioContext();
    if (this.context?.state === "suspended") void this.context.resume().catch(() => {});
    // Called only from a user gesture. No audible automatic playback.
    if (this.context) { const source = this.context.createBufferSource(); source.buffer = this.context.createBuffer(1, 1, this.context.sampleRate); source.connect(this.context.destination); source.start(); }
  }
  stop() {
    cancelAnimationFrame(this.animation);
    if (this.utterance) window.speechSynthesis?.cancel();
    this.cancelPending?.(); this.cancelPending = null;
    try { this.source?.stop(); } catch {}
    this.source?.disconnect(); this.source = null;
    this.analyser?.disconnect(); this.analyser = null;
    this.utterance = null; this.onLevel(0);
  }
  async play(text: string, generated: boolean, signal: AbortSignal, started: () => void) {
    const speech = cleanSpeech(text);
    if (!speech.trim() || signal.aborted) return;
    if (generated) {
      const response = await fetch("/api/speech", {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({text:speech}),signal});
      if (!response.ok) throw new Error("Generated voice is unavailable. Your answer is available as text.");
      if (!this.context) throw new Error("Enable voice with a click to allow audio playback.");
      const buffer = await this.context.decodeAudioData(await response.arrayBuffer());
      if (signal.aborted) return;
      await this.context.resume();
      if (this.context.state !== "running") throw new Error("Your browser blocked audio. Toggle voice and try again.");
      const source = this.context.createBufferSource(); this.source = source; source.buffer = buffer;
      const analyser = this.context.createAnalyser(); this.analyser = analyser; analyser.fftSize=256;
      source.connect(analyser); analyser.connect(this.context.destination);
      const samples = new Uint8Array(analyser.fftSize);
      const animate = () => { analyser.getByteTimeDomainData(samples); const rms = Math.sqrt(samples.reduce((sum,v)=>sum+((v-128)/128)**2,0)/samples.length); this.onLevel(Math.min(1,rms*4)); this.animation=requestAnimationFrame(animate); };
      await new Promise<void>((resolve) => {
        const done = () => { signal.removeEventListener("abort",abort); cancelAnimationFrame(this.animation); this.onLevel(0); this.cancelPending=null; resolve(); };
        const abort = () => { try { source.stop(); } catch {} done(); };
        this.cancelPending=done; source.onended=done; signal.addEventListener("abort",abort,{once:true});
        source.start(); started(); animate();
      });
      source.disconnect(); analyser.disconnect(); this.source=null; this.analyser=null;
      return;
    }
    if (!("speechSynthesis" in window) || typeof SpeechSynthesisUtterance === "undefined") throw new Error("Voice isn’t supported here. Your answer is available as text.");
    const utterance=new SpeechSynthesisUtterance(speech); this.utterance=utterance;
    utterance.lang="en-US"; utterance.rate=0.96; utterance.pitch=1.02;
    const voices=window.speechSynthesis.getVoices();
    utterance.voice=voices.find(v=>v.lang.startsWith("en") && /Samantha|Aria|Jenny|Google US English/.test(v.name)) || voices.find(v=>v.lang.startsWith("en")) || null;
    await new Promise<void>((resolve,reject)=>{
      let finished=false; let began=false;
      const timer=setTimeout(()=>done(new Error("Voice did not finish. Your answer is available as text.")),120000);
      const startTimer=setTimeout(()=>{ if(!began) { window.speechSynthesis.cancel(); done(new Error("Your browser blocked voice playback. Your answer is available as text.")); } },8000);
      const done=(error?:Error)=>{if(finished)return;finished=true;clearTimeout(timer);clearTimeout(startTimer);cancelAnimationFrame(this.animation);this.onLevel(0);signal.removeEventListener("abort",abort);this.cancelPending=null;this.utterance=null; if(error)reject(error);else resolve();};
      const abort=()=>{window.speechSynthesis.cancel();done();};
      this.cancelPending=()=>done(); signal.addEventListener("abort",abort,{once:true});
      utterance.onstart=()=>{began=true;started();const at=performance.now();const animate=()=>{ const t=(performance.now()-at)/1000; this.onLevel(0.24+0.35*Math.pow(Math.sin(t*8),2)+0.16*Math.sin(t*19)); this.animation=requestAnimationFrame(animate); };animate();};
      utterance.onend=()=>done(); utterance.onerror=()=>{ if(signal.aborted) done(); else done(new Error("Voice playback failed. Your answer is available as text.")); };
      window.speechSynthesis.speak(utterance);
    });
  }
  dispose() { this.stop(); void this.context?.close().catch(()=>{}); this.context=null; }
}
