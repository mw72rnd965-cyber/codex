import type { Phase } from "./protocol";
export type Machine = { phase: Phase; error: string | null };
export type Action =
  | { type: "LISTEN" | "SUBMIT" | "SPEAK" | "FINISH" | "STOP" | "EDIT" }
  | { type: "FAIL"; message: string };
export const initialMachine: Machine = { phase: "idle", error: null };
export function machine(state: Machine, action: Action): Machine {
  switch (action.type) {
    case "LISTEN": return state.phase === "idle" || state.phase === "error" ? { phase: "listening", error: null } : state;
    case "SUBMIT": return state.phase !== "thinking" && state.phase !== "speaking" ? { phase: "thinking", error: null } : state;
    case "SPEAK": return state.phase === "thinking" ? { phase: "speaking", error: null } : state;
    case "FINISH": return { phase: "idle", error: null };
    case "STOP": return { phase: "idle", error: null };
    case "FAIL": return { phase: "error", error: action.message };
    case "EDIT": return state.phase === "error" ? { phase: "idle", error: null } : state;
  }
}
