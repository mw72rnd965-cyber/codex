export type Phase = "idle" | "listening" | "thinking" | "speaking" | "error";
export type Message = { role: "user" | "assistant"; content: string };
export type Configuration = { mode: "demo" | "live"; transcription: boolean; speech: boolean; provider?: "ollama"; model?: string; available?: boolean; research?: boolean };
export type Source = { id:number;title:string;url:string;publisher:string;retrievedAt:string };
export type ResearchEvent = {type:"research";status:"searching"|"reading"|"complete"|"unavailable"|"skipped"|"disabled";sources:Source[]};
export type StreamEvent =
  | { type: "meta"; mode: "demo" | "live" }
  | { type: "delta"; text: string }
  | { type: "done" }
  | ResearchEvent
  | { type: "error"; message: string };
export async function readEvents(response: Response, receive: (event: StreamEvent) => void) {
  if (!response.body) throw new Error("No response stream. Please try again.");
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  let completed = false;
  function line(value: string) {
    if (!value.trim()) return;
    const event = JSON.parse(value) as StreamEvent;
    if (event.type === "error") throw new Error(event.message);
    if (event.type === "done") completed = true;
    receive(event);
  }
  try {
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      let index: number;
      while ((index = buffer.indexOf("\n")) >= 0) {
        line(buffer.slice(0, index)); buffer = buffer.slice(index + 1);
      }
    }
    buffer += decoder.decode();
    if (buffer.trim()) line(buffer);
    if (!completed) throw new Error("The connection ended early. Please retry.");
  } finally { await reader.cancel().catch(() => {}); reader.releaseLock(); }
}
