import { z } from "zod";
import { client, configuration, safeError } from "@/lib/server/model";
import { jsonError, sameOrigin } from "@/lib/server/http";
export const runtime = "nodejs";
const schema = z.object({ text: z.string().trim().min(1).max(6000) }).strict();
export async function POST(request: Request) {
  if (!sameOrigin(request)) return jsonError("Use the EDITH app.",403);
  if (!configuration().speech) return jsonError("Generated voice is not configured. Use browser voice.",503);
  const raw = await request.text();
  if (raw.length > 30000) return jsonError("Speech text is too long.",413);
  let data; try { data = schema.safeParse(JSON.parse(raw)); } catch { return jsonError("Invalid speech request.",400); }
  if (!data.success) return jsonError("Use a shorter speech request.",400);
  try {
    const response = await client().audio.speech.create({model:process.env.EDITH_TTS_MODEL!, voice:(process.env.EDITH_TTS_VOICE || "alloy") as "alloy", input:data.data.text, response_format:"mp3"}, {signal:request.signal});
    return new Response(response.body,{headers:{"Content-Type":"audio/mpeg","Cache-Control":"no-store"}});
  } catch(error) { return jsonError(safeError(error),502); }
}
