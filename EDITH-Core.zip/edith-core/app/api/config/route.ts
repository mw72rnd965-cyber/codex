import { configuration } from "@/lib/server/model";
import { ollamaAvailable } from "@/lib/server/ollama";
export const dynamic = "force-dynamic";
export async function GET() {
  const config=configuration();
  if(config.provider==="ollama")config.available=await ollamaAvailable();
  return Response.json(config, { headers: { "Cache-Control": "no-store" } });
}
