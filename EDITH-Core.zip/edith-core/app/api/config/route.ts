import { configuration } from "@/lib/server/model";
export const dynamic = "force-dynamic";
export function GET() { return Response.json(configuration(), { headers: { "Cache-Control": "no-store" } }); }
