import { chatSchema } from "@/lib/validation";
import { configuration, defaultPrompt, safeError, tokens } from "@/lib/server/model";
import { research,groundedPrompt } from "@/lib/server/research";
import { jsonError, sameOrigin } from "@/lib/server/http";
import type { StreamEvent } from "@/lib/protocol";
import { actionIntent } from "@/lib/actions";
import { prepareAction } from "@/lib/server/action-planner";
import { capabilityReply } from "@/lib/server/capabilities";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export async function POST(request: Request) {
  if (!sameOrigin(request)) return jsonError("Please send requests from the EDITH app.", 403);
  if (!request.headers.get("content-type")?.includes("application/json")) return jsonError("Send a JSON conversation.", 415);
  // Bound input before parsing, including chunked requests without a Content-Length.
  let raw = "";
  if (!request.body) return jsonError("A message is required.", 400);
  const reader = request.body.getReader(); const decoder = new TextDecoder(); let bytes = 0;
  try {
    while (true) {
      const {value, done} = await reader.read(); if (done) break;
      bytes += value.byteLength;
      if (bytes > 110000) { await reader.cancel(); return jsonError("This conversation is too large. Start a new session.", 413); }
      raw += decoder.decode(value, {stream:true});
    }
    raw += decoder.decode();
  } catch { return jsonError("The request was interrupted. Please retry.", 400); }
  finally { reader.releaseLock(); }
  let input: unknown;
  try { input = JSON.parse(raw); } catch { return jsonError("Send a valid conversation.", 400); }
  const parsed = chatSchema.safeParse(input);
  if (!parsed.success) return jsonError("Use a message of 1–8,000 characters and a shorter conversation.", 400);
  const controller = new AbortController();
  const abort = () => controller.abort();
  request.signal.addEventListener("abort", abort, {once:true});
  // Local models may need more time to load on a laptop's first request.
  const timeout = setTimeout(abort, process.env.AI_PROVIDER === "ollama" ? 180000 : 60000);
  const encoder = new TextEncoder();
  const body = new ReadableStream<Uint8Array>({
    async start(stream) {
      const send = (event: StreamEvent) => stream.enqueue(encoder.encode(JSON.stringify(event)+"\n"));
      try {
        send({type:"meta",mode:configuration().mode});
        const capability=capabilityReply(parsed.data.messages.at(-1)!.content);
        if(capability){
          send({type:"research",status:"skipped",sources:[]});
          send({type:"delta",text:capability});send({type:"done"});return;
        }
        const intent=actionIntent(parsed.data.messages.at(-1)!.content);
        if(intent){
          send({type:"research",status:"skipped",sources:[]});
          const proposal=await prepareAction(intent,parsed.data.messages.at(-1)!.content,controller.signal);
          send({type:"action",proposal});
          send({type:"delta",text:"Review the details below. Nothing has been read, changed or sent yet."});send({type:"done"});return;
        }
        const result=configuration().mode==="live"?await research(parsed.data.messages,controller.signal,send):{status:"disabled" as const,sources:[]};
        if(result.status==="skipped"||result.status==="disabled")send({type:"research",status:result.status,sources:[]});
        const prompt=groundedPrompt(process.env.EDITH_SYSTEM_PROMPT||defaultPrompt,result);
        // Make room for retrieved evidence while keeping recent completed turns.
        let messages=parsed.data.messages;
        if(result.sources.length){while(messages.length>1&&messages.reduce((n,m)=>n+m.content.length,0)>16000)messages=messages.slice(2);}
        for await (const text of tokens(messages, controller.signal,prompt)) send({type:"delta",text});
        send({type:"done"});
      } catch (error) {
        try { send({type:"error",message:controller.signal.aborted ? "The response took too long. Please retry." : safeError(error)}); } catch {}
      } finally {
        clearTimeout(timeout); request.signal.removeEventListener("abort",abort);
        try { stream.close(); } catch {}
      }
    },
    cancel() { controller.abort(); clearTimeout(timeout); request.signal.removeEventListener("abort",abort); }
  });
  return new Response(body,{headers:{"Content-Type":"application/x-ndjson; charset=utf-8","Cache-Control":"no-store, no-transform","X-Accel-Buffering":"no"}});
}
