import { z } from "zod";
import { actionStore,ActionError,fieldsSchema } from "@/lib/server/action-store";
import { actionsAvailable } from "@/lib/server/action-planner";
import { runMacAction } from "@/lib/server/mac-native";
import { jsonError,localActionRequest } from "@/lib/server/http";
export const runtime="nodejs";
export const dynamic="force-dynamic";
const idSchema=z.string().regex(/^[a-f0-9]{48}$/);
// Native access is restricted to the actual loopback app, including protection
// against a public hostname being rebound to 127.0.0.1.
const headers={"Cache-Control":"no-store"};
function errorResponse(error:unknown){return jsonError(error instanceof ActionError?error.message:"Action details are invalid.",400);}
async function body(request:Request){
  if(!request.headers.get("content-type")?.includes("application/json"))throw new ActionError("Send JSON action details.");
  if(!request.body)throw new ActionError("Action details are required.");
  const reader=request.body.getReader();let bytes=0;const chunks:Uint8Array[]=[];
  try{while(true){const next=await reader.read();if(next.done)break;bytes+=next.value.byteLength;if(bytes>50000){await reader.cancel();throw new ActionError("Action details are too large.");}chunks.push(next.value);}}finally{reader.releaseLock();}
  return JSON.parse(Buffer.concat(chunks).toString("utf8"));
}
export async function GET(request:Request){
  if(!localActionRequest(request))return jsonError("Open actions from your local EDITH app.",403);
  try{const id=idSchema.parse(new URL(request.url).searchParams.get("id"));return Response.json(actionStore.get(id),{headers});}catch(error){return errorResponse(error);}
}
export async function POST(request:Request){
  if(!localActionRequest(request))return jsonError("Confirm actions inside your local EDITH app.",403);
  if(!actionsAvailable())return jsonError("Native actions need the Mac download and local Ollama.",503);
  try{
    const input=z.object({id:idSchema,fields:fieldsSchema}).strict().parse(await body(request));
    return Response.json(actionStore.confirm(input.id,input.fields,runMacAction),{status:202,headers});
  }catch(error){return errorResponse(error);}
}
export async function DELETE(request:Request){
  if(!localActionRequest(request))return jsonError("Cancel actions inside your local EDITH app.",403);
  try{const input=z.object({id:idSchema}).strict().parse(await body(request));return Response.json(actionStore.cancel(input.id),{headers});}catch(error){return errorResponse(error);}
}
