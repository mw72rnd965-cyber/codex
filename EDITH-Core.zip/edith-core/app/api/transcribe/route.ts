import { client, configuration, safeError } from "@/lib/server/model";
import { jsonError, sameOrigin } from "@/lib/server/http";
export const runtime = "nodejs";
export async function POST(request: Request) {
  if (!sameOrigin(request)) return jsonError("Use the EDITH app.",403);
  if (!configuration().transcription) return jsonError("Server transcription is not configured. Use browser dictation or type.",503);
  const size=Number(request.headers.get("content-length"));
  if (!size || size > 11000000) return jsonError("Recording is too large. Keep it under one minute.",413);
  try {
    const form=await request.formData(); const file=form.get("audio");
    if (!(file instanceof File) || file.size > 10000000 || !file.size || !/^(audio\/(webm|mp4|ogg|wav)|video\/webm)/.test(file.type)) return jsonError("Use a supported audio recording.",400);
    const text=await client().audio.transcriptions.create({file,model:process.env.EDITH_TRANSCRIPTION_MODEL!},{signal:request.signal});
    return Response.json({text:text.text},{headers:{"Cache-Control":"no-store"}});
  } catch(error) { return jsonError(safeError(error),502); }
}
