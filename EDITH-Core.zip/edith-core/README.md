# EDITH

A quiet, conversational assistant: one luminous particle core, one glass input bar, and the current answer. Built with Next.js, TypeScript, Tailwind CSS and Three.js. This is the new minimal EDITH project; the older dashboard package is separate.

## Run

### One-command Mac startup

Paste this into Terminal and press Enter. It works from any folder and opens EDITH in your browser automatically:

```sh
curl -fsSL https://raw.githubusercontent.com/mw72rnd965-cyber/codex/edith-core-download/start-edith.sh -o /tmp/edith-start.command && /bin/bash /tmp/edith-start.command
```

Alternatively, double-click the included **Start EDITH.command**. Install [Ollama](https://ollama.com/download/mac) first. The launcher opens Ollama, chooses an installed local chat model, and loads it before opening EDITH. Embedding models, image-only Moondream, and cloud-backed models are excluded. If there is no local chat model, it downloads Qwen2.5 3B (about 2 GB) through Ollama. No API key is needed. An optional `EDITH_MODEL` environment variable selects a specific local model.

The launcher checks the repository's release manifest, downloads the app from an immutable GitHub commit, verifies its SHA-256, and keeps it in `~/Library/Application Support/EDITH Core`. If Node.js 24+ is absent, it installs the official pinned Node runtime locally after verifying its SHA-256. No administrator access or folder selection is needed. Repeat launches reuse the setup and open a running copy only when it uses the current release and selected Ollama model. An older copy remains intact; the new version uses another free port. The browser opens after the app and selected model pass readiness checks. Keep Terminal open; Control-C stops the app server this launcher started, while the Ollama app remains available. Existing `.env.local` preferences are retained privately across updates.

The launcher syntax and download/setup/startup/reuse/cleanup flow were checked in Linux with Mac OS detection and browser-opening fixtures. Physical macOS execution still needs validation on a Mac.

### Manual startup / other platforms

Requires Node.js 24+ with npm.

```sh
cd /workspace/edith-core
npm ci --cache /workspace/.npm-cache
cp .env.example .env.local # first setup only; preserve existing configuration
npm run dev
```

The app binds to loopback on port 3001. Stop a running server before rebuilding. For production, run `npm run build` followed by `npm start`. On another machine, change the directory to the folder where you extracted the project. Each cloud task already has an isolated workspace; use existing checkouts rather than creating a Git worktree.

Manual startup defaults to demo mode unless configured. Demo mode shows **DEMO · SIMULATED RESPONSES** and streams deterministic examples, including session-context follow-ups. It does not perform model reasoning. The Mac launcher configures local Ollama instead, labeled **LOCAL AI · OLLAMA**. Voice is off initially; use the volume button to enable it.

## Connect a model

Set these server-only variables in `.env.local` or your environment settings, then restart:

| Variable | Purpose |
| --- | --- |
| `AI_PROVIDER` | `ollama` uses a local model without a key. `demo` forces the demo; `auto` or `openai-compatible` uses a cloud model when a key and model are present. Missing cloud configuration falls back to visibly labeled demo mode. Ollama failures report an error and never silently switch to demo. |
| `AI_BASE_URL` | OpenAI-compatible API endpoint; defaults to `https://api.openai.com/v1`. HTTPS is required except for a loopback model server. |
| `AI_API_KEY` | Provider credential. Never put it in a `NEXT_PUBLIC_*` variable or client code. |
| `AI_MODEL` | Model identifier provided by your API provider; no model name is built into the application. |
| `OLLAMA_BASE_URL` | Native Ollama API address, default `http://127.0.0.1:11434`. Only loopback addresses are accepted. |
| `EDITH_SYSTEM_PROMPT` | Optional replacement for the concise, calm, capability-aware default prompt. |
| `RESEARCH_MODE` | Defaults to `auto`: factual questions retrieve public sources before the model answers. `off` explicitly disables research. Demo mode never searches. |
| `EDITH_TRANSCRIPTION_MODEL` | Optional audio-transcription model supported by the same API. |
| `EDITH_TTS_MODEL` | Optional speech-generation model supported by the same API. |
| `EDITH_TTS_VOICE` | Provider voice identifier; defaults to `alloy`. |

The server adapter uses the official [OpenAI Node SDK](https://github.com/openai/openai-node), its streaming Chat Completions API, and request AbortSignals. OpenAI-compatible providers must support streaming Chat Completions and `max_completion_tokens`. Audio routes use the SDK's transcription and speech APIs. Calls use the same server-side key and base URL. No key, endpoint, or internal provider error is returned to the browser. Add the provider hostname to restricted cloud network settings when connecting it. Paid inference and audio have not been exercised without credentials.

For manual Ollama setup, run Ollama and put `AI_PROVIDER=ollama`, `AI_MODEL=your-installed-model` and `OLLAMA_BASE_URL=http://127.0.0.1:11434` in `.env.local`, then restart EDITH. The native [Ollama API](https://github.com/ollama/ollama/blob/main/docs/api.md) streams chat without an Authorization header. Model inference stays on the local machine; web research sends search keywords to public search services as described below. Thinking is disabled and internal thinking fields are excluded from captions. The model stays loaded for ten minutes, uses an 8,192-token context window, and allows up to 1,200 generated tokens. Model loading can take longer on the first request; stopping aborts the upstream request. The connection label reports when Ollama or the selected model is offline. Ollama mode uses browser speech/recognition; Ollama does not provide the cloud audio endpoints.

The app is intended for a single user's local session. Keep the loopback binding unless adding authentication and abuse controls for deployment. Conversation and audio are not stored by this app; configured providers, search services and browser speech vendors have their own processing policies. No account, device, camera or action integrations are included.

## Automatic research and sources

With a live model, factual questions trigger a **Searching the web → Reading sources** stage before generation. EDITH searches Bing's public RSS endpoint, falls back to DuckDuckGo HTML, and reads up to three accessible HTTPS pages, preferring government, education and scientific sites. The Wikipedia article API supplies fallback article text when search pages are blocked or unreadable. No search API key is required. These public endpoints can change or rate-limit; they are not guaranteed search APIs.

Ollama receives the retrieved excerpts and a numbered source catalog. The prompt asks it to cite factual claims with `[1]`, `[2]` and `[3]`, qualify incomplete evidence, and treat page content as data rather than instructions. Citation numbers link only to sources EDITH retrieved; an invented number has no link. **Sources read** chips beneath the answer let you inspect those pages even if the model omits an inline citation. Reading a page does not establish that every claim on it is accurate, and small local models can misinterpret evidence. Consult the linked sources for important decisions. EDITH reads excerpts, not necessarily every section of a page.

If no readable sources are found, EDITH reports that research is unavailable, preserves your question, and offers Retry before asking the model to answer. Greetings, session-memory questions and requests to rewrite, translate or create text skip web research. Demo mode is explicitly simulated and never produces research citations. `RESEARCH_MODE=off` is available for intentional offline use; the research badge disappears.

Search keywords come from your current question and, for short follow-ups, the preceding user topic. Common API-key patterns, code blocks and email addresses are removed, but this is not a general privacy filter: do not include sensitive personal details in a research question. Search keywords and source URLs go to those public websites. The source reader sends no provider credentials or browser cookies, executes no page scripts, limits size/time/redirects, and rejects private network addresses. Stop cancels research and generation.

The Mac uses its own internet connection. Restricted cloud environments need the search hostnames `www.bing.com`, `html.duckduckgo.com` and `en.wikipedia.org`, plus any source hostnames, in their network settings. The saved cloud draft includes those search hosts and NASA's source hosts; review, save and publish the draft to apply it. Initial live requests were blocked in this cloud; later checks reached Bing RSS and Wikipedia, while DuckDuckGo returned a challenge page. The production app successfully retrieved real Wikipedia telescope articles, and a direct check confirmed that the evidence included Webb's infrared observations. Retrieval, grounding, citations and failure behavior also passed controlled page/model tests. Live inference on the user's Mac still requires that device; the cloud's Ollama API was a test fixture.

## Interaction and voice

- Enter sends; Shift+Enter adds a line. Escape or the square button cancels generation, dictation and playback. Empty and duplicate submissions are rejected. A failed request preserves the draft and offers Retry.
- The state machine is `idle → listening → thinking → speaking → idle`, with error, cancellation, and typed-input paths. Typed input and disabled voice may skip the listening/speaking stages.
- Only the current response is visible. It streams as plain text, scrolls for long answers, then fades after 12–45 seconds of inactivity. The message icon inside the bar recalls it.
- Context stays in memory for the current tab: at most the latest nine completed exchanges plus the next message, bounded to 24,000 characters. Refreshing clears it. Interrupted or failed answers are not committed to context.
- Microphone permission is requested only after activating the microphone. The core enters listening after access succeeds. Volume is sampled with a smoothed audio analyser. Dictation submits on completion, or when the microphone is tapped again. The stop button cancels it. Tracks and audio contexts are released on completion, cancellation and unmount. Recordings are limited to one minute and 10 MB.
- If server transcription is configured, MediaRecorder uploads the recording to `/api/transcribe`. Otherwise the browser's SpeechRecognition API is used where available. Browser recognition may use a vendor service; some browsers do not support it. Denied permission and unavailable speech leave typed input usable. HTTPS or loopback is required for microphone access.
- If server speech is configured, generated audio drives core motion through a real Web Audio analyser. Otherwise browser speech synthesis is used. **Browser synthesis has no audio stream available to Web Audio, so its amplitude animation is a smooth approximation**, not a measured waveform. Native voice choice and behavior vary by browser/OS. Playback only follows user interaction and can be interrupted; autoplay failures keep the text answer available.

## Rendering and accessibility

The core uses a particle shell, flowing internal filaments, fine orbital lines and a soft central glow. States change color, orbital speed and amplitude. Smaller devices use fewer particles; pixel ratio is capped at 1.5. Animation stops in hidden tabs. A lightweight Canvas sphere takes over if WebGL cannot initialize or its context is lost. Reduced motion removes rotation, scale changes and flashes while keeping state colors and text feedback.

Styles in `app/globals.css` define the palette, spacing, core size and glow. The input follows the visual viewport above mobile keyboards. Controls have accessible names and focus indicators; status changes are announced without announcing every streamed token. Responses are escaped plain text, not executable HTML. Resources, microphone tracks, animation loops and event listeners are cleaned up.

## Verify

```sh
npm run lint
npm run typecheck
npm test
npm run build
# Start a server on port 3001, then:
npm run test:browser
```

The browser suite uses `/usr/bin/chromium`; set `CHROMIUM_PATH` to an installed Chromium/Chrome executable on another machine. Tests use fake microphone input and controlled native speech adapters: they validate permission handling, cleanup, state transitions and cancellation, rather than claiming recognition accuracy or audible output on a physical device. Provider streaming is tested against local OpenAI-compatible and native Ollama fixtures, including cancellation, reasoning exclusion, missing models, installed-model selection and first-model downloads. Research tests cover retrieved page evidence, fallback, unavailable sources, private-address rejection, safe extraction, registered citations and mobile source placement. Model inference on the user's Mac and physical microphone/speaker behavior require validation on that device; paid cloud inference/transcription/TTS also need credentials.

Modules: `components/Assistant.tsx` and `useAssistant.ts` control the screen and conversation; `Core.tsx` renders it; `lib/machine.ts` defines transitions; `lib/voice.ts` handles speech; `lib/server/model.ts` handles the model; `app/api` contains chat, configuration and optional audio routes. There is no database or transcript persistence.
