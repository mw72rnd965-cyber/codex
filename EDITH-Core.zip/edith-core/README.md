# EDITH

A quiet, conversational assistant: one luminous particle core, one glass input bar, and the current answer. Built with Next.js, TypeScript, Tailwind CSS and Three.js. This is the new minimal EDITH project; the older dashboard package is separate.

## Run

### One-command Mac startup

Paste this into Terminal and press Enter. It works from any folder and opens EDITH in your browser automatically:

```sh
curl -fsSL https://raw.githubusercontent.com/mw72rnd965-cyber/codex/edith-core-download/start-edith.sh -o /tmp/edith-start.command && /bin/bash /tmp/edith-start.command
```

Alternatively, double-click the included **Start EDITH.command**. The launcher downloads the app from an immutable GitHub commit, verifies its SHA-256, and keeps it in `~/Library/Application Support/EDITH Core`. If Node.js 24+ is absent, it installs the official pinned Node runtime locally after verifying its SHA-256. No administrator access or folder selection is needed. Repeat launches reuse the setup and open an already-running copy. The app binds to a free loopback port and opens your browser only after checking readiness. Keep Terminal open; Control-C stops the server this launcher started. Local `.env.local` files are preserved.

The launcher syntax and download/setup/startup/reuse/cleanup flow were checked in Linux with Mac OS detection and browser-opening fixtures. Physical macOS execution still needs validation on a Mac.

### Manual startup / other platforms

Requires Node.js 24+ with npm.

```sh
cd /workspace/edith-core
npm ci --cache /workspace/.npm-cache
cp .env.example .env.local # first setup only; preserve existing configuration
npm run dev
```

The app binds to loopback on port 3001. Stop a running server before rebuilding. For production, run `npm run build` followed by `npm start`. On another machine, change the directory to the folder where you extracted the project. Each cloud task already has an isolated workspace; use existing checkouts rather than creating a Git worktree.

No credentials are needed to test the complete interaction. Demo mode shows **DEMO · SIMULATED RESPONSES** and streams deterministic examples, including session-context follow-ups. It does not perform model reasoning. Voice is off initially; use the volume button to enable it.

## Connect a model

Set these server-only variables in `.env.local` or your environment settings, then restart:

| Variable | Purpose |
| --- | --- |
| `AI_PROVIDER` | `demo` forces the demo; `auto` or `openai-compatible` uses a model when a key and model are present. Missing configuration falls back to visibly labeled demo mode. |
| `AI_BASE_URL` | OpenAI-compatible API endpoint; defaults to `https://api.openai.com/v1`. HTTPS is required except for a loopback model server. |
| `AI_API_KEY` | Provider credential. Never put it in a `NEXT_PUBLIC_*` variable or client code. |
| `AI_MODEL` | Model identifier provided by your API provider; no model name is built into the application. |
| `EDITH_SYSTEM_PROMPT` | Optional replacement for the concise, calm, capability-aware default prompt. |
| `EDITH_TRANSCRIPTION_MODEL` | Optional audio-transcription model supported by the same API. |
| `EDITH_TTS_MODEL` | Optional speech-generation model supported by the same API. |
| `EDITH_TTS_VOICE` | Provider voice identifier; defaults to `alloy`. |

The server adapter uses the official [OpenAI Node SDK](https://github.com/openai/openai-node), its streaming Chat Completions API, and request AbortSignals. OpenAI-compatible providers must support streaming Chat Completions and `max_completion_tokens`. Audio routes use the SDK's transcription and speech APIs. Calls use the same server-side key and base URL. No key, endpoint, or internal provider error is returned to the browser. Add the provider hostname to restricted cloud network settings when connecting it. Paid inference and audio have not been exercised without credentials.

The app is intended for a single user's local session. Keep the loopback binding unless adding authentication and abuse controls for deployment. Conversation and audio are not stored by this app; configured providers and browser speech vendors have their own processing policies. No account, device, camera, search, or action integrations are included.

## Interaction and voice

- Enter sends; Shift+Enter adds a line. Escape or the square button cancels generation, dictation and playback. Empty and duplicate submissions are rejected. A failed request preserves the draft and offers Retry.
- The state machine is `idle → listening → thinking → speaking → idle`, with error, cancellation, and typed-input paths. Typed input and disabled voice may skip the listening/speaking stages.
- Only the current response is visible. It streams as plain text, scrolls for long answers, then fades after 12–45 seconds of inactivity. The message icon inside the bar recalls it.
- Context stays in memory for the current tab: at most the latest nine completed exchanges plus the next message, bounded to 24,000 characters. Refreshing clears it. Interrupted or failed answers are not committed to context.
- Microphone permission is requested only after activating the microphone. The core enters listening after access succeeds. Volume is sampled with a smoothed audio analyser. Dictation submits on completion, or when the microphone is tapped again. The stop button cancels it. Tracks and audio contexts are released on completion, cancellation and unmount. Recordings are limited to one minute and 10 MB.
- If server transcription is configured, MediaRecorder uploads the recording to `/api/transcribe`. Otherwise the browser's SpeechRecognition API is used where available. Browser recognition may use a vendor service; some browsers do not support it. Denied permission and unavailable speech leave typed input usable. HTTPS or loopback is required for microphone access.
- If server speech is configured, generated audio drives core motion through a real Web Audio analyser. Otherwise browser speech synthesis is used. **Browser synthesis has no audio stream available to Web Audio, so its amplitude animation is a smooth approximation**, not a measured waveform. Native voice choice and behavior vary by browser/OS. Playback only follows user interaction and can be interrupted; autoplay failures keep the text answer available.

## Rendering and accessibility

The core uses a particle shell, flowing internal filaments, fine orbital lines and a soft central glow. States change color, orbital speed and amplitude. Smaller devices use fewer particles; pixel ratio is capped at 1.5. Animation stops in hidden tabs. A lightweight Canvas sphere takes over if WebGL cannot initialize or its context is lost. Reduced motion removes rotation, scale changes and flashes while keeping state colors and text feedback.

Styles in `app/globals.css` define the palette, spacing, core size and glow. The input follows the visual viewport above mobile keyboards. Controls have accessible names and focus indicators; status changes are announced without announcing every streamed token. Responses are escaped plain text, not executable HTML. Resources, microphone tracks, animation loops and event listeners are cleaned up.

## Verify

```sh
npm run lint
npm run typecheck
npm test
npm run build
# Start a server on port 3001, then:
npm run test:browser
```

The browser suite uses `/usr/bin/chromium`; set `CHROMIUM_PATH` to an installed Chromium/Chrome executable on another machine. Tests use fake microphone input and controlled native speech adapters: they validate permission handling, cleanup, state transitions and cancellation, rather than claiming recognition accuracy or audible output on a physical device. Provider streaming is tested against a local OpenAI-compatible fixture. Live provider inference, paid transcription/TTS, and physical microphone/speaker behavior require an appropriate device or credentials.

Modules: `components/Assistant.tsx` and `useAssistant.ts` control the screen and conversation; `Core.tsx` renders it; `lib/machine.ts` defines transitions; `lib/voice.ts` handles speech; `lib/server/model.ts` handles the model; `app/api` contains chat, configuration and optional audio routes. There is no database or transcript persistence.
