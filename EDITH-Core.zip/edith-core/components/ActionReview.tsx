"use client";
import { useState } from "react";
import { actionLabels,type ActionFields,type ActionStatus } from "@/lib/actions";
function inputDate(value:string){if(!value)return "";const d=new Date(value);if(!Number.isFinite(d.getTime()))return "";return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}T${String(d.getHours()).padStart(2,"0")}:${String(d.getMinutes()).padStart(2,"0")}`;}
function isoDate(value:string){return value?new Date(value).toISOString():"";}
export function ActionReview({action,onConfirm,onCancel,onDismiss}:{action:ActionStatus;onConfirm:(fields:ActionFields)=>Promise<void>;onCancel:()=>Promise<void>;onDismiss:()=>void}) {
  const {kind,fields:original}=action.proposal;
  const [fields,setFields]=useState(original);const [error,setError]=useState("");const [submitting,setSubmitting]=useState(false);
  const pending=action.status==="proposed";const busy=action.status==="running"||submitting;
  const calendar=kind.startsWith("calendar_");const create=kind.endsWith("create");const mail=kind==="mail_draft"||kind==="mail_send";
  function field(key:keyof ActionFields,label:string,required=false,date=false,multiline=false) {
    return <label key={key}>{label}{multiline?<textarea aria-label={label} value={fields[key]} required={required} maxLength={key==="body"?6000:2000} onChange={e=>setFields({...fields,[key]:e.target.value})}/>:<input aria-label={label} type={date?"datetime-local":key==="to"?"email":"text"} value={date?inputDate(fields[key]):fields[key]} required={required} maxLength={key==="to"?320:300} onChange={e=>{try{setFields({...fields,[key]:date?isoDate(e.target.value):e.target.value});}catch{setError("Choose a valid date.");}}}/>}</label>;
  }
  return <section className="action-review" aria-label="Review Mac action">
    <div className="action-heading"><strong>{actionLabels[kind]}</strong><span>YOUR MAC</span></div>
    {pending?<form onSubmit={async e=>{e.preventDefault();setSubmitting(true);setError("");try{await onConfirm(fields);}catch(e){setError(e instanceof Error?e.message:"Please retry.");}finally{setSubmitting(false);}}}>
      {create&&field("title","Title",true)}
      {calendar&&<div className="action-dates">{field("start","Start",true,true)}{field("end","End",true,true)}</div>}
      {kind==="calendar_create"&&field("location","Location")}
      {kind==="reminder_create"&&field("due","Due (optional)",false,true)}
      {create&&field("notes","Notes",false,false,true)}
      {mail&&<>{field("to","Recipient email",true)}{field("subject","Subject",true)}{field("body","Message",true,false,true)}</>}
      <p className="action-detail">{kind==="calendar_create"?"Creates one event in your default Calendar.":kind==="reminder_create"?"Adds one reminder to your default Reminders list.":kind==="mail_read"?"Reads five recent inbox text previews from Mail.":kind==="reminder_read"?"Reads up to ten incomplete reminders.":kind==="mail_draft"?"Opens an editable draft in Mail.":kind==="mail_send"?"Sends through your Mail account after you press Send email.":"Reads events, including recurring occurrences, in this date range."}</p>
      <p className="action-detail">macOS may ask you to allow access.</p>
      {error&&<p className="action-error" role="alert">{error}</p>}
      <div className="action-buttons"><button type="button" disabled={busy} onClick={async()=>{setSubmitting(true);try{await onCancel();}catch(e){setError(e instanceof Error?e.message:"Could not cancel.");}finally{setSubmitting(false);}}}>Cancel action</button><button type="submit" disabled={busy}>{submitting?"Working…":actionLabels[kind]}</button></div>
    </form>:<><p className="action-detail" role="status">{action.status==="running"?"Working on your Mac… Allow access if macOS asks. You can reload this page and EDITH will check the result.":action.status==="completed"?"Completed. The result is shown above.":action.status==="failed"?action.text:"Action cancelled."}</p>{action.status!=="running"&&<div className="action-buttons"><button onClick={onDismiss}>Close action</button></div>}</>}
  </section>;
}
