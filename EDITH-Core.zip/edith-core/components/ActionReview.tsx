"use client";
import { useState } from "react";
import { actionLabels,type ActionFields,type ActionStatus } from "@/lib/actions";
import { CalendarDays,ListChecks,Mail } from "lucide-react";
import { HudPanel } from "./HudPanel";
function inputDate(value:string){if(!value)return "";const d=new Date(value);if(!Number.isFinite(d.getTime()))return "";return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}T${String(d.getHours()).padStart(2,"0")}:${String(d.getMinutes()).padStart(2,"0")}`;}
function isoDate(value:string){return value?new Date(value).toISOString():"";}
export function ActionReview({action,onConfirm,onCancel,onDismiss}:{action:ActionStatus;onConfirm:(fields:ActionFields)=>Promise<void>;onCancel:()=>Promise<void>;onDismiss:()=>void}) {
  const {kind,fields:original}=action.proposal;
  const [fields,setFields]=useState(original);const [error,setError]=useState("");const [submitting,setSubmitting]=useState(false);
  const pending=action.status==="proposed";const busy=action.status==="running"||submitting;
  const calendar=kind.startsWith("calendar_");const create=kind.endsWith("create");const mail=kind==="mail_draft"||kind==="mail_send";
  function field(key:keyof ActionFields,label:string,required=false,date=false,multiline=false) {
    return <label key={key}>{label}{multiline?<textarea aria-label={label} value={fields[key]} required={required} maxLength={key==="body"?6000:2000} onChange={e=>setFields({...fields,[key]:e.target.value})}/>:<input aria-label={label} type={date?"datetime-local":key==="to"?"email":"text"} value={date?inputDate(fields[key]):fields[key]} required={required} maxLength={key==="to"?320:300} onChange={e=>{try{setFields({...fields,[key]:date?isoDate(e.target.value):e.target.value});}catch{setError("Choose a valid date.");}}}/>}</label>;
  }
  const app=calendar?"CALENDAR":kind.startsWith("reminder_")?"REMINDERS":"MAIL";
  const appName=calendar?"Calendar":kind.startsWith("reminder_")?"Reminders":"Mail";
  const permissionUrl=`x-apple.systempreferences:com.apple.preference.security?${calendar?"Privacy_Calendars":appName==="Reminders"?"Privacy_Reminders":"Privacy_Automation"}`;
  const progress=action.phase==="permission"?`Waiting for macOS ${appName} permission. Click Allow in the EDITH Actions prompt.`:action.phase==="reading"?`Reading your ${appName}…`:action.phase==="saving"?`Submitting your confirmed ${appName} action…`:`Connecting to ${appName} on your Mac…`;
  return <HudPanel className="action-review" title={actionLabels[kind]} label={`EDITH / ${app}`} ariaLabel="Review Mac action"
    icon={calendar?<CalendarDays size={20}/>:app==="REMINDERS"?<ListChecks size={20}/>:<Mail size={20}/>}
    tools={<span className={`hud-state ${action.status==="failed"?"hud-state-error":""}`}>{pending?"REVIEW":busy?"WORKING":action.status==="completed"?"COMPLETE":action.status.toUpperCase()}</span>}>
    {pending?<form onSubmit={async e=>{e.preventDefault();setSubmitting(true);setError("");try{await onConfirm(fields);}catch(e){setError(e instanceof Error?e.message:"Please retry.");}finally{setSubmitting(false);}}}>
      {calendar&&<div className="calendar-range" aria-label="Selected calendar date"><CalendarDays size={26}/><div><span>{fields.start&&Number.isFinite(Date.parse(fields.start))?new Date(fields.start).toLocaleDateString(undefined,{weekday:"short",day:"numeric",month:"long"}):"Choose a date"}</span><small>{kind==="calendar_read"?"Your selected date range":"One event · your local time"}</small></div></div>}
      {kind==="calendar_read"&&!fields.start&&<p className="action-detail">Choose the start and end dates before reading Calendar.</p>}
      {create&&field("title","Title",true)}
      {calendar&&<div className="action-dates">{field("start","Start",true,true)}{field("end","End",true,true)}</div>}
      {kind==="calendar_create"&&field("location","Location")}
      {kind==="reminder_create"&&field("due","Due (optional)",false,true)}
      {create&&field("notes","Notes",false,false,true)}
      {mail&&<>{field("to","Recipient email",true)}{field("subject","Subject",true)}{field("body","Message",true,false,true)}</>}
      <p className="action-detail">{kind==="calendar_create"?"Creates one event in your default Calendar.":kind==="reminder_create"?"Adds one reminder to your default Reminders list.":kind==="mail_read"?"Reads five recent inbox text previews from Mail.":kind==="reminder_read"?"Reads up to ten incomplete reminders.":kind==="mail_draft"?"Opens an editable draft in Mail.":kind==="mail_send"?"Sends through your Mail account after you press Send email.":"Reads events, including recurring occurrences, in this date range."}</p>
      <p className="action-detail">macOS may ask you to allow access.</p>
      {error&&<p className="action-error" role="alert">{error}</p>}
      <div className="action-buttons"><button type="button" disabled={busy} onClick={async()=>{setSubmitting(true);try{await onCancel();}catch(e){setError(e instanceof Error?e.message:"Could not cancel.");}finally{setSubmitting(false);}}}>Cancel action</button><button type="submit" disabled={busy}>{submitting?"Working…":actionLabels[kind]}</button></div>
    </form>:<><div className={`action-result ${action.status==="running"?"action-detail":"response-caption"}`} tabIndex={0} aria-label="Mac action result">{action.status==="running"?progress:action.text||"Action cancelled."}</div>{(action.phase==="permission"||action.status==="failed")&&<p className="action-detail"><a className="permission-link" href={permissionUrl}>Open {appName} permissions</a></p>}{action.status!=="running"&&<div className="action-buttons"><button onClick={onDismiss}>Close action</button></div>}</>}
  </HudPanel>;
}
