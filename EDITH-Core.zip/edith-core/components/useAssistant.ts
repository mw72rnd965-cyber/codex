"use client";
import { useCallback, useEffect, useReducer, useRef, useState } from "react";
import { initialMachine, machine } from "@/lib/machine";
import { readEvents, type Configuration, type Message,type Source,type ResearchEvent } from "@/lib/protocol";
import { Voice, recognitionConstructor, type Recognition } from "@/lib/voice";
import type { ActionStatus,ActionFields } from "@/lib/actions";

function boundedHistory(history: Message[], text: string) {
  let kept = history.slice(-18);
  while (kept.reduce((sum,m)=>sum+m.content.length,0)+text.length>24000) kept=kept.slice(2);
  return [...kept,{role:"user" as const,content:text}];
}
export function useAssistant() {
  const [state,dispatch]=useReducer(machine,initialMachine);
  const [config,setConfig]=useState<Configuration|null>(null);
  const [draft,setDraft]=useState("");
  const [caption,setCaption]=useState("");
  const [sources,setSources]=useState<Source[]>([]);
  const [researchStatus,setResearchStatus]=useState<ResearchEvent["status"]>("skipped");
  const [captionVisible,setCaptionVisible]=useState(true);
  const [action,setAction]=useState<ActionStatus|null>(null);
  const actionRef=useRef<ActionStatus|null>(null);
  const [actionRunning,setActionRunning]=useState(false);
  const actionInFlight=useRef(false);
  const [voiceEnabled,setVoiceEnabled]=useState(false);
  const voiceOn=useRef(false);
  const [notice,setNotice]=useState("");
  const [connected,setConnected]=useState(false);
  const [pending,setPending]=useState(false);
  const history=useRef<Message[]>([]);
  const audio=useRef(0);
  const epoch=useRef(0);
  const locked=useRef(false);
  const abort=useRef<AbortController|null>(null);
  const voice=useRef<Voice|null>(null);
  const media=useRef<MediaStream|null>(null);
  const microphoneContext=useRef<AudioContext|null>(null);
  const microphoneFrame=useRef(0);
  const micTimer=useRef<ReturnType<typeof setTimeout>|null>(null);
  const recognition=useRef<Recognition|null>(null);
  const recorder=useRef<MediaRecorder|null>(null);
  const transcript=useRef("");
  const retry=useRef("");
  const retryKind=useRef<"message"|"microphone">("message");
  const activePhase=useRef(state.phase); activePhase.current=state.phase;
  const showAction=useCallback((value:ActionStatus|null)=>{actionRef.current=value;setAction(value);},[]);
  const pollAction=useCallback(async(id:string,ticket:number,controller:AbortController)=>{
    try {
      while(ticket===epoch.current){
        const response=await fetch("/api/actions?id="+encodeURIComponent(id),{headers:{"X-EDITH-Action":"1"},signal:controller.signal,cache:"no-store"});
        const data=await response.json();if(!response.ok)throw new Error(data.error||"Action status unavailable. Check your Mac app before retrying.");
        if(ticket!==epoch.current)return;const current=data as ActionStatus;showAction(current);
        if(current.status!=="running"){
          sessionStorage.removeItem("edith.pendingAction");actionInFlight.current=false;setActionRunning(false);
          if(current.status==="proposed"){setNotice("This action is awaiting your confirmation.");dispatch({type:"FINISH"});return;}
          const text=current.text||"Action cancelled.";setCaption(text);setSources([]);setCaptionVisible(true);
          if(history.current.at(-1)?.role==="assistant")history.current=[...history.current.slice(0,-1),{role:"assistant",content:text}];
          if(voiceOn.current&&current.status==="completed")try{await voice.current?.play(text,false,controller.signal,()=>{if(ticket===epoch.current)dispatch({type:"SPEAK"});});}catch{}
          if(ticket===epoch.current)dispatch({type:"FINISH"});return;
        }
        await new Promise(resolve=>setTimeout(resolve,750));
      }
    }catch(error){if(ticket===epoch.current){setNotice(error instanceof Error?error.message:"Check your Mac app for the action result.");dispatch({type:"FINISH"});}}
    finally{if(ticket===epoch.current){locked.current=false;abort.current=null;actionInFlight.current=false;setActionRunning(false);}}
  },[showAction]);
  const releaseMicrophone=useCallback(()=>{
    if(micTimer.current)clearTimeout(micTimer.current);
    cancelAnimationFrame(microphoneFrame.current);
    if(recognition.current){recognition.current.onend=null;recognition.current.onresult=null;recognition.current.onerror=null;recognition.current.abort();recognition.current=null;}
    if(recorder.current){recorder.current.ondataavailable=null;recorder.current.onstop=null; if(recorder.current.state!=="inactive")recorder.current.stop();recorder.current=null;}
    media.current?.getTracks().forEach(t=>t.stop());media.current=null;
    void microphoneContext.current?.close().catch(()=>{});microphoneContext.current=null;audio.current=0;
  },[]);
  useEffect(()=>{
    const operationEpoch=epoch;
    voice.current=new Voice(level=>{audio.current=level;});
    const controller=new AbortController();
    fetch("/api/config",{signal:controller.signal}).then(r=>{if(!r.ok)throw Error();return r.json();}).then((c:Configuration)=>{setConfig(c);setConnected(true);}).catch(()=>{if(!controller.signal.aborted)setNotice("Connection unavailable. Reload to reconnect.");});
    const pendingId=sessionStorage.getItem("edith.pendingAction");
    if(pendingId){const ticket=++epoch.current;locked.current=true;actionInFlight.current=true;setActionRunning(true);dispatch({type:"SUBMIT"});abort.current=controller;void pollAction(pendingId,ticket,controller);}
    return()=>{++operationEpoch.current;controller.abort();abort.current?.abort();releaseMicrophone();voice.current?.dispose();};
  },[releaseMicrophone,pollAction]);
  useEffect(()=>{
    if(!caption || state.phase!=="idle")return;
    const timer=setTimeout(()=>setCaptionVisible(false),Math.min(45000,12000+caption.length*35));
    return()=>clearTimeout(timer);
  },[caption,state.phase]);
  useEffect(()=>{
    if(!notice)return;const timer=setTimeout(()=>setNotice(""),10000);return()=>clearTimeout(timer);
  },[notice]);
  const stop=useCallback(()=>{
    if(actionInFlight.current){setNotice("This action is already running. EDITH will check its result.");return;}
    ++epoch.current;locked.current=false;abort.current?.abort();abort.current=null;
    voice.current?.stop();releaseMicrophone();setPending(false);dispatch({type:"STOP"});setNotice("Stopped. Ready when you are.");
  },[releaseMicrophone]);
  const submit=useCallback(async(text:string)=>{
    const trimmed=text.trim();
    if(!trimmed || locked.current || !connected)return;
    if(actionRef.current?.status==="proposed"){setNotice("Review or cancel the current action first.");return;}
    if(actionRef.current?.status==="running"){setNotice("This action is awaiting a result. Reload to check it before starting another.");return;}
    if(trimmed.length>8000){dispatch({type:"FAIL",message:"Keep your message under 8,000 characters."});return;}
    releaseMicrophone();voice.current?.stop();voice.current?.unlock();
    const ticket=++epoch.current;locked.current=true;retry.current=trimmed;retryKind.current="message";
    const controller=new AbortController();abort.current=controller;
    const messages=boundedHistory(history.current,trimmed);
    showAction(null);setDraft("");setCaption("");setSources([]);setResearchStatus(config?.research?"searching":"disabled");setCaptionVisible(true);setNotice("");dispatch({type:"SUBMIT"});
    let answer="";
    let proposed=false;
    try {
      const response=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({messages}),signal:controller.signal});
      if(!response.ok){const data=await response.json().catch(()=>({}));throw new Error(data.error||"EDITH couldn’t connect. Please retry.");}
      await readEvents(response,event=>{
        if(ticket!==epoch.current)return;
        if(event.type==="meta")setConfig(c=>c?{...c,mode:event.mode}:c);
        if(event.type==="research"){setSources(event.sources);setResearchStatus(event.status);}
        if(event.type==="action"){proposed=true;showAction({proposal:event.proposal,status:"proposed"});}
        if(event.type==="delta"){answer+=event.text;setCaption(answer);setConfig(c=>c?.provider==="ollama"&&c.available===false?{...c,available:true}:c);}
      });
      if(ticket!==epoch.current)return;
      if(!answer.trim())throw new Error("The provider sent an empty answer. Please retry.");
      history.current=[...messages,{role:"assistant",content:answer}];
      if(voiceOn.current&&!proposed){
        try {await voice.current?.play(answer,config?.speech??false,controller.signal,()=>{if(ticket===epoch.current)dispatch({type:"SPEAK"});});}
        catch(error){if(ticket===epoch.current)setNotice(error instanceof Error?error.message:"Voice unavailable. Your answer is available as text.");}
      }
      if(ticket===epoch.current)dispatch({type:"FINISH"});
    } catch(error) {
      if(ticket!==epoch.current || controller.signal.aborted)return;
      setDraft(trimmed);dispatch({type:"FAIL",message:error instanceof Error?error.message:"Something interrupted the connection. Please retry."});
    } finally {if(ticket===epoch.current){locked.current=false;abort.current=null;}}
  },[config,connected,releaseMicrophone,showAction]);
  async function confirmAction(fields:ActionFields){
    const current=actionRef.current;if(!current||locked.current)throw new Error("Wait for the current response to finish.");
    const ticket=++epoch.current;locked.current=true;actionInFlight.current=true;setActionRunning(true);voice.current?.stop();setNotice("");dispatch({type:"SUBMIT"});
    const controller=new AbortController();abort.current=controller;
    try{
      // Persist only the opaque ID before submitting, so a lost response/reload
      // can recover status without storing private email or calendar contents.
      sessionStorage.setItem("edith.pendingAction",current.proposal.id);
      const response=await fetch("/api/actions",{method:"POST",headers:{"Content-Type":"application/json","X-EDITH-Action":"1"},body:JSON.stringify({id:current.proposal.id,fields}),signal:controller.signal});
      const data=await response.json();if(!response.ok){sessionStorage.removeItem("edith.pendingAction");throw new Error(data.error||"Could not start this action.");}
      showAction(data as ActionStatus);await pollAction(current.proposal.id,ticket,controller);
    }catch(error){if(ticket===epoch.current){locked.current=false;actionInFlight.current=false;setActionRunning(false);dispatch({type:"FINISH"});}throw error;}
  }
  async function cancelAction(){
    const current=actionRef.current;if(!current||current.status!=="proposed")return;
    const response=await fetch("/api/actions",{method:"DELETE",headers:{"Content-Type":"application/json","X-EDITH-Action":"1"},body:JSON.stringify({id:current.proposal.id})});
    const data=await response.json();if(!response.ok)throw new Error(data.error||"Could not cancel this action.");
    showAction(null);setCaption("Action cancelled.");setNotice("Ready when you are.");
    if(history.current.at(-1)?.role==="assistant")history.current=[...history.current.slice(0,-1),{role:"assistant",content:"Action cancelled; no native action was requested."}];
  }
  const finishRecording=useCallback(()=>{if(recorder.current?.state==="recording")recorder.current.stop();else recognition.current?.stop();},[]);
  const listen=useCallback(async()=>{
    if(activePhase.current==="listening"){finishRecording();return;}
    if(locked.current || !connected)return;
    const Recognition=recognitionConstructor();
    if(!config?.transcription&&!Recognition){setNotice("Dictation isn’t supported in this browser. You can still type.");return;}
    if(!navigator.mediaDevices?.getUserMedia){setNotice("Microphone access needs a secure connection. You can still type.");return;}
    const ticket=++epoch.current;locked.current=true;retryKind.current="microphone";transcript.current="";voice.current?.unlock();setPending(true);setNotice("Requesting microphone access…");
    try {
      const stream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true}});
      if(ticket!==epoch.current){stream.getTracks().forEach(t=>t.stop());return;}
      media.current=stream;
      if(typeof AudioContext!=="undefined"){
        const context=new AudioContext();microphoneContext.current=context;
        await context.resume();
        if(ticket!==epoch.current){releaseMicrophone();return;}
        const analyser=context.createAnalyser();analyser.fftSize=256;context.createMediaStreamSource(stream).connect(analyser);
        const bytes=new Uint8Array(analyser.fftSize);
        const sample=()=>{analyser.getByteTimeDomainData(bytes);const level=Math.sqrt(bytes.reduce((s,v)=>s+((v-128)/128)**2,0)/bytes.length);audio.current=audio.current*.78+Math.min(1,level*5)*.22;microphoneFrame.current=requestAnimationFrame(sample);};sample();
      }
      setPending(false);setNotice("");dispatch({type:"LISTEN"});
      if(config?.transcription){
        if(typeof MediaRecorder==="undefined")throw new Error("Recording isn’t supported here. Please type instead.");
        const mime=["audio/webm;codecs=opus","audio/mp4","audio/ogg;codecs=opus"].find(m=>MediaRecorder.isTypeSupported(m));
        const recording=new MediaRecorder(stream,mime?{mimeType:mime}:undefined);recorder.current=recording;
        const chunks:BlobPart[]=[];recording.ondataavailable=e=>{if(e.data.size)chunks.push(e.data);};
        recording.onstop=async()=>{
          if(ticket!==epoch.current)return;
          releaseMicrophone();setPending(true);dispatch({type:"FINISH"});setNotice("Transcribing…");
          const controller=new AbortController();abort.current=controller;
          try {
            const form=new FormData();form.append("audio",new Blob(chunks,{type:recording.mimeType}),recording.mimeType.includes("mp4")?"voice.mp4":"voice.webm");
            const result=await fetch("/api/transcribe",{method:"POST",body:form,signal:controller.signal});
            const data=await result.json();if(!result.ok)throw new Error(data.error);
            if(ticket!==epoch.current)return;
            locked.current=false;setPending(false);setNotice("");if(data.text?.trim())void submit(data.text);else setNotice("No speech detected. Try again or type.");
          }catch(error){if(ticket===epoch.current){locked.current=false;setPending(false);dispatch({type:"FAIL",message:error instanceof Error?error.message:"Dictation failed. Please type instead."});}}
        };recording.start();
      } else {
        const native=new Recognition!();recognition.current=native;native.lang="en-US";native.interimResults=true;native.continuous=false;
        native.onresult=event=>{if(ticket!==epoch.current)return;transcript.current=Array.from(event.results).map(r=>r[0].transcript).join(" ");setDraft(transcript.current);};
        native.onerror=event=>{if(ticket!==epoch.current)return;locked.current=false;releaseMicrophone();dispatch({type:"FAIL",message:event.error==="not-allowed"?"Microphone permission was denied. Allow it in browser settings, or type your message.":"Dictation couldn’t connect. Try again or type your message."});};
        native.onend=()=>{if(ticket!==epoch.current)return;const text=transcript.current;releaseMicrophone();locked.current=false;dispatch({type:"FINISH"});if(text.trim())void submit(text);else setNotice("No speech detected. Try again or type.");};native.start();
      }
      micTimer.current=setTimeout(finishRecording,60000);
    } catch(error) {
      if(ticket!==epoch.current)return;locked.current=false;setPending(false);releaseMicrophone();
      const denied=error instanceof DOMException&&(error.name==="NotAllowedError"||error.name==="PermissionDeniedError");
      dispatch({type:"FAIL",message:denied?"Microphone permission was denied. Allow it in browser settings, or type your message.":error instanceof Error&&error.message?error.message:"Microphone unavailable. You can still type."});
    }
  },[config,connected,finishRecording,releaseMicrophone,submit]);
  function edit(value:string){if(activePhase.current==="listening"||pending)stop();setDraft(value);dispatch({type:"EDIT"});}
  function toggleVoice(){voice.current?.unlock();const enabled=!voiceOn.current;voiceOn.current=enabled;if(!enabled){voice.current?.stop();if(activePhase.current==="speaking")stop();}setVoiceEnabled(enabled);setNotice(!enabled?"Voice off. Answers stay on screen.":config?.speech?"Voice on · generated audio":"Voice on · browser speech");}
  return {state,config,draft,edit,caption,sources,researchStatus,captionVisible,setCaptionVisible,action,actionRunning,confirmAction,cancelAction,dismissAction:()=>showAction(null),voiceEnabled,toggleVoice,notice,connected,pending,audio,submit,stop,listen,retry:()=>retryKind.current==="microphone"?void listen():void submit(retry.current)};
}
