import type { ReactNode } from "react";

export function HudPanel({title,label="EDITH",icon,tools,footer,children,className="",ariaLabel}: {
  title:string;label?:string;icon?:ReactNode;tools?:ReactNode;footer?:ReactNode;children:ReactNode;className?:string;ariaLabel?:string;
}) {
  return <section className={`hud-panel ${className}`} aria-label={ariaLabel||title}>
    <div className="hud-decoration" aria-hidden="true"><i/><i/><i/><i/><span/></div>
    <header className="hud-heading">
      <div className="hud-identity"><span className="hud-icon" aria-hidden="true">{icon}</span><div><span className="hud-label">{label}</span><strong className="hud-title">{title}</strong></div></div>
      <div className="hud-tools">{tools}</div>
    </header>
    <div className="hud-body">{children}</div>
    {footer&&<footer className="hud-footer">{footer}</footer>}
  </section>;
}
