"use client";
import { useEffect,useState } from "react";
import { ImageIcon,X } from "lucide-react";
import { HudPanel } from "./HudPanel";

export function PicturePanel({file,onClose}:{file:File;onClose:()=>void}) {
  const [url,setUrl]=useState("");const [dimensions,setDimensions]=useState("");const [error,setError]=useState("");
  useEffect(()=>{
    if(!["image/png","image/jpeg","image/webp","image/gif","image/avif"].includes(file.type)){setError("Choose a PNG, JPEG, WebP, GIF or AVIF picture.");return;}
    if(file.size>20*1024*1024){setError("Choose a picture smaller than 20 MB.");return;}
    const objectUrl=URL.createObjectURL(file);setUrl(objectUrl);
    return()=>URL.revokeObjectURL(objectUrl);
  },[file]);
  return <HudPanel className="picture-panel" title="Image viewer" label="EDITH / PICTURE" icon={<ImageIcon size={20}/>} ariaLabel="Picture preview"
    tools={<button type="button" className="hud-close" aria-label="Close picture" onClick={onClose}><X size={16} aria-hidden="true"/></button>}
    footer={<><span className="picture-filename" title={file.name}>{file.name}</span><span>{dimensions||"LOCAL FILE"}</span></>}>
    <figure className="picture-stage">{error?<p className="action-error" role="alert">{error}</p>:url?<>
      {/* Local blob URLs need the browser image element, without a remote image service. */}
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={url} alt={file.name} onLoad={event=>{const image=event.currentTarget;setDimensions(`${image.naturalWidth} × ${image.naturalHeight}`);}} onError={()=>setError("This picture couldn't be opened. Choose another image.")}/>
    </>:<p className="picture-loading" role="status">Opening picture…</p>}</figure>
  </HudPanel>;
}
