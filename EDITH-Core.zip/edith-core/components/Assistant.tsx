"use client";
import { useEffect, useRef } from "react";
import { ArrowUp, Mic, Square, Volume2, VolumeX, MessageSquare, RotateCcw, X } from "lucide-react";
import { Core } from "./Core";
import { useAssistant } from "./useAssistant";

export function Assistant() {
  const a=useAssistant();
  const field=useRef<HTMLTextAreaElement>(null);
  const caption=useRef<HTMLDivElement>(null);
  const busy=["thinking","speaking","listening"].includes(a.state.phase)||a.pending;
  useEffect(()=>{if(field.current){field.current.style.height="auto";field.current.style.height=`${Math.min(field.current.scrollHeight,120)}px`;}},[a.draft]);
  useEffect(()=>{if(caption.current)caption.current.scrollTop=caption.current.scrollHeight;},[a.caption]);
  useEffect(()=>{
    const viewport=window.visualViewport;
    const adjust=()=>{document.documentElement.style.setProperty("--visible-height",`${viewport?.height||window.innerHeight}px`);};
    adjust();viewport?.addEventListener("resize",adjust);window.addEventListener("resize",adjust);
    return()=>{viewport?.removeEventListener("resize",adjust);window.removeEventListener("resize",adjust);};
  },[]);
  const status=a.state.phase==="listening"?"Listening · tap the microphone to finish":a.state.phase==="thinking"?"Thinking…":a.state.phase==="speaking"?"Speaking…":!a.connected?"Connecting…":a.notice;
  return <main className="assistant-screen" data-state={a.state.phase}>
    <div className="ambient" aria-hidden="true" />
    <Core phase={a.state.phase} audio={a.audio}/>
    <div className="conversation-layer">
      <div className={`caption-wrap ${a.caption&&a.captionVisible?"caption-shown":""}`} aria-hidden={!a.captionVisible||!a.caption}>
        <div ref={caption} className="response-caption" tabIndex={a.caption&&a.captionVisible?0:-1} aria-label="EDITH’s current response">
          <span>{a.caption}</span>{a.state.phase==="thinking"&&a.caption&&<i className="stream-caret" aria-hidden="true"/>}
        </div>
        {a.caption&&a.captionVisible&&<button className="caption-close" aria-label="Hide response" onClick={()=>a.setCaptionVisible(false)} tabIndex={a.captionVisible?0:-1}><X size={13}/></button>}
      </div>
      <div className="input-area">
        <div className="status-line" role="status" aria-live="polite" aria-atomic="true">
          {a.state.error?<span className="error-text">{a.state.error} <button className="retry" onClick={a.retry}><RotateCcw size={11}/> Retry</button></span>:status?<span className="temporary-status"><span className={`status-dot ${a.state.phase}`}/>{status}</span>:<span className="quiet-label">Ready when you are</span>}
        </div>
        <form className={`input-bar ${a.state.phase==="listening"?"is-listening":""}`} onSubmit={e=>{e.preventDefault();void a.submit(a.draft);}}>
          <div className="input-identity" aria-hidden="true"><span/><span/><span/></div>
          <textarea ref={field} aria-label="Ask EDITH anything" placeholder="Ask EDITH anything…" rows={1} maxLength={8000} value={a.draft} onChange={e=>a.edit(e.target.value)} onKeyDown={e=>{if(e.key==="Enter"&&!e.shiftKey&&!e.nativeEvent.isComposing){e.preventDefault();if(a.state.phase==="listening")a.stop();else void a.submit(a.draft);}if(e.key==="Escape")a.stop();}} spellCheck={false}/>
          <div className="input-actions">
            {a.caption&&<button type="button" className={`icon-button recall ${a.captionVisible?"is-selected":""}`} aria-label="Show latest response" title="Show latest response" onClick={()=>a.setCaptionVisible(true)}><MessageSquare size={16}/></button>}
            <button type="button" className={`icon-button voice-toggle ${a.voiceEnabled?"is-selected":""}`} aria-label={a.voiceEnabled?"Disable voice output":"Enable voice output"} aria-pressed={a.voiceEnabled} title={a.voiceEnabled?"Voice on":"Voice off"} onClick={a.toggleVoice}>{a.voiceEnabled?<Volume2 size={17}/>:<VolumeX size={17}/>}</button>
            <span className="action-divider" aria-hidden="true"/>
            <button type="button" className={`icon-button mic-button ${a.state.phase==="listening"?"is-selected":""}`} aria-label={a.state.phase==="listening"?"Finish listening":"Start voice input"} aria-pressed={a.state.phase==="listening"} title={a.state.phase==="listening"?"Finish listening":"Speak to EDITH"} disabled={!a.connected||a.state.phase==="thinking"||a.state.phase==="speaking"} onClick={()=>void a.listen()}><Mic size={18}/></button>
            {busy?<button type="button" className="send-button stop-button" aria-label="Stop response and audio" title="Stop" onClick={a.stop}><Square size={13} fill="currentColor"/></button>:<button type="submit" className="send-button" aria-label="Send message" title="Send message" disabled={!a.draft.trim()||!a.connected}><ArrowUp size={19}/></button>}
          </div>
        </form>
        <div className="input-footnote"><span>{a.config?.mode==="demo"?"DEMO · SIMULATED RESPONSES":a.config?.mode==="live"?"EDITH · CONNECTED":"EDITH"}</span><span className="key-hint" aria-hidden="true">↵ to send <i>·</i> shift ↵ for a new line</span></div>
      </div>
    </div>
    <span className="sr-only" role="status" aria-live="polite">{a.caption&&a.state.phase==="idle"?"Response complete. Use Show latest response to read it.":""}</span>
  </main>;
}
