import type { Source } from "@/lib/protocol";
export function CitedText({text,sources,visible}:{text:string;sources:Source[];visible:boolean}) {
  const byId=new Map(sources.map(source=>[source.id,source]));
  return <span>{text.split(/(\[\d+\])/g).map((part,index)=>{
    const match=/^\[(\d+)\]$/.exec(part);if(!match)return part;
    const source=byId.get(Number(match[1]));
    if(!source)return <span key={index} className="unresolved-citation" title="No retrieved source matches this citation">{part}</span>;
    return <a key={index} href={source.url} target="_blank" rel="noopener noreferrer" className="inline-citation" title={source.title} aria-label={`Source ${source.id}: ${source.title}`} tabIndex={visible?0:-1}>{part}</a>;
  })}</span>;
}
export function SourceLinks({sources,visible}:{sources:Source[];visible:boolean}) {
  if(!sources.length)return null;
  return <div className="source-links" aria-label="Web sources read for this answer"><span className="source-label">Sources read</span>{sources.map(source=><a key={source.id} href={source.url} target="_blank" rel="noopener noreferrer" tabIndex={visible?0:-1} title={`${source.title} — ${source.url}`} aria-label={`Read source ${source.id}: ${source.title}`}><span>[{source.id}]</span> {source.publisher}</a>)}</div>;
}
