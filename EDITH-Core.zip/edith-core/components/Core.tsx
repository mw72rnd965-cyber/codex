"use client";
import { useEffect, useRef, useState, type MutableRefObject } from "react";
import type { Phase } from "@/lib/protocol";
import * as THREE from "three";

const vertex = `
attribute float aSize; attribute float aSeed;
uniform float uTime; uniform float uEnergy; uniform float uMotion;
varying float vSeed; varying float vDepth;
void main(){
  vec3 p=position;
  float t=uTime*uMotion;
  p += normalize(p)*sin(p.y*7.0+t*.7+aSeed*6.28)*.023*uMotion;
  float a=sin(p.y*3.0+t*.18)*.12*uMotion;
  p.xz=mat2(cos(a),-sin(a),sin(a),cos(a))*p.xz;
  p *= 1.0+uEnergy*.04;
  vec4 mv=modelViewMatrix*vec4(p,1.0);
  gl_Position=projectionMatrix*mv;
  gl_PointSize=clamp(aSize*(17.0/-mv.z)*(1.0+uEnergy*.15),.6,4.2);
  vSeed=aSeed;vDepth=clamp((p.z+1.0)*.5,0.0,1.0);
}`;
const fragment = `
uniform vec3 uColor; uniform float uTime; uniform float uEnergy; uniform float uMotion;
varying float vSeed; varying float vDepth;
void main(){
  float d=length(gl_PointCoord-.5);
  if(d>.5)discard;
  float glow=exp(-d*d*18.0);
  float wave=.73+.27*sin(vSeed*25.0+uTime*1.3*uMotion);
  vec3 c=mix(uColor,vec3(.82,.95,1.0),vDepth*.4+pow(vSeed,8.0)*.45);
  gl_FragColor=vec4(c*1.15,glow*(.3+vDepth*.55)*wave*(.9+uEnergy*.5));
}`;

function CanvasCore({ phase, audio, reduced }: {phase:Phase;audio:MutableRefObject<number>;reduced:boolean}) {
  const canvas=useRef<HTMLCanvasElement>(null);
  useEffect(()=>{
    const node=canvas.current!; const context=node.getContext("2d");if(!context)return;
    let frame=0;let width=0;let height=0;let smoothed=0;
    const points=Array.from({length:700},(_,i)=>{const y=1-2*i/699;const theta=i*2.39996;return {x:Math.cos(theta)*Math.sqrt(1-y*y),y,z:Math.sin(theta)*Math.sqrt(1-y*y),size:.4+(i%5)*.13};});
    const resize=()=>{width=node.clientWidth;height=node.clientHeight;const ratio=Math.min(window.devicePixelRatio||1,1.5);node.width=width*ratio;node.height=height*ratio;context.setTransform(ratio,0,0,ratio,0,0);};
    const draw=(now:number)=>{
      context.clearRect(0,0,width,height);const t=reduced?0:now*.00007;
      smoothed+=(audio.current-smoothed)*.09;const radius=Math.min(width,height)*.295*(1+(reduced?0:smoothed*.08));
      const color=phase==="error"?"224,168,103":phase==="thinking"?"124,161,245":"116,223,255";
      const gradient=context.createRadialGradient(width/2,height/2,0,width/2,height/2,radius*1.4);gradient.addColorStop(0,`rgba(${color},.17)`);gradient.addColorStop(.55,`rgba(${color},.035)`);gradient.addColorStop(1,`rgba(${color},0)`);context.fillStyle=gradient;context.fillRect(0,0,width,height);
      for(const point of points){const x=point.x*Math.cos(t)-point.z*Math.sin(t);const z=point.x*Math.sin(t)+point.z*Math.cos(t);context.fillStyle=`rgba(${color},${.2+(z+1)*.32})`;context.beginPath();context.arc(width/2+x*radius,height/2+point.y*radius,point.size*(1+z*.25),0,Math.PI*2);context.fill();}
      for(let i=0;i<4;i++){context.save();context.translate(width/2,height/2);context.rotate(i*.73+t*.2);context.strokeStyle=`rgba(${color},.19)`;context.lineWidth=.6;context.beginPath();context.ellipse(0,0,radius*1.08,radius*(.25+i*.07),0,0,Math.PI*2);context.stroke();context.restore();}
      if(!reduced&&!document.hidden)frame=requestAnimationFrame(draw);
    };
    const visibility=()=>{cancelAnimationFrame(frame);if(!document.hidden)frame=requestAnimationFrame(draw);};
    const observer=new ResizeObserver(()=>{resize();if(reduced)draw(0);});observer.observe(node);resize();frame=requestAnimationFrame(draw);document.addEventListener("visibilitychange",visibility);
    return()=>{cancelAnimationFrame(frame);observer.disconnect();document.removeEventListener("visibilitychange",visibility);};
  },[audio,phase,reduced]);
  return <canvas ref={canvas} className="core-canvas" aria-hidden="true" />;
}

export function Core({phase,audio}:{phase:Phase;audio:MutableRefObject<number>}) {
  const mount=useRef<HTMLDivElement>(null);
  const currentPhase=useRef(phase);currentPhase.current=phase;
  const [fallback,setFallback]=useState(false);
  const [reduced,setReduced]=useState(false);
  useEffect(()=>{const query=matchMedia("(prefers-reduced-motion: reduce)");setReduced(query.matches);const changed=()=>setReduced(query.matches);query.addEventListener("change",changed);return()=>query.removeEventListener("change",changed);},[]);
  useEffect(()=>{
    if(fallback)return;
    const node=mount.current!;
    let renderer:THREE.WebGLRenderer;
    try { renderer=new THREE.WebGLRenderer({alpha:true,antialias:true,powerPreference:"low-power"}); }
    catch {setFallback(true);return;}
    const lost=(event:Event)=>{event.preventDefault();setFallback(true);};
    renderer.domElement.addEventListener("webglcontextlost",lost);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,1.5));
    renderer.setClearColor(0x000000,0);node.appendChild(renderer.domElement);
    const scene=new THREE.Scene();const camera=new THREE.PerspectiveCamera(34,1,.1,50);camera.position.z=4.7;
    const globe=new THREE.Group();scene.add(globe);
    const small=window.innerWidth<600 || (navigator.hardwareConcurrency||4)<=4;
    const count=small?9500:21000;const positions=new Float32Array(count*3);const sizes=new Float32Array(count);const seeds=new Float32Array(count);
    // Deterministic Fibonacci shell interleaved with a flowing, denser interior.
    for(let i=0;i<count;i++){
      const seed=((i*16807)%2147483647)/2147483647;
      const y=1-2*(i+.5)/count;const angle=i*2.39996323;
      const radius=i%4===0?.46+.48*((i*79%991)/991):.96+.035*Math.sin(y*28+angle*.03);
      positions.set([Math.cos(angle)*Math.sqrt(1-y*y)*radius,y*radius,Math.sin(angle)*Math.sqrt(1-y*y)*radius],i*3);
      sizes[i]=.44+(i*31%73)/100;seeds[i]=(i*53%997)/997+seed*.01;
    }
    const geometry=new THREE.BufferGeometry();geometry.setAttribute("position",new THREE.BufferAttribute(positions,3));geometry.setAttribute("aSize",new THREE.BufferAttribute(sizes,1));geometry.setAttribute("aSeed",new THREE.BufferAttribute(seeds,1));
    const material=new THREE.ShaderMaterial({vertexShader:vertex,fragmentShader:fragment,uniforms:{uTime:{value:0},uEnergy:{value:0},uMotion:{value:reduced?0:1},uColor:{value:new THREE.Color("#67dcfa")}},transparent:true,depthWrite:false,blending:THREE.AdditiveBlending});
    const particles=new THREE.Points(geometry,material);globe.add(particles);
    const disposables:{dispose():void}[]=[geometry,material];
    // Six fine flowing bundles converge around the luminous center.
    const innerPositions=new Float32Array(4200*3);const innerSizes=new Float32Array(4200);const innerSeeds=new Float32Array(4200);
    for(let i=0;i<4200;i++){
      const strand=Math.floor(i/700);const t=(i%700)/699*Math.PI*4;const r=.12+.62*Math.pow(Math.sin((i%700)/699*Math.PI),.8);
      const tilt=strand*Math.PI/3;
      const x=Math.cos(t+tilt)*r;const y=Math.sin(t+tilt)*r;const z=Math.sin(t*.5)*.32;
      innerPositions.set([x,y*Math.cos(tilt)-z*Math.sin(tilt),y*Math.sin(tilt)+z*Math.cos(tilt)],i*3);innerSizes[i]=.9;innerSeeds[i]=(i%700)/700;
    }
    const innerGeometry=new THREE.BufferGeometry();innerGeometry.setAttribute("position",new THREE.BufferAttribute(innerPositions,3));innerGeometry.setAttribute("aSize",new THREE.BufferAttribute(innerSizes,1));innerGeometry.setAttribute("aSeed",new THREE.BufferAttribute(innerSeeds,1));
    const innerMaterial=material.clone();innerMaterial.uniforms.uColor=material.uniforms.uColor;innerMaterial.uniforms.uTime=material.uniforms.uTime;innerMaterial.uniforms.uEnergy=material.uniforms.uEnergy;
    particles.add(new THREE.Points(innerGeometry,innerMaterial));disposables.push(innerGeometry,innerMaterial);
    const orbits=new THREE.Group();globe.add(orbits);
    const orbitMaterials:THREE.LineBasicMaterial[]=[];
    for(let i=0;i<8;i++){
      const path=[];
      for(let j=0;j<=280;j++){const theta=j/280*Math.PI*2;const radius=1.055+(i%3)*.035;path.push(new THREE.Vector3(Math.cos(theta)*radius,Math.sin(theta)*radius,0));}
      const geo=new THREE.BufferGeometry().setFromPoints(path);const mat=new THREE.LineBasicMaterial({color:"#70d9fc",transparent:true,opacity:i<3?.19:.08,depthWrite:false,blending:THREE.AdditiveBlending});
      const line=new THREE.Line(geo,mat);line.rotation.set(.4+i*.43,.2+i*.62,i*.33);orbits.add(line);orbitMaterials.push(mat);disposables.push(geo,mat);
    }
    // Thin internal filaments create depth without an opaque solid sphere.
    for(let i=0;i<9;i++){
      const path=[];for(let j=0;j<=240;j++){const t=j/240*Math.PI*2;const radius=.72+.06*Math.sin(t*3+i);path.push(new THREE.Vector3(Math.cos(t)*radius,Math.sin(t)*radius,Math.sin(t*2+i)*.22));}
      const geo=new THREE.BufferGeometry().setFromPoints(path);const mat=new THREE.LineBasicMaterial({color:"#b7eeff",transparent:true,opacity:.1,depthWrite:false,blending:THREE.AdditiveBlending});const line=new THREE.Line(geo,mat);line.rotation.set(i*.51,i*.8,i*.37);particles.add(line);disposables.push(geo,mat);
    }
    const dustGeometry=new THREE.BufferGeometry();const dust=new Float32Array(180*3);
    for(let i=0;i<180;i++){const theta=i*2.39996;const radius=1.3+(i%29)/29*.38;dust.set([Math.sin(theta)*radius,Math.cos(theta)*radius,Math.sin(i*4.7)*.8],i*3);}
    dustGeometry.setAttribute("position",new THREE.BufferAttribute(dust,3));const dustMaterial=new THREE.PointsMaterial({color:"#86defe",size:.006,transparent:true,opacity:.32,depthWrite:false});scene.add(new THREE.Points(dustGeometry,dustMaterial));disposables.push(dustGeometry,dustMaterial);
    const cyan=new THREE.Color("#67dcfa");const color=cyan.clone();const violet=new THREE.Color("#aba3ff");const amber=new THREE.Color("#c7a071");const ice=new THREE.Color("#93e6ff");
    let frame=0;let last=0;let elapsed=0;let energy=0;let scale=1;let speed=.07;
    const resize=()=>{const width=node.clientWidth;const height=node.clientHeight;renderer.setSize(width,height);camera.aspect=width/height;camera.updateProjectionMatrix();if(reduced)renderer.render(scene,camera);};
    const animate=(now:number)=>{
      const dt=Math.min((now-(last||now))/1000,.05);last=now;elapsed+=dt;
      const phase=currentPhase.current;
      const target=phase==="thinking"?.42:phase==="listening"?.25+audio.current*.9:phase==="speaking"?.3+audio.current*.8:phase==="error"?.1:.04;
      energy+=(target-energy)*.055; speed+=((phase==="thinking"?.17:.055)-speed)*.025;
      node.parentElement?.style.setProperty("--audio-level",reduced?"0":String(audio.current));
      const targetScale=phase==="listening"?1.04:phase==="speaking"?1.01:1;
      scale+=(targetScale-scale)*.03;
      color.lerp(phase==="thinking"?violet:phase==="error"?amber:phase==="listening"||phase==="speaking"?ice:cyan,.025);
      material.uniforms.uTime.value=elapsed;material.uniforms.uEnergy.value=reduced?0:energy;material.uniforms.uColor.value=color;
      if(!reduced){particles.rotation.y+=dt*speed;particles.rotation.z=Math.sin(elapsed*.1)*.07;orbits.rotation.y-=dt*speed*.35;orbits.rotation.x=Math.sin(elapsed*.15)*.08;globe.scale.setScalar(scale+Math.sin(elapsed*.9)*.008+energy*.025);}
      orbitMaterials.forEach((mat,i)=>{mat.color.copy(color);mat.opacity=(i<3?.19:.08)*(1+energy*.6);});
      renderer.render(scene,camera);
      if(!document.hidden)frame=requestAnimationFrame(animate);
    };
    const visibility=()=>{cancelAnimationFrame(frame);last=0;if(!document.hidden)frame=requestAnimationFrame(animate);};
    const observer=new ResizeObserver(resize);observer.observe(node);resize();frame=requestAnimationFrame(animate);document.addEventListener("visibilitychange",visibility);
    return()=>{cancelAnimationFrame(frame);observer.disconnect();document.removeEventListener("visibilitychange",visibility);renderer.domElement.removeEventListener("webglcontextlost",lost);disposables.forEach(d=>d.dispose());renderer.dispose();renderer.forceContextLoss();renderer.domElement.remove();};
  },[audio,fallback,reduced]);
  return <div className="core-container" data-phase={phase} data-renderer={fallback?"canvas":"webgl"} data-reduced-motion={reduced} role="img" aria-label={`EDITH energy core, ${phase}`}>
    <div className="core-aura" />
    <div ref={mount} className="core-renderer" aria-hidden="true" />
    {fallback&&<CanvasCore phase={phase} audio={audio} reduced={reduced}/>}
    <div className="core-center" aria-hidden="true" />
    <div className="core-ripple" aria-hidden="true"/><div className="core-ripple outer" aria-hidden="true"/>
  </div>;
}
