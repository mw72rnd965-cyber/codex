import { defineConfig } from "@playwright/test";
export default defineConfig({
  testDir: "./tests", testMatch: "*.spec.ts", workers: 1,
  use: { baseURL: "http://127.0.0.1:3001", launchOptions: { executablePath: process.env.CHROMIUM_PATH || "/usr/bin/chromium", args:["--no-sandbox","--use-fake-device-for-media-stream"] }, screenshot:"only-on-failure" },
  reporter:"list",
});
