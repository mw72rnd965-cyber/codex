import { test } from "node:test";
import assert from "node:assert/strict";
import os from "node:os";
import { calendarReadRange } from "../lib/server/calendar-range";
import { prepareAction } from "../lib/server/action-planner";

test("Calendar date ranges use local midnights, including DST and Monday-based weeks",()=>{
  const original=process.env.TZ;process.env.TZ="Europe/Rome";
  try {
    assert.deepEqual(calendarReadRange("Show my calendar today",new Date("2026-03-29T12:00:00+02:00")),{start:"2026-03-28T23:00:00.000Z",end:"2026-03-29T22:00:00.000Z"});
    assert.deepEqual(calendarReadRange("Read my calendar today",new Date("2026-10-25T12:00:00+01:00")),{start:"2026-10-24T22:00:00.000Z",end:"2026-10-25T23:00:00.000Z"});
    assert.deepEqual(calendarReadRange("What meetings do I have tomorrow?",new Date("2026-12-31T23:30:00+01:00")),{start:"2026-12-31T23:00:00.000Z",end:"2027-01-01T23:00:00.000Z"});
    assert.deepEqual(calendarReadRange("Show my agenda this week",new Date("2026-10-15T12:00:00+02:00")),{start:"2026-10-11T22:00:00.000Z",end:"2026-10-18T22:00:00.000Z"});
    assert.equal(calendarReadRange("Show my calendar tomorrow and today"),null);
    assert.equal(calendarReadRange("Read my calendar in December"),null);
  }finally{if(original===undefined)delete process.env.TZ;else process.env.TZ=original;}
});

test("Calendar read opens an editable review without any Ollama or network request",async context=>{
  const original={provider:process.env.AI_PROVIDER,enabled:process.env.MAC_ACTIONS};
  context.mock.method(os,"platform",()=>"darwin");let inference=0;
  context.mock.method(globalThis,"fetch",async()=>{inference++;throw Error("Ollama should not be involved");});
  process.env.AI_PROVIDER="ollama";process.env.MAC_ACTIONS="on";
  try {
    const today=await prepareAction("calendar_read","Show my calendar today",new AbortController().signal);assert.ok(today.fields.start);assert.ok(today.fields.end);
    const unknown=await prepareAction("calendar_read","Read my calendar in December",new AbortController().signal);assert.equal(unknown.fields.start,"");assert.equal(unknown.fields.end,"");
    assert.equal(inference,0);
    await assert.rejects(prepareAction("calendar_read","Show my calendar",AbortSignal.abort()),{name:"AbortError"});
  }finally{context.mock.restoreAll();if(original.provider===undefined)delete process.env.AI_PROVIDER;else process.env.AI_PROVIDER=original.provider;if(original.enabled===undefined)delete process.env.MAC_ACTIONS;else process.env.MAC_ACTIONS=original.enabled;}
});
