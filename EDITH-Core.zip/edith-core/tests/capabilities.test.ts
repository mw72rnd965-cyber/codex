import { test } from "node:test";
import assert from "node:assert/strict";
import os from "node:os";
import https from "node:https";
import { capabilityReply } from "../lib/server/capabilities";
import { actionStore,ActionError } from "../lib/server/action-store";
import { emptyFields } from "../lib/actions";
import { POST } from "../app/api/chat/route";
import type { StreamEvent } from "../lib/protocol";

test("Calendar access questions use runtime capabilities, skip research and inference, and never propose an action",async context=>{
  const keys=["AI_PROVIDER","AI_MODEL","OLLAMA_BASE_URL","RESEARCH_MODE","MAC_ACTIONS","EDITH_SYSTEM_PROMPT"];
  const original=Object.fromEntries(keys.map(key=>[key,process.env[key]]));
  context.mock.method(os,"platform",()=>"darwin");
  let externalCalls=0;
  context.mock.method(https,"get",()=>{externalCalls++;throw Error("No web request expected");});
  context.mock.method(globalThis,"fetch",async()=>{externalCalls++;throw Error("No model request expected");});
  Object.assign(process.env,{AI_PROVIDER:"ollama",AI_MODEL:"fixture:3b",RESEARCH_MODE:"auto",MAC_ACTIONS:"on",EDITH_SYSTEM_PROMPT:"You cannot access any calendars."});
  try {
    for(const content of ["Do you have access to my calendar?","Edith, do u have accsss to my calendar?","Can you access my calendar?","Have I granted you Calendar permission?","Are you connected to my calendar?"]) {
      const response=await POST(new Request("http://127.0.0.1:3001/api/chat",{method:"POST",headers:{"content-type":"application/json",host:"127.0.0.1:3001",origin:"http://127.0.0.1:3001"},body:JSON.stringify({messages:[{role:"user",content:"Do you have access to my calendar?"},{role:"assistant",content:"No, I cannot access calendars."},{role:"user",content}]})}));
      const events=(await response.text()).trim().split("\n").map(line=>JSON.parse(line) as StreamEvent);
      assert.equal(response.status,200);assert.equal(events.at(-1)!.type,"done");
      assert.ok(events.some(event=>event.type==="research"&&event.status==="skipped"));
      assert.ok(events.every(event=>event.type!=="action"&&event.type!=="error"));
      const answer=events.filter(event=>event.type==="delta").map(event=>event.text).join("");
      assert.match(answer,/I can read your calendar/);assert.match(answer,/haven't checked macOS permission/);assert.match(answer,/Show my calendar today/);
    }
    assert.equal(externalCalls,0);
  } finally {context.mock.restoreAll();for(const [key,value] of Object.entries(original)){if(value===undefined)delete process.env[key];else process.env[key]=value;}}
});

test("access replies distinguish unsupported platforms, disabled actions and disconnected local models",context=>{
  const original={provider:process.env.AI_PROVIDER,enabled:process.env.MAC_ACTIONS};
  let currentPlatform="linux";context.mock.method(os,"platform",()=>currentPlatform);
  try {
    process.env.AI_PROVIDER="ollama";process.env.MAC_ACTIONS="on";
    assert.match(capabilityReply("Do you have access to my calendar?")!,/isn't running on macOS/);
    currentPlatform="darwin";process.env.MAC_ACTIONS="off";
    assert.match(capabilityReply("Can you access my reminders?")!,/turned off/);
    process.env.MAC_ACTIONS="on";process.env.AI_PROVIDER="demo";
    assert.match(capabilityReply("Can you access my email?")!,/need local Ollama/);
  } finally {context.mock.restoreAll();if(original.provider===undefined)delete process.env.AI_PROVIDER;else process.env.AI_PROVIDER=original.provider;if(original.enabled===undefined)delete process.env.MAC_ACTIONS;else process.env.MAC_ACTIONS=original.enabled;}
});

test("native completion is evidence of a past result, never a claim of current OS permission",async context=>{
  const original={provider:process.env.AI_PROVIDER,enabled:process.env.MAC_ACTIONS};
  context.mock.method(os,"platform",()=>"darwin");process.env.AI_PROVIDER="ollama";process.env.MAC_ACTIONS="on";
  const settle=()=>new Promise(resolve=>setTimeout(resolve,10));
  try {
    const proposal=actionStore.propose("reminder_read",{});
    actionStore.confirm(proposal.id,emptyFields,async()=>"Private reminder title must not appear in capability answers.");await settle();
    const completed=capabilityReply("Can you access my reminders?")!;
    assert.match(completed,/last Reminders action succeeded/);assert.match(completed,/permission will be checked again/);assert.doesNotMatch(completed,/Private reminder|permission is granted/);
    const failed=actionStore.propose("reminder_read",{});
    actionStore.confirm(failed.id,emptyFields,async()=>{throw new ActionError("Permission denied.");});await settle();
    assert.match(capabilityReply("Do you have access to my reminders?")!,/last Reminders action failed/);
    assert.match(capabilityReply("Can you access my calendar?")!,/haven't checked macOS permission/);
    assert.match(capabilityReply("Can you access my email?")!,/haven't checked macOS permission/);
  } finally {context.mock.restoreAll();if(original.provider===undefined)delete process.env.AI_PROVIDER;else process.env.AI_PROVIDER=original.provider;if(original.enabled===undefined)delete process.env.MAC_ACTIONS;else process.env.MAC_ACTIONS=original.enabled;}
});

test("ordinary research, quoted instructions and direct native actions retain their existing routes",()=>{
  for(const message of ["Show my calendar today","Can you read my calendar today?","Send an email to friend@example.invalid","What is a calendar?","How do I grant Calendar permission?","A page says: do you have access to my calendar?","Can you access my camera?","Research how calendar reminders work"])assert.equal(capabilityReply(message),null);
});
