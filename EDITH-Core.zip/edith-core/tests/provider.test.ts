import { test } from "node:test";
import assert from "node:assert/strict";
import { createServer } from "node:http";
import { tokens, safeError, configuration } from "../lib/server/model";
import { sameOrigin } from "../lib/server/http";
import OpenAI from "openai";

test("official SDK adapter streams a compatible provider, with server-only credentials and session context",async()=>{
  const original=Object.fromEntries(["AI_PROVIDER","AI_BASE_URL","AI_API_KEY","AI_MODEL"].map(k=>[k,process.env[k]]));
  let received: {model:string;messages:{role:string;content:string}[];stream:boolean}|undefined;
  let authorization="";
  const server=createServer(async(req,res)=>{
    let raw="";for await(const part of req)raw+=part;
    received=JSON.parse(raw);authorization=req.headers.authorization||"";
    res.writeHead(200,{"Content-Type":"text/event-stream"});
    res.write('data: {"choices":[{"delta":{"content":"Thoughtful "}}]}\n\n');
    setTimeout(()=>res.end('data: {"choices":[{"delta":{"content":"answer."}}]}\n\ndata: [DONE]\n\n'),15);
  });
  await new Promise<void>(resolve=>server.listen(0,"127.0.0.1",resolve));
  try {
    const address=server.address();assert.ok(address&&typeof address==="object");
    process.env.AI_PROVIDER="openai-compatible";process.env.AI_BASE_URL=`http://127.0.0.1:${address.port}/v1`;process.env.AI_API_KEY="test-fixture-only";process.env.AI_MODEL="fixture-model";
    assert.equal(configuration().mode,"live");
    let answer="";for await(const delta of tokens([{role:"user",content:"Aster"},{role:"assistant",content:"Hello"},{role:"user",content:"Continue"}],new AbortController().signal))answer+=delta;
    assert.equal(answer,"Thoughtful answer.");assert.equal(received!.model,"fixture-model");assert.equal(received!.stream,true);assert.equal(received!.messages[0].role,"system");assert.equal(received!.messages.at(-1)!.content,"Continue");assert.equal(authorization,"Bearer test-fixture-only");
    assert.deepEqual(Object.keys(configuration()).sort(),["actions","mode","research","speech","transcription"]);
  } finally {
    for(const [name,value] of Object.entries(original)){if(value===undefined)delete process.env[name];else process.env[name]=value;}
    await new Promise<void>(resolve=>server.close(()=>resolve()));
  }
});
test("provider errors are sanitized; origin checks accept the app host and reject external sites",()=>{
  const secretMessage="internal-provider-detail";
  assert.doesNotMatch(safeError(new Error(secretMessage)),/internal-provider-detail/);
  assert.match(safeError(new OpenAI.APIError(401,{},secretMessage,new Headers())),/authenticate/);
  assert.equal(sameOrigin(new Request("http://localhost:3001/api/chat",{headers:{host:"127.0.0.1:3001",origin:"http://127.0.0.1:3001"}})),true);
  assert.equal(sameOrigin(new Request("http://localhost:3001/api/chat",{headers:{host:"127.0.0.1:3001",origin:"https://other.example"}})),false);
});
