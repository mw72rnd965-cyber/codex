import { test } from "node:test";
import assert from "node:assert/strict";
import { mkdtemp,writeFile,rm,rename } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { waitForMacResult } from "../lib/server/mac-result";

test("Mac results complete from the receipt without waiting for the helper app to exit",async()=>{
  const dir=await mkdtemp(join(tmpdir(),"edith-result-test-"));
  try {
    const phases:string[]=[];await writeFile(join(dir,"progress.json"),JSON.stringify({phase:"permission"}));
    const waiting=waitForMacResult(dir,phase=>phases.push(phase),{timeoutMs:1000,pollMs:5});
    // No process-exit event exists in this test; only the helper receipt arrives.
    await new Promise(resolve=>setTimeout(resolve,30));await writeFile(join(dir,"result.partial"),JSON.stringify({ok:true,text:"No events found."}));await rename(join(dir,"result.partial"),join(dir,"result.json"));
    assert.deepEqual(await waiting,{ok:true,text:"No events found."});assert.deepEqual(phases,["permission"]);
  }finally{await rm(dir,{recursive:true,force:true});}
});
test("permission waits and startup failures are distinguished without inventing Calendar results",async()=>{
  const dir=await mkdtemp(join(tmpdir(),"edith-result-test-"));
  try {
    await writeFile(join(dir,"progress.json"),JSON.stringify({phase:"permission"}));
    assert.deepEqual(await waitForMacResult(dir,()=>{},{timeoutMs:25,pollMs:2}),{ok:false,code:"permission_timeout"});
    await rm(join(dir,"progress.json"));
    await assert.rejects(waitForMacResult(dir,()=>{},{timeoutMs:1000,startupMs:15,pollMs:2}),/did not finish starting/);
    await writeFile(join(dir,"result.json"),JSON.stringify({ok:true,text:"Untrusted",unexpected:"field"}));
    await assert.rejects(waitForMacResult(dir),/valid result/);
  }finally{await rm(dir,{recursive:true,force:true});}
});
