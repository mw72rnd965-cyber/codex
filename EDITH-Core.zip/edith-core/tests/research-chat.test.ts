import { test } from "node:test";
import assert from "node:assert/strict";
import http, { type IncomingMessage, type ClientRequest } from "node:http";
import https, { type RequestOptions } from "node:https";
import { EventEmitter } from "node:events";
import { Readable } from "node:stream";
import { POST } from "../app/api/chat/route";
import { readPublicWeb } from "../lib/server/public-web";
import type { StreamEvent } from "../lib/protocol";

const evidence="The James Webb Space Telescope observes infrared light. It studies distant galaxies and exoplanet atmospheres using spectra collected by its instruments. Its observations help astronomers identify chemical signatures and understand early galaxies. ";

test("chat retrieves page evidence before Ollama, supplies grounded context, and stops before inference when research fails",async context=>{
  const keys=["AI_PROVIDER","AI_MODEL","OLLAMA_BASE_URL","RESEARCH_MODE","HTTPS_PROXY"];
  const original=Object.fromEntries(keys.map(key=>[key,process.env[key]]));
  let fail=false;let modelRequests=0;
  let received: {messages:{role:string;content:string}[]}|undefined;
  const webCalls:string[]=[];
  // Only the test replaces public HTTP responses. Production keeps HTTPS,
  // DNS/private-address checks, proxy policy, and certificate verification.
  context.mock.method(http as unknown as {setGlobalProxyFromEnv:()=>void},"setGlobalProxyFromEnv",()=>{});
  context.mock.method(https,"get",(url:URL,options:RequestOptions,callback:(response:IncomingMessage)=>void)=>{
    webCalls.push(url.href);assert.equal(options.headers&&"Authorization" in options.headers,false);
    const request=new EventEmitter() as ClientRequest;
    request.destroy=()=>request;
    queueMicrotask(()=>{
      if(fail){request.emit("error",new Error("Fixture source unavailable"));return;}
      let text:string;let contentType:string;
      if(url.hostname==="www.bing.com"){
        contentType="application/rss+xml";text='<rss><channel><item><title>Webb research</title><link>https://en.wikipedia.org/wiki/James_Webb_Space_Telescope</link></item></channel></rss>';
      }else if(url.pathname==="/w/api.php"){
        contentType="application/json";text=JSON.stringify({query:{pages:{"1":{title:"Webb telescope",fullurl:"https://en.wikipedia.org/wiki/James_Webb_Space_Telescope",extract:evidence.repeat(2),index:1}}}});
      }else{
        contentType="text/html";text=`<html><head><title>Webb research</title></head><body><article><h1>Webb research</h1><p>${evidence.repeat(3)}</p></article></body></html>`;
      }
      const response=Readable.from([Buffer.from(text)]) as IncomingMessage;
      response.statusCode=200;response.headers={"content-type":contentType};callback(response);
    });
    return request;
  });
  const server=http.createServer(async(req,res)=>{
    modelRequests++;
    if(req.url==="/api/show"){res.setHeader("Content-Type","application/json");res.end('{"capabilities":["completion"]}');return;}
    let raw="";for await(const chunk of req)raw+=chunk;
    received=JSON.parse(raw);res.setHeader("Content-Type","application/x-ndjson");
    res.end('{"message":{"content":"Webb observes infrared light [1]."},"done":true}\n');
  });
  await new Promise<void>(resolve=>server.listen(0,"127.0.0.1",resolve));
  const address=server.address();assert.ok(address&&typeof address==="object");
  Object.assign(process.env,{AI_PROVIDER:"ollama",AI_MODEL:"fixture:3b",OLLAMA_BASE_URL:`http://127.0.0.1:${address.port}`,RESEARCH_MODE:"auto",HTTPS_PROXY:"http://fixture.invalid"});
  const ask=async(content:string)=>{
    const response=await POST(new Request("http://127.0.0.1:3001/api/chat",{method:"POST",headers:{"content-type":"application/json",host:"127.0.0.1:3001",origin:"http://127.0.0.1:3001"},body:JSON.stringify({messages:[{role:"user",content}]})}));
    assert.equal(response.status,200);return (await response.text()).trim().split("\n").map(line=>JSON.parse(line) as StreamEvent);
  };
  try {
    const events=await ask("What does the Webb telescope observe?");
    const complete=events.findIndex(event=>event.type==="research"&&event.status==="complete");
    const delta=events.findIndex(event=>event.type==="delta");
    assert.ok(complete>0&&delta>complete);assert.equal(events.at(-1)!.type,"done");
    assert.match(received!.messages[0].content,/SOURCE \[1\]/);assert.match(received!.messages[0].content,/observes infrared light/);assert.match(received!.messages[0].content,/Never invent sources/);
    assert.equal(received!.messages.at(-1)!.content,"What does the Webb telescope observe?");
    assert.ok(webCalls.some(url=>url.startsWith("https://www.bing.com/search?")));
    const requestsBeforeFailure=modelRequests;fail=true;
    const failed=await ask("Latest telescope discoveries?");
    assert.equal(modelRequests,requestsBeforeFailure);assert.equal(failed.at(-1)!.type,"error");assert.ok(failed.every(event=>event.type!=="delta"&&event.type!=="done"));
    const requestsBeforeGreeting=webCalls.length;
    const greeting=await ask("Hello");
    assert.equal(webCalls.length,requestsBeforeGreeting);assert.ok(greeting.some(event=>event.type==="research"&&event.status==="skipped"));assert.equal(greeting.at(-1)!.type,"done");
  } finally {
    context.mock.restoreAll();for(const [key,value] of Object.entries(original)){if(value===undefined)delete process.env[key];else process.env[key]=value;}
    server.closeAllConnections();await new Promise<void>(resolve=>server.close(()=>resolve()));
  }
});

test("source redirects are revalidated and cannot send a request to a private network",async context=>{
  const original=process.env.HTTPS_PROXY;process.env.HTTPS_PROXY="http://fixture.invalid";
  let calls=0;
  context.mock.method(http as unknown as {setGlobalProxyFromEnv:()=>void},"setGlobalProxyFromEnv",()=>{});
  context.mock.method(https,"get",(_url:URL,_options:RequestOptions,callback:(response:IncomingMessage)=>void)=>{
    calls++;const request=new EventEmitter() as ClientRequest;request.destroy=()=>request;
    queueMicrotask(()=>{const response=Readable.from([]) as IncomingMessage;response.statusCode=302;response.headers={location:"https://169.254.169.254/latest/meta-data"};callback(response);});
    return request;
  });
  try{await assert.rejects(readPublicWeb("https://www.bing.com/redirect",new AbortController().signal),/public HTTPS/);assert.equal(calls,1);}
  finally{context.mock.restoreAll();if(original===undefined)delete process.env.HTTPS_PROXY;else process.env.HTTPS_PROXY=original;}
});
