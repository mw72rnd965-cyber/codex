import { test } from "node:test";
import assert from "node:assert/strict";
import { research,researchQuery,needsResearch,rssCandidates,articleEvidence,groundedPrompt,ResearchError } from "../lib/server/research";
import { publicUrl,isPublicAddress,type WebReader } from "../lib/server/public-web";
import type { ResearchEvent } from "../lib/protocol";

const article=(title:string,body:string)=>`<!doctype html><html><head><title>${title}</title></head><body><article><h1>${title}</h1><p>${body}</p><p>${body}</p><p>${body}</p></article></body></html>`;
const fact="The James Webb Space Telescope observes infrared light. It launched in December 2021 and studies distant galaxies and exoplanet atmospheres. Its instruments collect spectra that help researchers identify chemical signatures. ";
const wiki=(title="James Webb Space Telescope")=>JSON.stringify({query:{pages:{"1":{title,fullurl:"https://en.wikipedia.org/wiki/James_Webb_Space_Telescope",extract:fact.repeat(3),index:1}}}});
test("research reads real page text, deduplicates sources and emits only registered public citation links",async()=>{
  const calls:string[]=[];const events:ResearchEvent[]=[];
  const reader:WebReader=async url=>{
    calls.push(url);
    if(url.includes("bing.com"))return {url,contentType:"application/rss+xml",text:'<rss><channel><item><title>Webb</title><link>https://science.nasa.gov/webb/</link></item><item><title>Duplicate</title><link>https://science.nasa.gov/webb/</link></item><item><title>Private</title><link>https://127.0.0.1/private</link></item></channel></rss>'};
    if(url.includes("/w/api.php"))return {url,contentType:"application/json",text:wiki()};
    return {url,contentType:"text/html",text:article("NASA Webb facts",fact)};
  };
  const result=await research([{role:"user",content:"What does Webb observe?"}],new AbortController().signal,e=>events.push(e),reader);
  assert.equal(result.status,"complete");assert.equal(result.sources.length,2);assert.equal(result.sources[0].id,1);
  assert.match(result.sources[0].excerpt,/infrared light/);assert.equal(result.sources[0].title,"NASA Webb facts");
  assert.equal(calls.filter(url=>url==="https://science.nasa.gov/webb/").length,1);assert.ok(calls.every(url=>!url.includes("127.0.0.1")));
  assert.deepEqual(events.map(event=>event.status),["searching","reading","complete"]);
  assert.equal("excerpt" in events.at(-1)!.sources[0],false);
  const prompt=groundedPrompt("Base prompt",result);assert.match(prompt,/SOURCE \[1\]/);assert.match(prompt,/infrared light/);assert.match(prompt,/untrusted data/);assert.match(prompt,/Never invent sources/);
});
test("Wikipedia article API supplies readable fallback evidence when generic search is blocked",async()=>{
  const reader:WebReader=async url=>{
    if(!url.includes("en.wikipedia.org"))throw Error("Search blocked");
    return {url,contentType:"application/json",text:wiki()};
  };
  const result=await research([{role:"user",content:"What is the Webb telescope?"}],new AbortController().signal,()=>{},reader);
  assert.equal(result.sources[0].publisher,"Wikipedia");assert.equal(result.sources[0].url,"https://en.wikipedia.org/wiki/James_Webb_Space_Telescope");assert.match(result.sources[0].excerpt,/spectra/);
});
test("failed research rejects instead of supplying an unverified answer or invented sources",async()=>{
  const events:ResearchEvent[]=[];
  await assert.rejects(research([{role:"user",content:"Latest telescope discoveries?"}],new AbortController().signal,e=>events.push(e),async()=>{throw Error("Unavailable");}),ResearchError);
  assert.equal(events.at(-1)!.status,"unavailable");assert.equal(events.at(-1)!.sources.length,0);
});
test("stop aborts research and suppresses completion events",async()=>{
  const controller=new AbortController();const events:ResearchEvent[]=[];
  const reader:WebReader=async(_url,signal)=>new Promise((_resolve,reject)=>{signal.addEventListener("abort",()=>reject(signal.reason),{once:true});controller.abort(new DOMException("Stopped","AbortError"));});
  await assert.rejects(research([{role:"user",content:"A factual question?"}],controller.signal,e=>events.push(e),reader),{name:"AbortError"});
  assert.ok(events.every(event=>event.status!=="complete"));
});
test("public web reader blocks private addresses, non-web schemes, credentials and unsafe ports",()=>{
  for(const value of ["https://127.0.0.1/","https://10.0.0.1/","https://169.254.169.254/latest","https://[::1]/","https://localhost/","https://printer.local/","http://example.com/","file:///etc/passwd","javascript:alert(1)","https://user:password@example.com/","https://example.com:11434/"])assert.throws(()=>publicUrl(value));
  for(const address of ["192.168.1.1","100.64.0.1","::ffff:127.0.0.1","fc00::1","fe80::1","0:0:0:0:0:ffff:c0a8:101"])assert.equal(isPublicAddress(address),false);
  assert.equal(isPublicAddress("93.184.216.34"),true);assert.equal(publicUrl("https://example.com/article#section").href,"https://example.com/article");
});
test("query follows the current topic without sending system prompts, keys, code or email addresses",()=>{
  const query=researchQuery([{role:"user",content:"James Webb telescope"},{role:"assistant",content:"Private assistant context"},{role:"user",content:"What does it observe? api_key=secret-value user@example.com ```secret code```"}]);
  assert.match(query,/James Webb telescope/);assert.doesNotMatch(query,/secret-value|secret code|user@example.com|Private assistant/);
  assert.equal(needsResearch([{role:"user",content:"Hello"}]),false);assert.equal(needsResearch([{role:"user",content:"What did I say earlier?"}]),false);assert.equal(needsResearch([{role:"user",content:"How do black holes form?"}]),true);
});
test("source extraction does not execute scripts or accept challenge/login pages as research",()=>{
  const page=articleEvidence(article("Webb research",fact)+'<script>globalThis.compromised=true</script>',"https://example.com/research","Fallback");
  assert.ok(page);assert.doesNotMatch(page.excerpt,/compromised/);assert.equal((globalThis as unknown as {compromised?:boolean}).compromised,undefined);
  assert.equal(articleEvidence(article("Just a moment",fact),"https://example.com/challenge","Challenge"),null);
  assert.equal(rssCandidates('<rss><channel><item><title>Bad</title><link>javascript:alert(1)</link></item></channel></rss>').length,0);
});
