import { test, expect, type Page } from "@playwright/test";
import { emptyFields,type ActionKind,type ActionFields } from "../lib/actions";
const input=(p:Page)=>p.getByRole("textbox",{name:"Ask EDITH anything"});
const ndjson=(text:string)=>JSON.stringify({type:"meta",mode:"demo"})+"\n"+JSON.stringify({type:"delta",text})+"\n"+JSON.stringify({type:"done"})+"\n";
async function ready(page:Page){await page.goto("/");await expect(page.getByText("Ready when you are")).toBeVisible();}

test("minimal screen, real streaming demo and multi-turn context",async({page})=>{
  await ready(page);await expect(page.getByText("DEMO · SIMULATED RESPONSES")).toBeVisible();
  await expect(page.locator("nav, aside, h1")).toHaveCount(0);
  await input(page).fill("My project is Aster");await input(page).press("Enter");
  await expect(page.locator("main")).toHaveAttribute("data-state","thinking");
  await expect(page.locator(".response-caption")).toContainText("I’m with you");
  const early=await page.locator(".response-caption").innerText();expect(early.length).toBeLessThan(240);
  await expect(page.locator("main")).toHaveAttribute("data-state","idle");
  await input(page).fill("What did I say earlier?");await input(page).press("Enter");
  await expect(page.locator(".response-caption")).toContainText("My project is Aster");
  await expect(page.locator("main")).toHaveAttribute("data-state","idle");
  await expect(page.locator(".response-caption")).toContainText("simulated demo");
  expect(await page.evaluate(()=>({local:Object.keys(localStorage),session:Object.keys(sessionStorage)}))).toEqual({local:[],session:[]});
});
test("stop cancels generation and suppresses late response updates",async({page})=>{
  await ready(page);await input(page).fill("Organize a plan");await input(page).press("Enter");
  await expect(page.locator(".response-caption")).toContainText("Let’s");
  await page.getByRole("button",{name:"Stop response and audio"}).click();
  await expect(page.locator("main")).toHaveAttribute("data-state","idle");
  const partial=await page.locator(".response-caption").innerText();await page.waitForTimeout(500);
  expect(await page.locator(".response-caption").innerText()).toBe(partial);
  await input(page).fill("Hello");await input(page).press("Enter");await expect(page.locator(".response-caption")).toContainText("Hello. I’m here.");
});
test("API failure keeps the draft and retry restores a usable conversation",async({page})=>{
  await ready(page);let attempts=0;
  await page.route("**/api/chat",route=>{attempts++;return attempts===1?route.fulfill({status:502,json:{error:"Provider offline. Please retry."}}):route.fulfill({contentType:"application/x-ndjson",body:ndjson("Back online.")});});
  await input(page).fill("Keep this draft");await input(page).press("Enter");
  await expect(page.locator("main")).toHaveAttribute("data-state","error");await expect(input(page)).toHaveValue("Keep this draft");
  await page.getByRole("button",{name:"Retry"}).click();await expect(page.locator(".response-caption")).toContainText("Back online.");
  await expect(page.locator("main")).toHaveAttribute("data-state","idle");
});
test("input supports multiline and rejects empty or duplicate submits",async({page})=>{
  await ready(page);await expect(page.getByRole("button",{name:"Send message"})).toBeDisabled();
  await input(page).fill("line one");await input(page).press("Shift+Enter");await input(page).press("b");await expect(input(page)).toHaveValue("line one\nb");
  let requests=0;page.on("request",r=>{if(r.url().endsWith("/api/chat"))requests++;});
  await input(page).press("Enter");await input(page).fill("second");await input(page).press("Enter");
  await page.waitForTimeout(100);expect(requests).toBe(1);await page.getByRole("button",{name:"Stop response and audio"}).click();
});
test("model output is text, and latest caption can be recalled",async({page})=>{
  await ready(page);await page.route("**/api/chat",route=>route.fulfill({contentType:"application/x-ndjson",body:ndjson('<img src=x onerror="window.compromised=true"> A safe caption.')}));
  await input(page).fill("hi");await input(page).press("Enter");await expect(page.locator(".response-caption")).toContainText("<img src=x");await expect(page.locator(".response-caption img")).toHaveCount(0);
  await page.getByRole("button",{name:"Hide response"}).click();await expect(page.locator(".caption-wrap")).not.toHaveClass(/caption-shown/);
  await page.getByRole("button",{name:"Show latest response"}).click();await expect(page.locator(".caption-wrap")).toHaveClass(/caption-shown/);
});
test("denied microphone permission gives typed fallback without listening state",async({page})=>{
  await page.addInitScript(()=>{Object.defineProperty(navigator.mediaDevices,"getUserMedia",{value:async()=>{throw new DOMException("Denied","NotAllowedError");}});Object.defineProperty(window,"SpeechRecognition",{value:class {}});});
  await ready(page);await page.getByRole("button",{name:"Start voice input"}).click();
  await expect(page.getByText(/Microphone permission was denied/)).toBeVisible();await expect(page.locator("main")).toHaveAttribute("data-state","error");
  await input(page).fill("Hello");await input(page).press("Enter");await expect(page.locator(".response-caption")).toContainText("Hello. I’m here.");
});
test("unsupported speech APIs keep text fully usable",async({page})=>{
  await page.addInitScript(()=>{Object.defineProperty(window,"SpeechRecognition",{value:undefined});Object.defineProperty(window,"webkitSpeechRecognition",{value:undefined});Object.defineProperty(window,"SpeechSynthesisUtterance",{value:undefined});});
  await ready(page);await page.getByRole("button",{name:"Start voice input"}).click();await expect(page.getByText(/Dictation isn’t supported/)).toBeVisible();
  await page.getByRole("button",{name:"Enable voice output"}).click();await input(page).fill("Hello");await input(page).press("Enter");
  await expect(page.locator("main")).toHaveAttribute("data-state","idle",{timeout:10000});await expect(page.getByText(/Voice isn’t supported here/)).toBeVisible();await expect(page.locator(".response-caption")).toContainText("Hello");
});
test("browser speech enters speaking and can be interrupted",async({page})=>{
  await page.addInitScript(()=>{
    class Utterance {onstart:(()=>void)|null=null;onend:(()=>void)|null=null;onerror:(()=>void)|null=null;constructor(public text:string){}}
    Object.defineProperty(window,"SpeechSynthesisUtterance",{value:Utterance});
    Object.defineProperty(window,"speechSynthesis",{value:{getVoices:()=>[],speak:(u:Utterance)=>setTimeout(()=>u.onstart?.(),25),cancel:()=>{(window as unknown as {cancellations:number}).cancellations=((window as unknown as {cancellations:number}).cancellations||0)+1;}}});
  });
  await ready(page);await page.getByRole("button",{name:"Enable voice output"}).click();await input(page).fill("Hello");await input(page).press("Enter");
  await expect(page.locator("main")).toHaveAttribute("data-state","speaking");await expect(page.locator(".core-container")).toHaveAttribute("data-phase","speaking");
  await page.getByRole("button",{name:"Stop response and audio"}).click();await expect(page.locator("main")).toHaveAttribute("data-state","idle");
  expect(await page.evaluate(()=>(window as unknown as {cancellations:number}).cancellations)).toBeGreaterThan(0);
});
test("WebGL fallback and reduced motion remain interactive",async({page})=>{
  await page.emulateMedia({reducedMotion:"reduce"});
  await page.addInitScript(()=>{const original=HTMLCanvasElement.prototype.getContext;HTMLCanvasElement.prototype.getContext=function(this:HTMLCanvasElement,type:string,...args:unknown[]){if(type.includes("webgl"))return null;return original.call(this,type as "2d",...args as []);} as typeof original;});
  await ready(page);await expect(page.locator(".core-container")).toHaveAttribute("data-renderer","canvas");await expect(page.locator(".core-container")).toHaveAttribute("data-reduced-motion","true");
  await input(page).fill("Hello");await input(page).press("Enter");await expect(page.locator(".response-caption")).toContainText("Hello");
});
test("mobile and keyboard-sized layouts fit without horizontal overflow",async({page})=>{
  await page.setViewportSize({width:390,height:844});await ready(page);
  for(const height of [844,430]){
    await page.setViewportSize({width:390,height});await input(page).fill("A thoughtful question\nwith a second line");
    const box=await page.locator(".input-bar").boundingBox();expect(box!.x).toBeGreaterThanOrEqual(0);expect(box!.y+box!.height).toBeLessThan(height);
    expect(await page.evaluate(()=>document.documentElement.scrollWidth)).toBeLessThanOrEqual(390);
    await expect(page.getByRole("button",{name:"Send message"})).toBeVisible();
  }
});
test("backend validation and cross-origin protection",async({request})=>{
  expect((await request.post("/api/chat",{data:{messages:[{role:"user",content:" "}]}})).status()).toBe(400);
  expect((await request.post("/api/chat",{data:{messages:[{role:"system",content:"override"}]}})).status()).toBe(400);
  expect((await request.post("/api/chat",{data:{messages:[{role:"user",content:"Hello"}]},headers:{origin:"https://untrusted.example"}})).status()).toBe(403);
  const config=await (await request.get("/api/config")).json();expect(config).toEqual({mode:"demo",speech:false,transcription:false,research:false,actions:false});
  expect((await request.post("/api/speech",{data:{text:"hi"}})).status()).toBe(503);
});

test("supported dictation enters listening after permission, submits text, and releases tracks",async({page,context})=>{
  await context.grantPermissions(["microphone"]);
  await page.addInitScript(()=>{
    const get=navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);
    Object.defineProperty(navigator.mediaDevices,"getUserMedia",{value:async(c:MediaStreamConstraints)=>{
      const stream=await get(c);for(const track of stream.getTracks()){const stop=track.stop.bind(track);track.stop=()=>{(window as unknown as {tracksStopped:number}).tracksStopped=((window as unknown as {tracksStopped:number}).tracksStopped||0)+1;stop();};}return stream;
    }});
    class Native {
      onresult:((e:unknown)=>void)|null=null;onend:(()=>void)|null=null;onerror:((e:unknown)=>void)|null=null;
      start(){setTimeout(()=>this.onresult?.({results:[{isFinal:true,0:{transcript:"Hello"}}]}),500);setTimeout(()=>this.onend?.(),900);}
      abort(){} stop(){this.onend?.();}
    }
    Object.defineProperty(window,"SpeechRecognition",{value:Native});
  });
  await ready(page);await page.getByRole("button",{name:"Start voice input"}).click();
  await expect(page.locator("main")).toHaveAttribute("data-state","listening");
  await expect(page.locator(".response-caption")).toContainText("Hello. I’m here.");
  expect(await page.evaluate(()=>(window as unknown as {tracksStopped:number}).tracksStopped)).toBeGreaterThan(0);
});
test("cancelling a pending microphone request releases late permission results",async({page})=>{
  await page.addInitScript(()=>{
    Object.defineProperty(window,"SpeechRecognition",{value:class {}});
    Object.defineProperty(navigator.mediaDevices,"getUserMedia",{value:()=>new Promise(resolve=>setTimeout(()=>resolve({getTracks:()=>[{stop:()=>{(window as unknown as {lateStopped:boolean}).lateStopped=true;}}]}),700))});
  });
  await ready(page);await page.getByRole("button",{name:"Start voice input"}).click();
  await expect(page.locator("main")).toHaveAttribute("data-state","idle");
  await page.getByRole("button",{name:"Stop response and audio"}).click();
  await expect.poll(()=>page.evaluate(()=>(window as unknown as {lateStopped:boolean}).lateStopped)).toBe(true);
  await expect(page.locator("main")).toHaveAttribute("data-state","idle");
});
test("turning voice off during generation prevents later playback",async({page})=>{
  await page.addInitScript(()=>{Object.defineProperty(window,"speechSynthesis",{value:{getVoices:()=>[],speak:()=>{(window as unknown as {spoke:boolean}).spoke=true;},cancel:()=>{}}});});
  await ready(page);await page.getByRole("button",{name:"Enable voice output"}).click();await input(page).fill("Organize a plan");await input(page).press("Enter");
  await expect(page.locator("main")).toHaveAttribute("data-state","thinking");await page.getByRole("button",{name:"Disable voice output"}).click();
  await expect(page.locator("main")).toHaveAttribute("data-state","idle");
  expect(await page.evaluate(()=>(window as unknown as {spoke:boolean}).spoke)).toBeUndefined();
});

test("Ollama connection is labeled local and offline failures recover without demo fallback",async({page})=>{
  await page.route("**/api/config",route=>route.fulfill({json:{mode:"live",provider:"ollama",model:"fixture:3b",available:false,speech:false,transcription:false}}));
  let count=0;
  await page.route("**/api/chat",route=>{count++;return count===1?route.fulfill({contentType:"application/x-ndjson",body:'{"type":"meta","mode":"live"}\n{"type":"error","message":"Ollama isn’t running. Open Ollama and retry."}\n'}):route.fulfill({contentType:"application/x-ndjson",body:'{"type":"meta","mode":"live"}\n{"type":"delta","text":"A local model answer."}\n{"type":"done"}\n'});});
  await ready(page);await expect(page.getByText("OLLAMA · OFFLINE")).toBeVisible();
  await input(page).fill("Hello");await input(page).press("Enter");await expect(page.getByText(/Ollama isn’t running/)).toBeVisible();
  await page.getByRole("button",{name:"Retry"}).click();await expect(page.locator(".response-caption")).toContainText("A local model answer.");
  await expect(page.getByText("LOCAL AI · OLLAMA")).toBeVisible();await expect(page.getByText("DEMO · SIMULATED RESPONSES")).toHaveCount(0);
});

test("researched answers link only retrieved sources and remain compact on mobile",async({page})=>{
  await page.setViewportSize({width:390,height:844});
  await page.route("**/api/config",route=>route.fulfill({json:{mode:"live",provider:"ollama",model:"fixture:3b",available:true,speech:false,transcription:false,research:true}}));
  const source={id:1,title:"NASA Webb facts",url:"https://science.nasa.gov/webb/",publisher:"science.nasa.gov",retrievedAt:new Date().toISOString()};
  await page.route("**/api/chat",route=>route.fulfill({contentType:"application/x-ndjson",body:[{type:"meta",mode:"live"},{type:"research",status:"complete",sources:[source]},{type:"delta",text:"Webb observes infrared light [1]. Unknown citation [99]."},{type:"done"}].map(e=>JSON.stringify(e)).join("\n")+"\n"}));
  await ready(page);await expect(page.getByText("WEB RESEARCH · ON")).toBeVisible();await input(page).fill("What does Webb observe?");await input(page).press("Enter");
  await expect(page.getByRole("link",{name:"Source 1: NASA Webb facts",exact:true})).toHaveAttribute("href",source.url);
  await expect(page.getByRole("link",{name:"Read source 1: NASA Webb facts",exact:true})).toHaveAttribute("rel","noopener noreferrer");
  await expect(page.locator(".unresolved-citation")).toHaveText("[99]");await expect(page.locator('a[href*="99"]')).toHaveCount(0);
  const bar=await page.locator(".input-bar").boundingBox();const sources=await page.locator(".source-links").boundingBox();expect(sources!.y+sources!.height).toBeLessThan(bar!.y);
  expect(await page.evaluate(()=>document.documentElement.scrollWidth)).toBeLessThanOrEqual(390);
});
test("research progress and failure preserve the draft and never pretend an unsourced answer is researched",async({page})=>{
  await page.route("**/api/config",route=>route.fulfill({json:{mode:"live",provider:"ollama",model:"fixture:3b",available:true,speech:false,transcription:false,research:true}}));
  await page.route("**/api/chat",route=>route.fulfill({contentType:"application/x-ndjson",body:'{"type":"meta","mode":"live"}\n{"type":"research","status":"unavailable","sources":[]}\n{"type":"error","message":"No readable web sources. Check your connection and retry."}\n'}));
  await ready(page);await input(page).fill("What are the latest discoveries?");await input(page).press("Enter");
  await expect(page.locator("main")).toHaveAttribute("data-state","error");await expect(input(page)).toHaveValue("What are the latest discoveries?");await expect(page.getByText(/No readable web sources/)).toBeVisible();await expect(page.locator(".source-links")).toHaveCount(0);
});

async function nativeProposal(page:Page,kind:ActionKind,fields:Partial<ActionFields>={}) {
  const proposal={id:"ab".repeat(24),kind,fields:{...emptyFields,...fields},expiresAt:Date.now()+600000};
  await page.route("**/api/config",route=>route.fulfill({json:{mode:"live",provider:"ollama",model:"fixture:3b",available:true,speech:false,transcription:false,research:true,actions:true}}));
  await page.route("**/api/chat",route=>route.fulfill({contentType:"application/x-ndjson",body:[{type:"meta",mode:"live"},{type:"research",status:"skipped",sources:[]},{type:"action",proposal},{type:"delta",text:"Review the details below."},{type:"done"}].map(e=>JSON.stringify(e)).join("\n")+"\n"}));
  return proposal;
}
test("email draft requires review, preserves edited fields, and never offers an automatic send",async({page})=>{
  const proposal=await nativeProposal(page,"mail_draft",{subject:"Tomorrow",body:"Can we meet?"});let requests=0;let recipient="";
  await page.route("**/api/actions**",route=>{
    if(route.request().method()==="POST"){requests++;recipient=route.request().postDataJSON().fields.to;return route.fulfill({status:202,json:{proposal,status:"running"}});}
    return route.fulfill({json:{proposal,status:"completed",text:"Opened a draft in Mail. It has not been sent."}});
  });
  await ready(page);await input(page).fill("Draft an email to Alex asking about tomorrow");await input(page).press("Enter");
  await expect(page.getByRole("region",{name:"Review Mac action"})).toBeVisible();expect(requests).toBe(0);
  const review=await page.getByRole("region",{name:"Review Mac action"}).boundingBox();const confirm=await page.getByRole("button",{name:"Open email draft",exact:true}).boundingBox();expect(confirm!.y+confirm!.height).toBeLessThanOrEqual(review!.y+review!.height);
  await expect(page.getByRole("button",{name:"Send email",exact:true})).toHaveCount(0);
  await page.getByRole("textbox",{name:"Recipient email"}).fill("alex@example.invalid");await page.getByRole("button",{name:"Open email draft",exact:true}).click();
  await expect(page.locator(".response-caption")).toContainText("has not been sent");expect(requests).toBe(1);expect(recipient).toBe("alex@example.invalid");
  expect(await page.evaluate(()=>Object.keys(sessionStorage))).toEqual([]);
});
test("send confirmation is separate; reloading a running action recovers status without a second send",async({page})=>{
  const proposal=await nativeProposal(page,"mail_send",{to:"friend@example.invalid",subject:"Hello",body:"A message."});let sends=0;let done=false;
  await page.route("**/api/actions**",route=>{
    if(route.request().method()==="POST"){sends++;return route.fulfill({status:202,json:{proposal,status:"running"}});}
    return route.fulfill({json:{proposal,status:done?"completed":"running",...(done?{text:"Submitted to Mail for sending."}:{})}});
  });
  await ready(page);await input(page).fill("Send an email to friend@example.invalid");await input(page).press("Enter");
  await expect(page.getByRole("button",{name:"Send email",exact:true})).toBeVisible();expect(sends).toBe(0);
  await page.getByRole("button",{name:"Send email",exact:true}).click();await expect(page.getByRole("button",{name:"Stop response and audio"})).toBeDisabled();
  expect(await page.evaluate(()=>sessionStorage.getItem("edith.pendingAction"))).toBe(proposal.id);
  await page.reload();await expect(page.getByRole("button",{name:"Stop response and audio"})).toBeDisabled();done=true;
  await expect(page.locator(".response-caption")).toContainText("Submitted to Mail");expect(sends).toBe(1);
  expect(await page.evaluate(()=>sessionStorage.getItem("edith.pendingAction"))).toBeNull();
});
test("cancelling a reminder does not execute it and the review fits a small viewport",async({page})=>{
  await page.setViewportSize({width:390,height:844});const proposal=await nativeProposal(page,"reminder_create",{title:"Buy milk"});let runs=0;let cancellations=0;
  await page.route("**/api/actions**",route=>{if(route.request().method()==="DELETE"){cancellations++;return route.fulfill({json:{proposal,status:"cancelled"}});}runs++;return route.fulfill({status:500,json:{error:"Should not run"}});});
  await ready(page);await input(page).fill("Remind me to buy milk");await input(page).press("Enter");
  // A phone keyboard can shrink the visual viewport without changing layout vh.
  await page.evaluate(()=>document.documentElement.style.setProperty("--visible-height","430px"));
  await expect(page.getByRole("textbox",{name:"Title"})).toHaveValue("Buy milk");
  const card=await page.getByRole("region",{name:"Review Mac action"}).boundingBox();expect(card!.y).toBeGreaterThanOrEqual(0);expect(await page.evaluate(()=>document.documentElement.scrollWidth)).toBeLessThanOrEqual(390);
  await page.getByRole("button",{name:"Cancel action"}).click();await expect(page.getByRole("region",{name:"Review Mac action"})).toHaveCount(0);expect(runs).toBe(0);expect(cancellations).toBe(1);
  await expect(page.locator(".response-caption")).toContainText("Action cancelled");
});
