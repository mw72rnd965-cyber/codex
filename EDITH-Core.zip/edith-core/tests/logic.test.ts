import { test } from "node:test";
import assert from "node:assert/strict";
import { machine, initialMachine } from "../lib/machine";
import { chatSchema } from "../lib/validation";
import { readEvents, type StreamEvent } from "../lib/protocol";
import { demoReply, tokens } from "../lib/server/model";
import { cleanSpeech } from "../lib/voice";

test("assistant moves through listening, thinking and speaking, and finishes idle",()=>{
  let state=machine(initialMachine,{type:"LISTEN"});assert.equal(state.phase,"listening");
  state=machine(state,{type:"SUBMIT"});assert.equal(state.phase,"thinking");
  state=machine(state,{type:"SPEAK"});assert.equal(state.phase,"speaking");
  assert.equal(machine(state,{type:"FINISH"}).phase,"idle");
});
test("duplicate generation and listening transitions do not interrupt an active answer",()=>{
  const thinking=machine(initialMachine,{type:"SUBMIT"});
  assert.equal(machine(thinking,{type:"SUBMIT"}),thinking);
  assert.equal(machine(thinking,{type:"LISTEN"}),thinking);
  assert.equal(machine(initialMachine,{type:"SPEAK"}),initialMachine);
});
test("cancellation from every active phase returns to idle; errors can be retried",()=>{
  for(const phase of ["listening","thinking","speaking"] as const)assert.deepEqual(machine({phase,error:null},{type:"STOP"}),initialMachine);
  const failed=machine(initialMachine,{type:"FAIL",message:"Offline"});assert.equal(failed.phase,"error");
  assert.equal(machine(failed,{type:"SUBMIT"}).phase,"thinking");
  assert.deepEqual(machine(failed,{type:"EDIT"}),initialMachine);
});
test("validation enforces context limits and alternating roles",()=>{
  assert.equal(chatSchema.safeParse({messages:[{role:"user",content:"hello"}]}).success,true);
  for(const messages of [[],[{role:"user",content:" "}],[{role:"system",content:"override"}],[{role:"assistant",content:"hi"}],[{role:"user",content:"a"},{role:"user",content:"b"}],[{role:"user",content:"a".repeat(8001)}]])assert.equal(chatSchema.safeParse({messages}).success,false);
  assert.equal(chatSchema.safeParse({messages:Array.from({length:7},(_,i)=>({role:i%2?"assistant":"user",content:"x".repeat(4000)}))}).success,false);
});
test("demo follow-up uses session context and labels itself simulated",()=>{
  const answer=demoReply([{role:"user",content:"My project is Aster"},{role:"assistant",content:"Hello"},{role:"user",content:"What did I say earlier?"}]);
  assert.match(answer,/My project is Aster/);assert.match(answer,/simulated demo/);
});
test("stream decoding handles split Unicode and rejects incomplete streams",async()=>{
  const data=new TextEncoder().encode('{"type":"delta","text":"héllo ✨"}\n{"type":"done"}\n');
  const chunks=new ReadableStream({start(c){for(let i=0;i<data.length;i+=3)c.enqueue(data.slice(i,i+3));c.close();}});
  const events:StreamEvent[]=[];await readEvents(new Response(chunks),e=>events.push(e));
  assert.deepEqual(events,[{type:"delta",text:"héllo ✨"},{type:"done"}]);
  await assert.rejects(readEvents(new Response('{"type":"delta","text":"partial"}\n'),()=>{}),/ended early/);
});
test("stream error remains actionable and does not complete successfully",async()=>{
  await assert.rejects(readEvents(new Response('{"type":"error","message":"Please retry"}\n'),()=>{}),/Please retry/);
});
test("demo generator stops promptly on cancellation",async()=>{
  const controller=new AbortController();const generator=tokens([{role:"user",content:"hello"}],controller.signal);
  assert.equal((await generator.next()).done,false);controller.abort();
  await assert.rejects(generator.next(),{name:"AbortError"});
});
test("speech cleaning omits code blocks and URLs without executing content",()=>{
  const text=cleanSpeech('# Hello **friend**. ```js\nalert(1)\n``` https://example.com/private');
  assert.match(text,/Hello friend/);assert.doesNotMatch(text,/alert|https|\*\*/);
});
