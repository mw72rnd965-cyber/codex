import { test } from "node:test";
import assert from "node:assert/strict";
import { createServer, type IncomingMessage, type ServerResponse } from "node:http";
import { promisify } from "node:util";
import { execFile } from "node:child_process";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { configuration, safeError, tokens } from "../lib/server/model";
import { ollamaAvailable, ollamaBaseUrl } from "../lib/server/ollama";

async function withOllama(handler: (req: IncomingMessage, res: ServerResponse) => void, run: (base: string) => Promise<void>) {
  const names=["AI_PROVIDER","AI_MODEL","AI_API_KEY","OLLAMA_BASE_URL"];
  const original=Object.fromEntries(names.map(name=>[name,process.env[name]]));
  const server=createServer(handler);
  await new Promise<void>(resolve=>server.listen(0,"127.0.0.1",resolve));
  const address=server.address();assert.ok(address&&typeof address==="object");
  const base=`http://127.0.0.1:${address.port}`;
  process.env.AI_PROVIDER="ollama";process.env.AI_MODEL="fixture:3b";process.env.OLLAMA_BASE_URL=base;delete process.env.AI_API_KEY;
  try { await run(base); }
  finally {
    for(const [name,value] of Object.entries(original)){if(value===undefined)delete process.env[name];else process.env[name]=value;}
    server.closeAllConnections();await new Promise<void>(resolve=>server.close(()=>resolve()));
  }
}

test("Ollama streams split Unicode and conversation context without authentication or reasoning text",async()=>{
  let body: {model:string;think:boolean;messages:{role:string;content:string}[];options:{num_ctx:number}}|undefined;
  let auth:string|undefined;
  await withOllama(async(req,res)=>{
    let raw="";for await(const part of req)raw+=part;body=JSON.parse(raw);auth=req.headers.authorization;
    const bytes=Buffer.from([
      {message:{thinking:"Internal thoughts, excluded",content:""},done:false},
      {message:{content:"Hello ✨ "},done:false},
      {message:{content:"Aster."},done:true},
    ].map(frame=>JSON.stringify(frame)).join("\n")+"\n");
    res.writeHead(200,{"Content-Type":"application/x-ndjson"});
    for(let i=0;i<bytes.length;i+=7)res.write(bytes.subarray(i,i+7));res.end();
  },async()=>{
    // An unrelated cloud key must never reach the local endpoint.
    process.env.AI_API_KEY="unrelated-test-fixture";
    assert.equal(configuration().mode,"live");assert.equal(configuration().provider,"ollama");assert.equal(configuration().speech,false);
    let answer="";for await(const delta of tokens([{role:"user",content:"My project is Aster"},{role:"assistant",content:"I’m here"},{role:"user",content:"What is my project?"}],new AbortController().signal))answer+=delta;
    assert.equal(answer,"Hello ✨ Aster.");assert.equal(auth,undefined);assert.equal(body!.model,"fixture:3b");assert.equal(body!.think,false);assert.equal(body!.options.num_ctx,8192);
    assert.equal(body!.messages[0].role,"system");assert.match(body!.messages[1].content,/Aster/);assert.equal(body!.messages.at(-1)!.content,"What is my project?");
  });
});
test("Ollama status detects the selected installed model and restricts connections to loopback",async()=>{
  await withOllama((_req,res)=>{res.setHeader("Content-Type","application/json");res.end(JSON.stringify({models:[{name:"fixture:3b"}]}));},async()=>{
    assert.equal(await ollamaAvailable(),true);process.env.AI_MODEL="missing";assert.equal(await ollamaAvailable(),false);
    process.env.OLLAMA_BASE_URL="https://external.example";assert.throws(()=>ollamaBaseUrl(),/loopback/);
  });
});
test("missing models, in-stream errors, and incomplete responses fail instead of switching to demo",async()=>{
  for(const kind of ["missing","stream-error","truncated"]){
    await withOllama((_req,res)=>{
      if(kind==="missing"){res.writeHead(404);res.end();return;}
      res.setHeader("Content-Type","application/x-ndjson");res.end(kind==="stream-error"?'{"error":"private-internal-diagnostic"}\n':'{"message":{"content":"partial"},"done":false}\n');
    },async()=>{
      let error:unknown;try{for await(const _token of tokens([{role:"user",content:"hello"}],new AbortController().signal))void _token;}catch(e){error=e;}
      assert.ok(error);assert.doesNotMatch(safeError(error),/private-internal-diagnostic/);assert.match(safeError(error),/Ollama/);assert.equal(configuration().mode,"live");
    });
  }
});
test("stop aborts the upstream Ollama stream",async()=>{
  let closed=false;
  await withOllama((_req,res)=>{res.on("close",()=>{closed=true;});res.writeHead(200,{"Content-Type":"application/x-ndjson"});res.write('{"message":{"content":"Hello"},"done":false}\n');},async()=>{
    const controller=new AbortController();const stream=tokens([{role:"user",content:"Hello"}],controller.signal);
    assert.equal((await stream.next()).value,"Hello");controller.abort();await assert.rejects(stream.next(),{name:"AbortError"});
    for(let i=0;i<50&&!closed;i++)await new Promise(resolve=>setTimeout(resolve,10));assert.equal(closed,true);
  });
});
test("model setup reuses an installed chat model and warms it",async()=>{
  const dir=await mkdtemp(join(tmpdir(),"edith-ollama-"));let pulled=false;let warmed="";
  try {
    await withOllama(async(req,res)=>{
      let raw="";for await(const part of req)raw+=part;const data=raw?JSON.parse(raw):{};res.setHeader("Content-Type","application/json");
      if(req.url==="/api/tags")res.end(JSON.stringify({models:[{name:"nomic-embed-text:latest",size:100},{name:"llama3.2:3b",size:200}]}));
      else if(req.url==="/api/show")res.end(JSON.stringify({capabilities:data.model.startsWith("nomic")?["embedding"]:["completion"]}));
      else if(req.url==="/api/pull"){pulled=true;res.end('{"status":"success"}\n');}
      else if(req.url==="/api/generate"){warmed=data.model;res.end('{"done":true}');}
      else{res.writeHead(404);res.end();}
    },async(base)=>{
      const result=await promisify(execFile)(process.execPath,["scripts/setup-ollama.mjs",join(dir,"model"),join(dir,"saved")],{env:{...process.env,OLLAMA_BASE_URL:base,EDITH_MODEL:""}});
      assert.match(result.stdout,/No API key needed/);assert.equal((await readFile(join(dir,"model"),"utf8")).trim(),"llama3.2:3b");assert.equal(warmed,"llama3.2:3b");assert.equal(pulled,false);
    });
  }finally{await rm(dir,{recursive:true,force:true});}
});
test("model setup downloads and verifies completion when no chat model is installed",async()=>{
  const dir=await mkdtemp(join(tmpdir(),"edith-ollama-pull-"));let pulled="";let warmed=false;
  try {
    await withOllama(async(req,res)=>{
      let raw="";for await(const part of req)raw+=part;const data=raw?JSON.parse(raw):{};res.setHeader("Content-Type","application/json");
      if(req.url==="/api/tags")res.end('{"models":[]}');
      else if(req.url==="/api/pull"){pulled=data.model;res.end('{"status":"verifying sha256 digest"}\n{"status":"success"}\n');}
      else if(req.url==="/api/show")res.end('{"capabilities":["completion"]}');
      else if(req.url==="/api/generate"){warmed=true;res.end('{"done":true}');}
      else{res.writeHead(404);res.end();}
    },async(base)=>{
      await promisify(execFile)(process.execPath,["scripts/setup-ollama.mjs",join(dir,"model")],{env:{...process.env,OLLAMA_BASE_URL:base,EDITH_MODEL:""}});
      assert.equal(pulled,"qwen2.5:3b");assert.equal(warmed,true);assert.equal((await readFile(join(dir,"model"),"utf8")).trim(),pulled);
    });
  }finally{await rm(dir,{recursive:true,force:true});}
});
