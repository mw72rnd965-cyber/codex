import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { runInNewContext } from "node:vm";
import { emptyFields,type ActionFields,type ActionKind } from "../lib/actions";
const source=readFileSync("native/mac-actions.js","utf8");
type NativeDate={isNil:()=>boolean;timeIntervalSince1970:number};
function execute(kind:ActionKind,fields:Partial<ActionFields>,allowed=true,options:{authorized?:boolean;callbackMissing?:boolean;permissionPending?:boolean;cancelled?:boolean}={}) {
  let result:{ok:boolean;text?:string;code?:string}|undefined;let savedEvent:Record<string,unknown>|undefined;let savedReminder:Record<string,unknown>|undefined;let sent=0;let drafts=0;
  let authorization=options.authorized?3:0;let permissionRequests=0;let ticks=0;const phases:string[]=[];
  const wrap=(value:unknown)=>({value,isNil:()=>false,writeToFileAtomicallyEncodingError:(path:string)=>{const data=JSON.parse(String(value));if(path.endsWith('/result.json'))result=data;else if(path.endsWith('/progress.json'))phases.push(data.phase);return true;}});
  const nativeDate=(seconds:number):NativeDate=>({isNil:()=>false,timeIntervalSince1970:seconds});
  const target={isNil:()=>false,allowsContentModifications:true,title:wrap("Personal")};
  const collection=(items:unknown[])=>({isNil:()=>false,count:items.length,objectAtIndex:(i:number)=>items[i]});
  const requestPermission=(callback:(ok:boolean)=>void)=>{permissionRequests++;if(!options.callbackMissing&&!options.permissionPending){authorization=allowed?3:2;callback(allowed);}};
  const store={respondsToSelector:()=>true,requestFullAccessToEventsWithCompletion:requestPermission,requestFullAccessToRemindersWithCompletion:requestPermission,defaultCalendarForNewEvents:target,defaultCalendarForNewReminders:target,saveEventSpanCommitError:(event:Record<string,unknown>)=>{savedEvent=event;return true;},saveReminderCommitError:(reminder:Record<string,unknown>)=>{savedReminder=reminder;return true;},predicateForEventsWithStartDateEndDateCalendars:()=>({}),eventsMatchingPredicate:()=>collection([{title:wrap("Recurring meeting occurrence"),startDate:nativeDate(1792051200),endDate:nativeDate(1792054800),location:wrap("Office")}]),predicateForIncompleteRemindersWithDueDateStartingEndingCalendars:()=>({}),fetchRemindersMatchingPredicateCompletion:(_predicate:unknown,callback:(items:unknown)=>void)=>callback(collection([{title:wrap("Pending reminder"),dueDateComponents:null}]))};
  const job={kind,fields:{...emptyFields,...fields},deadline:Date.now()+120000};
  const foundation=Object.assign(wrap,{
    NSProcessInfo:{processInfo:{arguments:collection([wrap("applet"),wrap("/tmp/edith-action-fixture")])}},NSString:{stringWithContentsOfFileEncodingError:()=>wrap(JSON.stringify(job))},NSSelectorFromString:(selector:string)=>selector,
    NSDate:{dateWithTimeIntervalSince1970:nativeDate,dateWithTimeIntervalSinceNow:()=>({})},NSRunLoop:{currentRunLoop:{runUntilDate:()=>{ticks++;if(options.callbackMissing&&!options.permissionPending)authorization=allowed?3:2;}}},EKEventStore:{alloc:{init:store},authorizationStatusForEntityType:()=>authorization},EKEvent:{eventWithEventStore:()=>({})},EKReminder:{reminderWithEventStore:()=>({addAlarm:()=>{}})},NSCalendar:{currentCalendar:{componentsFromDate:()=>({}),dateFromComponents:()=>nativeDate(1792051200)}},NSTimeZone:{localTimeZone:{}},EKAlarm:{alarmWithAbsoluteDate:()=>({})},NSApplication:{sharedApplication:{activateIgnoringOtherApps:()=>{}}},NSFileManager:{defaultManager:{removeItemAtPathError:()=>{},fileExistsAtPath:()=>!options.cancelled}},
  });
  const outgoing:Record<string,unknown>[]=[];
  const messages=[{subject:()=>"An older inbox message",sender:()=>"friend@example.invalid",content:()=>"Older preview"},{subject:()=>"A newer inbox message",sender:()=>"friend@example.invalid",content:()=>"Private message text"}];
  const collectionMessages=Object.assign(()=>messages,{dateReceived:()=>[new Date("2026-10-13T10:00:00Z"),new Date("2026-10-14T10:00:00Z")]});
  const mail={accounts:()=>[{}],inbox:{messages:collectionMessages},OutgoingMessage:(values:Record<string,unknown>)=>({...values,toRecipients:[]}),ToRecipient:(values:unknown)=>values,outgoingMessages:{push:(message:Record<string,unknown>)=>{drafts++;outgoing.push(message);}},activate:()=>{},send:()=>{sent++;return true;}};
  class FixtureDate extends Date {static now(){return Date.now()+ticks*130000;}}
  // Permission-pending tests advance native time without a two-minute sleep.
  const TestDate=options.permissionPending?FixtureDate:Date;
  runInNewContext(source+"\nrun();",{ObjC:{import:()=>{},unwrap:(value:{value?:unknown}|unknown)=>value&&typeof value==="object"&&"value" in value?value.value:value},$:foundation,Ref:()=>({}),Application:()=>mail,Date:TestDate,JSON,isFinite},{timeout:1000});
  return {result,savedEvent,savedReminder,sent,drafts,outgoing,permissionRequests,phases};
}
test("native Calendar permission denial prevents writes; user text is passed as data to EventKit",()=>{
  const fields={title:'Meeting "; do shell script "unsafe"',start:"2026-10-15T10:00:00+02:00",end:"2026-10-15T11:00:00+02:00"};
  const denied=execute("calendar_create",fields,false);assert.deepEqual(denied.result,{ok:false,code:"permission"});assert.equal(denied.savedEvent,undefined);
  const accepted=execute("calendar_create",fields);assert.equal(accepted.result!.ok,true);assert.match(accepted.result!.text!,/Created/);
  assert.equal((accepted.savedEvent!.title as {value:string}).value,fields.title);assert.equal((accepted.savedEvent!.startDate as NativeDate).timeIntervalSince1970,Date.parse(fields.start)/1000);
});
test("native Reminders create only after permission and report actual saved results",()=>{
  const result=execute("reminder_create",{title:"Buy milk"});assert.equal(result.result!.ok,true);assert.equal((result.savedReminder!.title as {value:string}).value,"Buy milk");assert.match(result.result!.text!,/No due date/);
  assert.equal(execute("reminder_create",{title:"Buy milk"},false).savedReminder,undefined);
});
test("native email draft does not send; the distinct send action reports submission rather than delivery",()=>{
  const fields={to:"friend@example.invalid",subject:"Tomorrow",body:'Hello!\n"; malicious code is plain text.'};
  const draft=execute("mail_draft",fields);assert.equal(draft.sent,0);assert.equal(draft.drafts,1);assert.match(draft.result!.text!,/not been sent/);assert.equal(draft.outgoing[0].content,fields.body+"\n");
  const send=execute("mail_send",fields);assert.equal(send.sent,1);assert.match(send.result!.text!,/Submitted to Mail/);assert.match(send.result!.text!,/Delivery depends/);
});
test("Calendar reads use EventKit occurrence results; Reminders and Mail reads return only bounded text without writes",()=>{
  const cal=execute("calendar_read",{start:"2026-10-14T00:00:00Z",end:"2026-10-15T00:00:00Z"});assert.equal(cal.result!.ok,true);assert.match(cal.result!.text!,/Recurring meeting occurrence/);assert.equal(cal.savedEvent,undefined);
  const reminders=execute("reminder_read",{});assert.equal(reminders.result!.ok,true);assert.match(reminders.result!.text!,/Pending reminder/);assert.equal(reminders.savedReminder,undefined);
  const mail=execute("mail_read",{});assert.equal(mail.result!.ok,true);assert.match(mail.result!.text!,/Private message text/);assert.ok(mail.result!.text!.indexOf("A newer")<mail.result!.text!.indexOf("An older"));assert.equal(mail.sent,0);assert.equal(mail.drafts,0);
});
test("dated reminders create native due-date components and an alarm after permission",()=>{
  const result=execute("reminder_create",{title:"Buy milk",due:"2026-10-15T17:00:00+02:00"});assert.equal(result.result!.ok,true);assert.ok(result.savedReminder!.dueDateComponents);assert.match(result.result!.text!,/Due:/);
});
test("Calendar with existing access never waits on another permission callback",()=>{
  const result=execute("calendar_read",{start:"2026-10-15T00:00:00Z",end:"2026-10-16T00:00:00Z"},true,{authorized:true,callbackMissing:true});
  assert.equal(result.result!.ok,true);assert.equal(result.permissionRequests,0);assert.ok(result.phases.includes("reading"));
});
test("Calendar observes granted OS permission even when the JS completion callback is not delivered",()=>{
  const result=execute("calendar_read",{start:"2026-10-15T00:00:00Z",end:"2026-10-16T00:00:00Z"},true,{callbackMissing:true});
  assert.equal(result.result!.ok,true);assert.equal(result.permissionRequests,1);assert.match(result.result!.text!,/Recurring meeting/);
});
test("pending Calendar permission reports the permission stage and cannot read or write",()=>{
  const result=execute("calendar_create",{title:"Meeting",start:"2026-10-15T10:00:00Z",end:"2026-10-15T11:00:00Z"},true,{permissionPending:true});
  assert.deepEqual(result.result,{ok:false,code:"permission_timeout"});assert.equal(result.savedEvent,undefined);assert.ok(!result.phases.includes("saving"));
});
test("a job removed by the server cannot make a late Calendar write",()=>{
  const result=execute("calendar_create",{title:"Meeting",start:"2026-10-15T10:00:00Z",end:"2026-10-15T11:00:00Z"},true,{cancelled:true});
  assert.deepEqual(result.result,{ok:false,code:"timeout"});assert.equal(result.savedEvent,undefined);assert.equal(result.permissionRequests,0);
});
