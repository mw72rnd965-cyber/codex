import type { NextConfig } from "next";
const config: NextConfig = { poweredByHeader: false, devIndicators: false, serverExternalPackages:["jsdom","@mozilla/readability","cheerio","fast-xml-parser"],experimental: { cpus: 2 } };
export default config;
