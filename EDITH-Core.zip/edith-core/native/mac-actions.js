/* global ObjC, $, Ref, Application */
/* exported run */
// JavaScript for Automation, compiled into a local app with explicit macOS
// privacy descriptions. EventKit expands recurring calendar occurrences.
ObjC.import("Foundation");
ObjC.import("EventKit");
ObjC.import("AppKit");
function fail(code) { var error=new Error(code);error.edithCode=code;throw error; }
function unwrap(value) { return ObjC.unwrap(value); }
function isNil(value) { return !value||value.isNil(); }
function date(value) { var time=Date.parse(value);if(!isFinite(time))fail("native");return $.NSDate.dateWithTimeIntervalSince1970(time/1000); }
function dateText(value) { return isNil(value)?"No due date":new Date(Number(value.timeIntervalSince1970)*1000).toLocaleString(); }
function wait(done,deadline) {
  while(!done()) {if(Date.now()>deadline)fail("timeout");$.NSRunLoop.currentRunLoop.runUntilDate($.NSDate.dateWithTimeIntervalSinceNow(0.1));}
}
function permission(store,type,deadline) {
  var complete=false,allowed=false;
  var callback=function(granted){allowed=Boolean(granted);complete=true;};
  var selector=type===0?"requestFullAccessToEventsWithCompletion:":"requestFullAccessToRemindersWithCompletion:";
  if(store.respondsToSelector($.NSSelectorFromString(selector))) {
    if(type===0)store.requestFullAccessToEventsWithCompletion(callback);
    else store.requestFullAccessToRemindersWithCompletion(callback);
  }else store.requestAccessToEntityTypeCompletion(type,callback);
  wait(function(){return complete;},deadline);if(!allowed)fail("permission");
}
function checkDeadline(job) {if(Date.now()>job.deadline)fail("timeout");}
function calendar(job) {
  var store=$.EKEventStore.alloc.init;permission(store,0,job.deadline);checkDeadline(job);
  var fields=job.fields;
  if(job.kind==="calendar_create") {
    var target=store.defaultCalendarForNewEvents;if(isNil(target)||!target.allowsContentModifications)fail("account");
    var event=$.EKEvent.eventWithEventStore(store);event.calendar=target;
    event.title=$(fields.title);event.startDate=date(fields.start);event.endDate=date(fields.end);
    event.location=$(fields.location);event.notes=$(fields.notes);checkDeadline(job);
    var error=Ref();if(!store.saveEventSpanCommitError(event,0,true,error))fail("native");
    return "Created “"+fields.title+"” in "+unwrap(target.title)+".\n"+dateText(event.startDate)+" → "+dateText(event.endDate);
  }
  var predicate=store.predicateForEventsWithStartDateEndDateCalendars(date(fields.start),date(fields.end),null);
  var events=store.eventsMatchingPredicate(predicate);var items=[];
  for(var i=0;i<Number(events.count);i++)items.push(events.objectAtIndex(i));
  items.sort(function(a,b){return Number(a.startDate.timeIntervalSince1970)-Number(b.startDate.timeIntervalSince1970);});
  if(!items.length)return "No events found in your Calendar for that period.";
  return "From your Calendar (up to 10 events):\n\n"+items.slice(0,10).map(function(item){return unwrap(item.title)+"\n"+dateText(item.startDate)+" → "+dateText(item.endDate)+(isNil(item.location)?"":"\n"+unwrap(item.location));}).join("\n\n");
}
function reminders(job) {
  var store=$.EKEventStore.alloc.init;permission(store,1,job.deadline);checkDeadline(job);
  var fields=job.fields;
  if(job.kind==="reminder_create") {
    var target=store.defaultCalendarForNewReminders;if(isNil(target)||!target.allowsContentModifications)fail("account");
    var reminder=$.EKReminder.reminderWithEventStore(store);reminder.calendar=target;reminder.title=$(fields.title);reminder.notes=$(fields.notes);
    if(fields.due) {
      var due=date(fields.due);var components=$.NSCalendar.currentCalendar.componentsFromDate(124,due);
      components.timeZone=$.NSTimeZone.localTimeZone;reminder.dueDateComponents=components;
      reminder.addAlarm($.EKAlarm.alarmWithAbsoluteDate(due));
    }
    checkDeadline(job);var error=Ref();if(!store.saveReminderCommitError(reminder,true,error))fail("native");
    return "Added “"+fields.title+"” to "+unwrap(target.title)+(fields.due?".\nDue: "+dateText(date(fields.due)):". No due date.");
  }
  var predicate=store.predicateForIncompleteRemindersWithDueDateStartingEndingCalendars(null,null,null);
  var complete=false,list;
  store.fetchRemindersMatchingPredicateCompletion(predicate,function(items){list=items;complete=true;});
  wait(function(){return complete;},job.deadline);if(isNil(list))fail("native");
  var items=[];for(var i=0;i<Number(list.count);i++)items.push(list.objectAtIndex(i));
  function dueDate(item){return isNil(item.dueDateComponents)?null:$.NSCalendar.currentCalendar.dateFromComponents(item.dueDateComponents);}
  items.sort(function(a,b){var x=dueDate(a),y=dueDate(b);return (isNil(x)?Infinity:Number(x.timeIntervalSince1970))-(isNil(y)?Infinity:Number(y.timeIntervalSince1970));});
  if(!items.length)return "There are no incomplete reminders in your Mac’s Reminders app.";
  return "From your Reminders (up to 10 incomplete items):\n\n"+items.slice(0,10).map(function(item){return unwrap(item.title)+"\n"+dateText(dueDate(item));}).join("\n\n");
}
function mail(job) {
  var app=Application("Mail");var fields=job.fields;checkDeadline(job);
  if(!app.accounts().length)fail("account");
  if(job.kind==="mail_read") {
    // Fetch received-date metadata in bulk and select the newest five; the
    // mailbox's GUI sort order does not decide which messages are read.
    var messages=app.inbox.messages();
    if(!messages.length)return "Your Mail inbox is empty.";
    var received=app.inbox.messages.dateReceived();
    if(received.length!==messages.length)fail("native");
    var ordered=messages.map(function(message,index){return {message:message,date:received[index]};});
    ordered.sort(function(a,b){return b.date.getTime()-a.date.getTime();});
    return "From your Mail inbox (up to 5 recent messages; text previews):\n\n"+ordered.slice(0,5).map(function(item){var message=item.message;return message.subject()+"\nFrom: "+message.sender()+"\n"+item.date.toLocaleString()+"\n"+message.content().slice(0,600);}).join("\n\n");
  }
  var message=app.OutgoingMessage({subject:fields.subject,content:fields.body+"\n",visible:job.kind==="mail_draft"});
  app.outgoingMessages.push(message);message.toRecipients.push(app.ToRecipient({address:fields.to}));
  if(job.kind==="mail_draft") {app.activate();return "Opened a draft in Mail. It has not been sent.\nTo: "+fields.to+"\nSubject: "+fields.subject;}
  checkDeadline(job);if(app.send(message)===false)fail("native");
  return "Submitted to Mail for sending. Delivery depends on your Mail account and connection.\nTo: "+fields.to+"\nSubject: "+fields.subject;
}
// eslint-disable-next-line @typescript-eslint/no-unused-vars -- Native app entry point.
function run() {
  var nativeArgs=$.NSProcessInfo.processInfo.arguments,args=[];
  for(var i=0;i<Number(nativeArgs.count);i++)args.push(unwrap(nativeArgs.objectAtIndex(i)));
  var folder=args.filter(function(arg){return /^\/.*\/edith-action-[A-Za-z0-9]+$/.test(arg);}).pop();
  if(!folder)return;
  $.NSApplication.sharedApplication.activateIgnoringOtherApps(true);
  var result;
  try {
    var raw=unwrap($.NSString.stringWithContentsOfFileEncodingError(folder+"/input.json",4,null));
    if(!raw||raw.length>20000)fail("native");var job=JSON.parse(raw);
    if(!job.fields||typeof job.deadline!=="number")fail("native");checkDeadline(job);
    if(job.kind==="calendar_read"||job.kind==="calendar_create")result={ok:true,text:calendar(job)};
    else if(job.kind==="reminder_read"||job.kind==="reminder_create")result={ok:true,text:reminders(job)};
    else if(job.kind==="mail_read"||job.kind==="mail_draft"||job.kind==="mail_send")result={ok:true,text:mail(job)};
    else fail("native");
  }catch(error){result={ok:false,code:error.edithCode||(/not authorized|not permitted|-1743|denied/i.test(String(error))?"permission":"native")};}
  $(JSON.stringify(result)).writeToFileAtomicallyEncodingError(folder+"/result.json",true,4,null);
  $.NSFileManager.defaultManager.removeItemAtPathError(folder+"/input.json",null);
}
