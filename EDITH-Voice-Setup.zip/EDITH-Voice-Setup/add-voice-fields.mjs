import { existsSync, lstatSync, readFileSync, writeFileSync, renameSync, unlinkSync } from "node:fs";
import { resolve } from "node:path";
import { randomUUID } from "node:crypto";
import { fileURLToPath } from "node:url";

// Append missing placeholders only. Never log, replace or request credentials.
export function ensureVoiceEnvironment(directory = process.cwd()) {
 const folder = resolve(directory);
 const packagePath = resolve(folder, "package.json");
 if (!existsSync(packagePath) || JSON.parse(readFileSync(packagePath, "utf8")).name !== "edith") throw new Error("Run from your current E.D.I.T.H. folder, or provide its path.");
 const envPath = resolve(folder, ".env");
 const existingFile = existsSync(envPath);
 if (existingFile && !lstatSync(envPath).isFile()) throw new Error("Use a regular private .env file before adding voice settings.");
 // Reject dangling symlinks as well: existsSync follows links.
 if (!existingFile) {
  try { if (lstatSync(envPath).isSymbolicLink()) throw new Error("Use a regular private .env file before adding voice settings."); }
  catch (error) { if (error.code !== "ENOENT") throw error; }
 }
 const original = readFileSync(existingFile ? envPath : resolve(folder, ".env.example"), "utf8");
 const names = ["ELEVENLABS_API_KEY", "ELEVENLABS_VOICE_ID"];
 const missing = names.filter(name => !new RegExp(`^[\\t \\uFEFF]*(?:export[\\t ]+)?${name}[\\t ]*(?:=|:[\\t ])`, "m").test(original));
 if (existingFile && !missing.length) return { added: [], created: false };
 const newline = original.includes("\r\n") ? "\r\n" : "\n";
 let updated = original;
 if (missing.length) {
  if (updated && !updated.endsWith("\n")) updated += newline;
  updated += "# ElevenLabs voice: enter your own values privately." + newline;
  updated += missing.map(name => `${name}=""`).join(newline) + newline;
 }
 const temporary = envPath + ".voice-" + randomUUID();
 try {
  writeFileSync(temporary, updated, { mode: 0o600, flag: "wx" });
  renameSync(temporary, envPath);
 } finally {
  if (existsSync(temporary)) unlinkSync(temporary);
 }
 return { added: missing, created: !existingFile };
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
 const result = ensureVoiceEnvironment(process.argv[2]);
 console.log(result.added.length || result.created ? "Blank voice settings are ready in your private .env. Enter your own ELEVENLABS_API_KEY and ELEVENLABS_VOICE_ID there, then restart E.D.I.T.H." : "The voice fields already exist. Their current values were preserved.");
}
