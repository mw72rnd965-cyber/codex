E.D.I.T.H. — ADD MISSING VOICE FIELDS

Unzip into Downloads. Open Terminal and run:
  node ~/Downloads/EDITH-Voice-Setup/add-voice-fields.mjs ~/Downloads/EDITH-Emiliano
Use your actual current installation path as the last argument if different,
such as ~/Downloads/EDITH-Ollama or ~/Downloads/EDITH-Core.
This adds blank ELEVENLABS_API_KEY and ELEVENLABS_VOICE_ID entries in the
private .env in your current app folder. It preserves existing values and
adds no duplicates. Your model, database and documents are not modified.
No package installation is needed; use the Node.js already running your app.

Then open your existing app folder's private .env:
  cd ~/Downloads/EDITH-Emiliano
  nano .env
Find these two lines and put your own values inside the quotes:
  ELEVENLABS_API_KEY=""
  ELEVENLABS_VOICE_ID=""
Save with Control+O, Enter, then exit with Control+X.
Stop and restart the app and scheduler with Control+C, then npm run dev
and npm run scheduler in their separate terminals in your existing folder.
Choose ElevenLabs as the voice engine in Privacy & preferences, save,
then click Integrations -> Preview selected voice.

Get your own key and a voice your account can use from https://elevenlabs.io/.
This utility adds empty fields; it does not generate credentials or activate
an account. Keep your actual API key in .env, never in chat.
